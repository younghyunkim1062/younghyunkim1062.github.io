"""
gui/morphology_tab.py
Tab 3 — Morphology & Fluorescence Analysis

Features:
  ① Multi-channel Z-stack .tif loader
  ② Per-channel mean intensity + area-normalized intensity
  ③ Channel intensity ratio (e.g. MLC2v / MLC2a)
  ④ 3D Volume rendering (multi-channel overlay, matplotlib 3D MIP)
  ⑤ Intensity surface plot (per channel, Z-projected)
  ⑥ Excel export
"""

import sys
import numpy as np
from pathlib import Path

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QPushButton, QLabel, QFileDialog, QComboBox,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QGroupBox, QDoubleSpinBox, QSpinBox, QCheckBox,
    QMessageBox, QScrollArea, QSizePolicy, QFormLayout,
    QSlider, QListWidget, QListWidgetItem, QColorDialog,
    QProgressDialog, QTabWidget,
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QColor

import matplotlib
matplotlib.use("Qt5Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_qt5agg import (
    FigureCanvasQTAgg as FigureCanvas,
    NavigationToolbar2QT as NavToolbar,
)
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.colors import Normalize
import matplotlib.cm as cm

import tifffile

# ── Fonts ────────────────────────────────────────────────────────────────────
ARIAL    = QFont("Arial", 10)
ARIAL_SM = QFont("Arial", 9)
ARIAL_BD = QFont("Arial", 10, QFont.Bold)

plt.rcParams.update({"font.family": "Arial", "axes.titlesize": 9,
                      "axes.labelsize": 8, "xtick.labelsize": 8,
                      "ytick.labelsize": 8})

def _btn(text, color=None, bold=False):
    b = QPushButton(text)
    b.setFont(ARIAL_BD if bold else ARIAL)
    if color:
        b.setStyleSheet(f"background-color:{color};")
    return b

def _lbl(text, bold=False, size=10):
    l = QLabel(text)
    l.setFont(QFont("Arial", size, QFont.Bold if bold else QFont.Normal))
    return l


# Default channel colors (RGBA 0-1)
DEFAULT_COLORS = [
    (0.0, 0.5, 1.0),   # blue   — ch0 (DAPI)
    (0.0, 1.0, 0.0),   # green  — ch1 (cTNT / GFP)
    (1.0, 0.0, 0.0),   # red    — ch2 (MLC2v / RFP)
    (1.0, 0.8, 0.0),   # yellow — ch3 (MLC2a)
    (1.0, 0.0, 1.0),   # magenta— ch4
]
DEFAULT_NAMES = ["DAPI", "cTNT", "MLC2v", "MLC2a", "Ch5"]


# ─────────────────────────────────────────────────────────────────────────────
#  TIF loader worker
# ─────────────────────────────────────────────────────────────────────────────

class TifLoadWorker(QThread):
    finished = pyqtSignal(object, str)   # (ndarray, axes_string)
    error    = pyqtSignal(str)

    def __init__(self, path: str):
        super().__init__()
        self.path = path

    def run(self):
        try:
            with tifffile.TiffFile(self.path) as tif:
                data   = tif.asarray()
                axes   = tif.series[0].axes if tif.series else "unknown"
            self.finished.emit(data, axes)
        except Exception as e:
            self.error.emit(str(e))


# ─────────────────────────────────────────────────────────────────────────────
#  Channel settings row widget
# ─────────────────────────────────────────────────────────────────────────────

class ChannelRow(QWidget):
    def __init__(self, ch_idx: int, name: str, color: tuple, parent=None):
        super().__init__(parent)
        self._color = color
        layout = QHBoxLayout(self)
        layout.setContentsMargins(2, 1, 2, 1)
        layout.setSpacing(6)

        self.chk     = QCheckBox()
        self.chk.setChecked(True)
        self.name_edit = QLabel(name)
        self.name_edit.setFont(ARIAL_SM)
        self.name_edit.setMinimumWidth(60)

        self.color_btn = QPushButton()
        self.color_btn.setFixedSize(24, 20)
        self._apply_color(color)

        self.gamma_spin = QDoubleSpinBox()
        self.gamma_spin.setRange(0.1, 5.0)
        self.gamma_spin.setValue(1.0)
        self.gamma_spin.setSingleStep(0.1)
        self.gamma_spin.setFont(ARIAL_SM)
        self.gamma_spin.setFixedWidth(60)

        layout.addWidget(self.chk)
        layout.addWidget(_lbl(f"Ch{ch_idx}:", size=9))
        layout.addWidget(self.name_edit)
        layout.addWidget(self.color_btn)
        layout.addWidget(_lbl("γ:", size=8))
        layout.addWidget(self.gamma_spin)
        layout.addStretch()

        self.color_btn.clicked.connect(self._pick_color)

    def _apply_color(self, rgb_01):
        r, g, b = [int(v * 255) for v in rgb_01]
        self.color_btn.setStyleSheet(
            f"background-color: rgb({r},{g},{b}); border: 1px solid #999;")
        self._color = rgb_01

    def _pick_color(self):
        r, g, b = [int(v * 255) for v in self._color]
        col = QColorDialog.getColor(QColor(r, g, b), self)
        if col.isValid():
            self._apply_color((col.redF(), col.greenF(), col.blueF()))

    @property
    def enabled(self): return self.chk.isChecked()
    @property
    def color(self):   return self._color
    @property
    def gamma(self):   return self.gamma_spin.value()
    @property
    def name(self):    return self.name_edit.text()


# ─────────────────────────────────────────────────────────────────────────────
#  Main Tab 3 widget
# ─────────────────────────────────────────────────────────────────────────────

class MorphologyTab(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._data      = None   # raw ndarray (C, Z, Y, X) after parsing
        self._n_ch      = 0
        self._n_z       = 0
        self._ch_rows: list[ChannelRow] = []
        self._results: dict = {}
        self._build_ui()

    # ─────────────────────────────────────────────────────────────────────────
    #  UI
    # ─────────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setSpacing(4)
        root.setContentsMargins(4, 4, 4, 4)

        title_row = QHBoxLayout()
        title_row.addWidget(
            _lbl("■  Morphology & Fluorescence Analysis  (Z-stack TIFF)",
                 bold=True, size=11))
        title_row.addStretch()
        root.addLayout(title_row)

        splitter = QSplitter(Qt.Horizontal)
        root.addWidget(splitter, stretch=1)

        # ── LEFT: controls ───────────────────────────────────────────────────
        ctrl = QWidget(); ctrl.setMaximumWidth(290)
        cl   = QVBoxLayout(ctrl); cl.setSpacing(6)

        # Load
        grp_load = QGroupBox("Step 1 — Load Z-stack TIFF")
        grp_load.setFont(ARIAL_BD)
        g1 = QVBoxLayout(grp_load)
        self.btn_load  = _btn("📂  Load .tif / .tiff")
        self.file_lbl  = _lbl("No file loaded", size=8)
        self.file_lbl.setWordWrap(True)
        self.file_lbl.setStyleSheet("color:gray;")
        self.info_lbl  = _lbl("", size=8)
        self.info_lbl.setStyleSheet("color:#1A5E1A;")
        g1.addWidget(self.btn_load)
        g1.addWidget(self.file_lbl)
        g1.addWidget(self.info_lbl)
        cl.addWidget(grp_load)

        # Channel settings
        grp_ch = QGroupBox("Step 2 — Channel Settings")
        grp_ch.setFont(ARIAL_BD)
        g2 = QVBoxLayout(grp_ch)
        self.ch_container = QWidget()
        self.ch_layout    = QVBoxLayout(self.ch_container)
        self.ch_layout.setSpacing(2)
        g2.addWidget(self.ch_container)
        cl.addWidget(grp_ch)

        # Ratio
        grp_ratio = QGroupBox("Step 3 — Intensity Ratio")
        grp_ratio.setFont(ARIAL_BD)
        g3 = QFormLayout(grp_ratio)
        self.ratio_num = QComboBox(); self.ratio_num.setFont(ARIAL)
        self.ratio_den = QComboBox(); self.ratio_den.setFont(ARIAL)
        g3.addRow("Numerator:",   self.ratio_num)
        g3.addRow("Denominator:", self.ratio_den)
        cl.addWidget(grp_ratio)

        # Z-slice selector
        grp_z = QGroupBox("Z-slice for Surface Plot")
        grp_z.setFont(ARIAL_BD)
        g4 = QFormLayout(grp_z)
        self.z_combo = QComboBox(); self.z_combo.setFont(ARIAL)
        self.z_combo.addItem("Max Projection (all Z)")
        g4.addRow("Z slice:", self.z_combo)
        self.surf_ch_combo = QComboBox(); self.surf_ch_combo.setFont(ARIAL)
        g4.addRow("Channel:", self.surf_ch_combo)
        cl.addWidget(grp_z)

        # Action buttons
        self.btn_analyze = _btn("▶  Analyze", color="#d4f0d4", bold=True)
        self.btn_vol3d   = _btn("🧊  3D Volume Render", color="#e0f0ff")
        self.btn_surface = _btn("📈  Surface Plot", color="#f0e0ff")
        self.btn_export  = _btn("💾  Export Excel")
        for b in [self.btn_analyze, self.btn_vol3d,
                  self.btn_surface, self.btn_export]:
            cl.addWidget(b)
        cl.addStretch()
        splitter.addWidget(ctrl)

        # ── RIGHT: view tabs ─────────────────────────────────────────────────
        right = QWidget()
        rl    = QVBoxLayout(right)
        rl.setContentsMargins(0, 0, 0, 0)

        self.view_tabs = QTabWidget()
        self.view_tabs.setFont(ARIAL)

        # Tab A: Intensity analysis
        tab_a = QWidget()
        ta_l  = QVBoxLayout(tab_a)
        self.fig_int, axes_int = plt.subplots(1, 2, figsize=(10, 4))
        self.ax_bar, self.ax_ratio = axes_int
        self.canvas_int = FigureCanvas(self.fig_int)
        ta_l.addWidget(NavToolbar(self.canvas_int, self))
        ta_l.addWidget(self.canvas_int, stretch=1)
        # Result table
        self.result_table = QTableWidget(0, 4)
        self.result_table.setHorizontalHeaderLabels(
            ["Channel", "Mean Intensity", "Area-norm. Intensity", "Ratio"])
        self.result_table.setFont(ARIAL_SM)
        self.result_table.horizontalHeader().setFont(ARIAL_SM)
        for i in range(4):
            self.result_table.horizontalHeader().setSectionResizeMode(
                i, QHeaderView.Stretch)
        self.result_table.setMaximumHeight(160)
        ta_l.addWidget(self.result_table)
        self.view_tabs.addTab(tab_a, "📊  Intensity")

        # Tab B: 3D Volume rendering
        tab_b  = QWidget()
        tb_l   = QVBoxLayout(tab_b)
        self.fig_vol = plt.figure(figsize=(10, 7))
        self.canvas_vol = FigureCanvas(self.fig_vol)
        tb_l.addWidget(NavToolbar(self.canvas_vol, self))
        tb_l.addWidget(self.canvas_vol, stretch=1)
        self.view_tabs.addTab(tab_b, "🧊  3D Volume")

        # Tab C: Surface plot
        tab_c  = QWidget()
        tc_l   = QVBoxLayout(tab_c)
        self.fig_surf = plt.figure(figsize=(10, 7))
        self.canvas_surf = FigureCanvas(self.fig_surf)
        tc_l.addWidget(NavToolbar(self.canvas_surf, self))
        tc_l.addWidget(self.canvas_surf, stretch=1)
        self.view_tabs.addTab(tab_c, "📈  Surface")

        rl.addWidget(self.view_tabs)
        splitter.addWidget(right)
        splitter.setSizes([270, 900])

        # Wire up
        self.btn_load.clicked.connect(self._load_tif)
        self.btn_analyze.clicked.connect(self._run_analysis)
        self.btn_vol3d.clicked.connect(self._render_volume)
        self.btn_surface.clicked.connect(self._render_surface)
        self.btn_export.clicked.connect(self._export_excel)

    # ─────────────────────────────────────────────────────────────────────────
    #  Step 1 — Load TIF
    # ─────────────────────────────────────────────────────────────────────────

    def _load_tif(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Z-stack TIFF", "",
            "TIFF files (*.tif *.tiff)")
        if not path:
            return
        self.file_lbl.setText(Path(path).name)
        self.file_lbl.setStyleSheet("color:#1A5E1A;")

        self._load_worker = TifLoadWorker(path)
        self._load_worker.finished.connect(self._on_tif_loaded)
        self._load_worker.error.connect(
            lambda e: QMessageBox.critical(self, "Load error", e))
        self._load_worker.start()

    def _on_tif_loaded(self, data: np.ndarray, axes: str):
        """Parse loaded array into (C, Z, Y, X)."""
        arr = data.astype(np.float32)

        # Normalise to (C, Z, Y, X) regardless of input shape
        if arr.ndim == 2:       # Y, X → 1ch, 1z
            arr = arr[np.newaxis, np.newaxis, :, :]
        elif arr.ndim == 3:
            # Could be Z,Y,X or C,Y,X — assume Z,Y,X (single channel)
            arr = arr[np.newaxis, :, :, :]
        elif arr.ndim == 4:
            # Could be C,Z,Y,X or Z,C,Y,X
            if "C" in axes and axes.index("C") == 1:
                arr = arr.transpose(1, 0, 2, 3)   # Z,C,Y,X → C,Z,Y,X
            # else assume already C,Z,Y,X
        elif arr.ndim == 5:
            # T,C,Z,Y,X → take first timepoint
            arr = arr[0]
            if arr.ndim == 4 and "C" in axes:
                pass  # already C,Z,Y,X

        self._data = arr
        self._n_ch, self._n_z = arr.shape[0], arr.shape[1]
        H, W = arr.shape[2], arr.shape[3]

        self.info_lbl.setText(
            f"Channels: {self._n_ch}  |  Z: {self._n_z}  |  {W}×{H} px")

        # Build channel rows
        for row in self._ch_rows:
            row.setParent(None)
        self._ch_rows.clear()
        while self.ch_layout.count():
            self.ch_layout.takeAt(0)

        self.ratio_num.clear()
        self.ratio_den.clear()
        self.surf_ch_combo.clear()

        for i in range(self._n_ch):
            name  = DEFAULT_NAMES[i] if i < len(DEFAULT_NAMES) else f"Ch{i}"
            color = DEFAULT_COLORS[i] if i < len(DEFAULT_COLORS) else (1,1,1)
            row   = ChannelRow(i, name, color)
            self._ch_rows.append(row)
            self.ch_layout.addWidget(row)
            self.ratio_num.addItem(name)
            self.ratio_den.addItem(name)
            self.surf_ch_combo.addItem(name)

        # Z-slice selector
        self.z_combo.clear()
        self.z_combo.addItem("Max Projection (all Z)")
        for z in range(self._n_z):
            self.z_combo.addItem(f"Z = {z}")

        if self._n_ch >= 2:
            self.ratio_den.setCurrentIndex(1)

    # ─────────────────────────────────────────────────────────────────────────
    #  Step 2 — Intensity analysis
    # ─────────────────────────────────────────────────────────────────────────

    def _run_analysis(self):
        if self._data is None:
            QMessageBox.warning(self, "No data", "Load a TIFF first.")
            return

        arr = self._data   # (C, Z, Y, X)
        results = []

        for ci, row in enumerate(self._ch_rows):
            ch_vol = arr[ci]                         # (Z, Y, X)
            mip    = ch_vol.max(axis=0)              # max-Z projection
            mean_i = float(mip.mean())
            # Organoid mask: pixels > 10th percentile of MIP
            thresh  = np.percentile(mip, 10)
            mask    = mip > thresh
            area_px = int(mask.sum())
            area_norm = mean_i / max(area_px, 1) * 1e4   # scaled
            results.append({
                "name":       row.name,
                "mean":       mean_i,
                "area_norm":  area_norm,
                "area_px":    area_px,
            })

        # Ratio
        num_idx = self.ratio_num.currentIndex()
        den_idx = self.ratio_den.currentIndex()
        ratio_val = np.nan
        if den_idx < len(results) and results[den_idx]["mean"] > 0:
            ratio_val = results[num_idx]["mean"] / results[den_idx]["mean"]

        self._results = {
            "channels": results,
            "ratio": ratio_val,
            "ratio_label": f"{self.ratio_num.currentText()} / {self.ratio_den.currentText()}",
        }

        self._plot_intensity(results, ratio_val)
        self._update_table(results, ratio_val)
        self.view_tabs.setCurrentIndex(0)

    def _plot_intensity(self, results, ratio_val):
        self.ax_bar.cla(); self.ax_ratio.cla()

        names  = [r["name"] for r in results]
        means  = [r["mean"] for r in results]
        norms  = [r["area_norm"] for r in results]
        colors = [self._ch_rows[i].color for i in range(len(results))]

        x = np.arange(len(names))
        self.ax_bar.bar(x - 0.2, means, width=0.35,
                        color=colors, label="Mean intensity", alpha=0.85)
        self.ax_bar.bar(x + 0.2, norms, width=0.35,
                        color=colors, label="Area-norm (×10⁴)", alpha=0.5,
                        hatch="//")
        self.ax_bar.set_xticks(x); self.ax_bar.set_xticklabels(names)
        self.ax_bar.set_ylabel("Intensity (AU)")
        self.ax_bar.set_title("Per-channel Intensity (MIP)")
        self.ax_bar.legend(fontsize=7)
        self.ax_bar.grid(True, alpha=0.2, axis="y")

        # Ratio bar
        num_idx = self.ratio_num.currentIndex()
        den_idx = self.ratio_den.currentIndex()
        label   = self._results["ratio_label"]
        self.ax_ratio.bar([label], [ratio_val if not np.isnan(ratio_val) else 0],
                           color="#4A90D9", alpha=0.85)
        self.ax_ratio.set_title(f"Intensity Ratio: {label}")
        self.ax_ratio.set_ylabel("Ratio")
        self.ax_ratio.grid(True, alpha=0.2, axis="y")

        self.fig_int.tight_layout()
        self.canvas_int.draw_idle()

    def _update_table(self, results, ratio_val):
        self.result_table.setRowCount(len(results))
        for r, res in enumerate(results):
            items = [
                res["name"],
                f"{res['mean']:.2f}",
                f"{res['area_norm']:.4f}",
                f"{ratio_val:.4f}" if r == self.ratio_num.currentIndex()
                                   and not np.isnan(ratio_val) else "—",
            ]
            for c, v in enumerate(items):
                item = QTableWidgetItem(str(v))
                item.setFont(ARIAL_SM)
                item.setTextAlignment(Qt.AlignCenter)
                self.result_table.setItem(r, c, item)

    # ─────────────────────────────────────────────────────────────────────────
    #  3D Volume Rendering (multi-channel MIP overlay)
    # ─────────────────────────────────────────────────────────────────────────

    def _render_volume(self):
        if self._data is None:
            QMessageBox.warning(self, "No data", "Load a TIFF first.")
            return

        self.fig_vol.clear()
        arr = self._data   # (C, Z, Y, X)
        H, W = arr.shape[2], arr.shape[3]

        # ── 1. XY Max projection (top view) ─────────────────────────────────
        ax_xy = self.fig_vol.add_subplot(2, 2, 1)
        ax_xy.set_title("XY  (Max Z projection)", fontsize=9)
        composite_xy = self._make_composite(arr, proj_axis=1)   # max over Z
        ax_xy.imshow(composite_xy)
        ax_xy.axis("off")

        # ── 2. XZ projection (side view, Y collapsed) ───────────────────────
        ax_xz = self.fig_vol.add_subplot(2, 2, 2)
        ax_xz.set_title("XZ  (Max Y projection)", fontsize=9)
        composite_xz = self._make_composite(arr, proj_axis=2)   # max over Y
        ax_xz.imshow(composite_xz, aspect="auto")
        ax_xz.axis("off")

        # ── 3. YZ projection (front view, X collapsed) ──────────────────────
        ax_yz = self.fig_vol.add_subplot(2, 2, 3)
        ax_yz.set_title("YZ  (Max X projection)", fontsize=9)
        composite_yz = self._make_composite(arr, proj_axis=3)   # max over X
        ax_yz.imshow(composite_yz, aspect="auto")
        ax_yz.axis("off")

        # ── 4. 3D scatter (Z-MIP contour in 3D space) ───────────────────────
        ax3d = self.fig_vol.add_subplot(2, 2, 4, projection="3d")
        ax3d.set_title("3D  (Z-depth projection)", fontsize=9)

        for ci, row in enumerate(self._ch_rows):
            if not row.enabled or ci >= self._data.shape[0]:
                continue
            ch_vol = arr[ci]                          # (Z, Y, X)
            gamma  = row.gamma
            # Z-weighted projection: for each XY pixel find Z of max intensity
            z_idx  = np.argmax(ch_vol, axis=0)        # (Y, X)
            mip    = ch_vol.max(axis=0)

            # Subsample for performance
            step = max(1, min(H, W) // 60)
            ys   = np.arange(0, H, step)
            xs   = np.arange(0, W, step)
            Xg, Yg = np.meshgrid(xs, ys)
            Zg   = z_idx[::step, ::step]
            Ig   = mip[::step, ::step]

            # Normalise intensity for alpha
            Ig_n = ((Ig - Ig.min()) / (Ig.max() - Ig.min() + 1e-9)) ** gamma
            mask = Ig_n > 0.15   # skip dark pixels

            r, g, b = row.color
            colors_sc = np.zeros((Xg.shape[0], Xg.shape[1], 4))
            colors_sc[..., 0] = r
            colors_sc[..., 1] = g
            colors_sc[..., 2] = b
            colors_sc[..., 3] = Ig_n

            ax3d.scatter(
                Xg[mask].ravel(), Yg[mask].ravel(), Zg[mask].ravel(),
                c=[[r, g, b, float(a)] for a in Ig_n[mask].ravel()],
                s=2, depthshade=True, label=row.name,
            )

        ax3d.set_xlabel("X", fontsize=7)
        ax3d.set_ylabel("Y", fontsize=7)
        ax3d.set_zlabel("Z", fontsize=7)
        ax3d.tick_params(labelsize=6)
        ax3d.legend(fontsize=7, loc="upper left")

        self.fig_vol.tight_layout(pad=1.0)
        self.canvas_vol.draw_idle()
        self.view_tabs.setCurrentIndex(1)

    def _make_composite(self, arr: np.ndarray, proj_axis: int) -> np.ndarray:
        """
        Create RGB composite from all enabled channels.
        proj_axis: 1=Z(XY view), 2=Y(XZ view), 3=X(YZ view)
        """
        n_ch = arr.shape[0]
        proj = arr.max(axis=proj_axis)   # (C, A, B) after reducing proj_axis

        H2, W2 = proj.shape[1], proj.shape[2]
        composite = np.zeros((H2, W2, 3), dtype=np.float32)

        for ci, row in enumerate(self._ch_rows):
            if not row.enabled or ci >= n_ch:
                continue
            ch   = proj[ci].astype(np.float32)
            gamma = row.gamma
            vmin, vmax = np.percentile(ch, [1, 99])
            ch_n = np.clip((ch - vmin) / (vmax - vmin + 1e-9), 0, 1) ** gamma
            r, g, b = row.color
            composite[..., 0] += ch_n * r
            composite[..., 1] += ch_n * g
            composite[..., 2] += ch_n * b

        return np.clip(composite, 0, 1)

    # ─────────────────────────────────────────────────────────────────────────
    #  Intensity Surface Plot
    # ─────────────────────────────────────────────────────────────────────────

    def _render_surface(self):
        if self._data is None:
            QMessageBox.warning(self, "No data", "Load a TIFF first.")
            return

        ch_idx = self.surf_ch_combo.currentIndex()
        z_sel  = self.z_combo.currentIndex()   # 0 = MIP, else z index

        arr    = self._data[ch_idx]   # (Z, Y, X)
        if z_sel == 0:
            img = arr.max(axis=0).astype(np.float32)
            z_label = "Max Z Projection"
        else:
            z_idx = z_sel - 1
            img   = arr[z_idx].astype(np.float32)
            z_label = f"Z = {z_idx}"

        # Subsample for surface
        step = max(1, min(img.shape) // 80)
        img_s = img[::step, ::step]
        H2, W2 = img_s.shape
        X = np.arange(W2) * step
        Y = np.arange(H2) * step
        Xg, Yg = np.meshgrid(X, Y)

        # Gamma
        gamma = self._ch_rows[ch_idx].gamma if ch_idx < len(self._ch_rows) else 1.0
        vmin, vmax = np.percentile(img_s, [1, 99])
        Zg = np.clip((img_s - vmin) / (vmax - vmin + 1e-9), 0, 1) ** gamma

        ch_name = self.surf_ch_combo.currentText()
        r_c, g_c, b_c = (self._ch_rows[ch_idx].color
                          if ch_idx < len(self._ch_rows) else (0.3, 0.6, 1.0))

        self.fig_surf.clear()

        # ── Top: 2D heatmap ──────────────────────────────────────────────────
        ax2d = self.fig_surf.add_subplot(1, 2, 1)
        cmap = self._channel_cmap(r_c, g_c, b_c)
        im   = ax2d.imshow(img_s, cmap=cmap, aspect="equal",
                            vmin=vmin, vmax=vmax)
        self.fig_surf.colorbar(im, ax=ax2d, fraction=0.046, pad=0.04,
                                label="Intensity (AU)")
        ax2d.set_title(f"{ch_name}  —  {z_label}  (Heatmap)", fontsize=9)
        ax2d.set_xlabel("X (px)"); ax2d.set_ylabel("Y (px)")

        # ── Bottom: 3D surface ───────────────────────────────────────────────
        ax3d = self.fig_surf.add_subplot(1, 2, 2, projection="3d")
        face_colors = plt.cm.get_cmap(cmap)(Zg)
        surf = ax3d.plot_surface(
            Xg, Yg, Zg,
            facecolors=face_colors,
            rstride=1, cstride=1,
            linewidth=0, antialiased=False, shade=True,
        )
        ax3d.set_xlabel("X (px)", fontsize=7)
        ax3d.set_ylabel("Y (px)", fontsize=7)
        ax3d.set_zlabel("Norm. Intensity", fontsize=7)
        ax3d.set_title(f"{ch_name}  —  {z_label}  (Surface)", fontsize=9)
        ax3d.tick_params(labelsize=6)
        ax3d.view_init(elev=35, azim=-60)

        self.fig_surf.tight_layout(pad=1.5)
        self.canvas_surf.draw_idle()
        self.view_tabs.setCurrentIndex(2)

    def _channel_cmap(self, r, g, b):
        """Create a black→channel_color colormap."""
        from matplotlib.colors import LinearSegmentedColormap
        return LinearSegmentedColormap.from_list(
            "ch_cmap", [(0, 0, 0), (r, g, b)])

    # ─────────────────────────────────────────────────────────────────────────
    #  Export Excel
    # ─────────────────────────────────────────────────────────────────────────

    def _export_excel(self):
        if not self._results:
            QMessageBox.warning(self, "No data", "Run analysis first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Excel", "morphology_results.xlsx", "Excel (*.xlsx)")
        if not path:
            return
        try:
            import openpyxl
            from openpyxl.styles import Font, PatternFill, Alignment
            wb = openpyxl.Workbook()
            ws = wb.active
            ws.title = "Fluorescence Intensity"

            hdrs = ["Channel", "Mean Intensity (AU)",
                    "Area-norm Intensity (×10⁴)",
                    "Mask Area (px)", "Ratio"]
            for ci, h in enumerate(hdrs, start=1):
                c = ws.cell(1, ci, h)
                c.font = Font(bold=True, color="FFFFFF", name="Arial")
                c.fill = PatternFill("solid", fgColor="1F3864")
                c.alignment = Alignment(horizontal="center")

            ratio_lbl = self._results["ratio_label"]
            ratio_val = self._results["ratio"]
            num_name  = self.ratio_num.currentText()

            for r, res in enumerate(self._results["channels"], start=2):
                rv = ratio_val if (res["name"] == num_name
                                    and not np.isnan(ratio_val)) else ""
                row_data = [res["name"], round(res["mean"], 3),
                             round(res["area_norm"], 5),
                             res["area_px"], rv if rv == "" else round(rv, 4)]
                for ci, v in enumerate(row_data, start=1):
                    ws.cell(r, ci, v)

            # Ratio summary
            ws.cell(len(self._results["channels"]) + 3, 1,
                    f"Ratio ({ratio_lbl})")
            ws.cell(len(self._results["channels"]) + 3, 2,
                    round(ratio_val, 4) if not np.isnan(ratio_val) else "N/A")

            for col in ["A","B","C","D","E"]:
                ws.column_dimensions[col].width = 24
            wb.save(path)
            QMessageBox.information(self, "Saved", f"Saved to:\n{path}")
        except Exception as e:
            QMessageBox.critical(self, "Export error", str(e))
