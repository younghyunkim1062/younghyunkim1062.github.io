# gui package — intentionally minimal to avoid circular imports
