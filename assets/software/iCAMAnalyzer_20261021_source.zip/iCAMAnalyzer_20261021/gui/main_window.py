"""
iCAMAnalyzer: UI refresh of the supplied v6_chip source snapshot.
Presentation changes dated 2026-10-21; original analysis modes retained.
"""

import sys, os
import numpy as np
import cv2
from pathlib import Path

from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QTabWidget,
    QPushButton, QLabel, QFileDialog, QInputDialog, QMessageBox,
    QCheckBox, QProgressDialog, QTableWidget, QTableWidgetItem,
    QSplitter, QComboBox, QSizePolicy, QStatusBar,
    QHeaderView, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QFormLayout, QSlider, QGroupBox, QButtonGroup, QRadioButton,
    QFrame, QScrollArea,
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui  import QFont, QPixmap

import matplotlib
matplotlib.use("Qt5Agg")
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.backends.backend_qt5agg import NavigationToolbar2QT as NavToolbar
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
import matplotlib.font_manager as fm

sys.path.insert(0, str(Path(__file__).parent.parent))
from gui.contractility_tab import ContractilityTab
from gui.theme import (font, label, button, card, SignalMark,
                       style_table, install_theme, FONT_FAMILY)
from core import (analyze_transient, safe_sg, KineticsResult,
                  compute_activation_map, build_organoid_mask,
                  prepare_hires_map, ActivationResult,
                  build_chip_mask_auto, build_chip_mask_from_template,
                  compute_arc_length_cv, ChipArcResult,
                  export_excel, export_whole_trace,
                  export_avg_transient, export_activation_map,
                  analyze_alternans, analyze_beat_irregularity,
                  detect_dad, detect_triggered_activity)

# ── Global font ───────────────────────────────────────────────────────────────
ARIAL      = QFont(FONT_FAMILY, 10)
ARIAL_BOLD = QFont(FONT_FAMILY, 10, QFont.Bold)
ARIAL_SM   = QFont(FONT_FAMILY, 9)

plt.rcParams.update({
    "font.family":      "DejaVu Sans",   # supports ⚠ ⁻ ₀ etc. (Arial lacks them)
    "font.sans-serif":  ["DejaVu Sans", "Arial", "sans-serif"],
    "axes.unicode_minus": False,          # use ASCII minus instead of U+2212
    "axes.titlesize":   10,
    "axes.labelsize":   9,
    "xtick.labelsize":  8,
    "ytick.labelsize":  8,
    "legend.fontsize":  8,
})

# ── Colormap ──────────────────────────────────────────────────────────────────
ICAM_CMAP = mcolors.LinearSegmentedColormap.from_list(
    "icam",
    [np.array(c) / 255 for c in [
        (90, 25, 140), (25, 65, 180), (128, 128, 140),
        (40, 165, 90), (240, 230, 40), (230, 25, 25),
    ]]
)

def _btn(text, color=None, bold=False):
    return button(text, color, bold)

def _lbl(text, bold=False, size=10):
    return label(text, bold, size)


# ══════════════════════════════════════════════════════════════════════════════
#  Startup modal: Analysis Type Selection
# ══════════════════════════════════════════════════════════════════════════════

# Keeps strong references to windows created via "Switch Mode" so they
# aren't garbage-collected the moment the creating function returns.
_OPEN_WINDOWS = []


class AnalysisTypeDialog(QDialog):
    """
    Modal dialog shown at app startup for selecting the analysis type.
    Returns: 'fluorescence' or 'brightfield'
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("iCAMAnalyzer — Choose workspace")
        self.setMinimumWidth(560)
        self.resize(600, 460)
        self.setFont(font())
        self._choice = "fluorescence"

        root = QVBoxLayout(self)
        root.setContentsMargins(30, 26, 30, 26)
        root.setSpacing(14)
        brand = QHBoxLayout()
        brand.addWidget(SignalMark())
        titles = QVBoxLayout()
        titles.setSpacing(3)
        titles.addWidget(label("iCAMAnalyzer", True, 20))
        titles.addWidget(label("Calcium & motion analysis", size=10, role="muted"))
        brand.addLayout(titles)
        brand.addStretch()
        root.addLayout(brand)
        root.addSpacing(10)
        root.addWidget(label("Choose your analysis workspace", True, 13))
        hint = label("Start with the imaging modality of your recording.", size=10, role="muted")
        hint.setWordWrap(True)
        root.addWidget(hint)

        self._btn_group = QButtonGroup(self)
        self._radio_ca = QRadioButton("Fluorescence\nCalcium transients and activation mapping")
        self._radio_bf = QRadioButton("Brightfield\nMotion, contractility and mechanical maps")
        for idx, radio in enumerate([self._radio_ca, self._radio_bf]):
            radio.setObjectName("modeOption")
            radio.setFont(font(11))
            radio.setCursor(Qt.PointingHandCursor)
            self._btn_group.addButton(radio, idx)
            root.addWidget(radio)
        current = getattr(parent, "_analysis_type", "fluorescence")
        (self._radio_bf if current == "brightfield" else self._radio_ca).setChecked(True)
        root.addStretch()
        confirm_btn = button("Open workspace", role="primary", bold=True)
        confirm_btn.setMinimumHeight(44)
        confirm_btn.setDefault(True)
        confirm_btn.clicked.connect(self._on_confirm)
        root.addWidget(confirm_btn)

    def _on_confirm(self):
        self._choice = "fluorescence" if self._radio_ca.isChecked() else "brightfield"
        self.accept()

    @property
    def choice(self):
        return self._choice


# ══════════════════════════════════════════════════════════════════════════════
#  Worker threads
# ══════════════════════════════════════════════════════════════════════════════

class VideoLoadWorker(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal(object)
    error    = pyqtSignal(str)

    def __init__(self, path):
        super().__init__()
        self.path = path

    def run(self):
        try:
            cap   = cv2.VideoCapture(self.path)
            total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            frames = []
            for f in range(total):
                ret, frm = cap.read()
                if not ret:
                    break
                if frm.ndim == 3:
                    frm = cv2.cvtColor(frm, cv2.COLOR_BGR2GRAY)
                frames.append(frm)
                if f % 20 == 0:
                    self.progress.emit(int(f / total * 100))
            cap.release()
            self.finished.emit(np.stack(frames, axis=2))
        except Exception as e:
            self.error.emit(str(e))


class ActMapWorker(QThread):
    finished = pyqtSignal(object)
    error    = pyqtSignal(str)

    def __init__(self, roi_data, mask, fps, px_to_mm):
        super().__init__()
        self.roi_data = roi_data
        self.mask     = mask
        self.fps      = fps
        self.px_to_mm = px_to_mm

    def run(self):
        try:
            self.finished.emit(
                compute_activation_map(self.roi_data, self.mask,
                                       self.fps, self.px_to_mm))
        except Exception as e:
            self.error.emit(str(e))


# ══════════════════════════════════════════════════════════════════════════════
#  Pixel calibration dialog
# ══════════════════════════════════════════════════════════════════════════════

class CalibDialog(QDialog):
    def __init__(self, parent=None, current_val=1/7.8):
        super().__init__(parent)
        self.setWindowTitle("Pixel Calibration")
        self.setFont(ARIAL)
        layout = QFormLayout(self)
        self.spin = QDoubleSpinBox()
        self.spin.setDecimals(6)
        self.spin.setRange(0.0001, 10.0)
        self.spin.setValue(current_val)
        self.spin.setFont(ARIAL)
        layout.addRow("px → mm  (mm/pixel):", self.spin)
        note = _lbl("Curi Bio Nautilus default:  1 / 7.8  ≈  0.128205", size=9)
        note.setStyleSheet("color: gray;")
        layout.addRow(note)
        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.setFont(ARIAL)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addRow(btns)

    @property
    def value(self):
        return self.spin.value()


# ══════════════════════════════════════════════════════════════════════════════
#  ROI Selector
# ══════════════════════════════════════════════════════════════════════════════

class ROISelectorDialog(QDialog):
    def __init__(self, video_data: np.ndarray, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Select ROI  —  scroll to zoom, drag to pan, then draw")
        self.setMinimumSize(860, 680)
        self.setFont(ARIAL)

        self._video  = video_data
        self._H, self._W, self._F = video_data.shape
        self._mask   = None
        self._selector = None
        self._xlim   = None
        self._ylim   = None

        layout = QVBoxLayout(self)

        self.fig, self.ax = plt.subplots(figsize=(8, 6))
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setFocusPolicy(Qt.StrongFocus)
        layout.addWidget(self.canvas, stretch=1)

        slider_row = QHBoxLayout()
        slider_row.addWidget(_lbl("Frame:"))
        self.frame_slider = QSlider(Qt.Horizontal)
        self.frame_slider.setMinimum(0)
        self.frame_slider.setMaximum(max(0, self._F - 1))
        self.frame_slider.setValue(0)
        self.frame_slider.setFont(ARIAL)
        self.frame_lbl = _lbl("0")
        self.frame_slider.valueChanged.connect(self._on_frame_changed)
        slider_row.addWidget(self.frame_slider, stretch=1)
        slider_row.addWidget(self.frame_lbl)
        layout.addLayout(slider_row)

        ctrl_row = QHBoxLayout()
        self.shape_combo = QComboBox()
        self.shape_combo.addItems(["Ellipse / Circle", "Rectangle", "Freehand"])
        self.shape_combo.setFont(ARIAL)
        ctrl_row.addWidget(_lbl("Shape:"))
        ctrl_row.addWidget(self.shape_combo)

        self.draw_btn    = _btn("✏  Draw ROI")
        self.reset_btn   = _btn("↺  Reset Zoom")
        self.confirm_btn = _btn("✔  Confirm", color="#d4f0d4", bold=True)
        self.confirm_btn.setEnabled(False)
        ctrl_row.addWidget(self.draw_btn)
        ctrl_row.addWidget(self.reset_btn)
        ctrl_row.addStretch()
        ctrl_row.addWidget(self.confirm_btn)
        layout.addLayout(ctrl_row)

        hint = _lbl("  Scroll = zoom  |  Right-drag = pan  |  Draw ROI → Confirm", size=8)
        hint.setStyleSheet("color: gray;")
        layout.addWidget(hint)

        self._show_frame(0)

        self.draw_btn.clicked.connect(self._start_draw)
        self.reset_btn.clicked.connect(self._reset_zoom)
        self.confirm_btn.clicked.connect(self.accept)

        self.canvas.mpl_connect("scroll_event",        self._on_scroll)
        self.canvas.mpl_connect("button_press_event",  self._on_press)
        self.canvas.mpl_connect("motion_notify_event", self._on_motion)
        self.canvas.mpl_connect("button_release_event",self._on_release)
        self._pan_start = None

    def _show_frame(self, idx):
        xlim = self._xlim
        ylim = self._ylim
        self.ax.cla()
        self.ax.imshow(self._video[:, :, idx], cmap="gray",
                       aspect="equal", interpolation="nearest")
        self.ax.set_title(f"Frame {idx} / {self._F-1}  —  draw ROI after zooming",
                          fontsize=9)
        self.ax.axis("off")
        if xlim is not None:
            self.ax.set_xlim(xlim)
            self.ax.set_ylim(ylim)
        self.fig.tight_layout(pad=0.5)
        self.canvas.draw_idle()

    def _on_frame_changed(self, val):
        self.frame_lbl.setText(str(val))
        self._xlim = self.ax.get_xlim()
        self._ylim = self.ax.get_ylim()
        self._show_frame(val)

    def _on_scroll(self, event):
        if event.xdata is None:
            return
        factor = 0.85 if event.button == "up" else 1.0 / 0.85
        xl, xr = self.ax.get_xlim()
        yb, yt = self.ax.get_ylim()
        cx, cy = event.xdata, event.ydata
        self.ax.set_xlim(cx + (xl - cx) * factor, cx + (xr - cx) * factor)
        self.ax.set_ylim(cy + (yb - cy) * factor, cy + (yt - cy) * factor)
        self._xlim = self.ax.get_xlim()
        self._ylim = self.ax.get_ylim()
        self.canvas.draw_idle()

    def _reset_zoom(self):
        self._xlim = None
        self._ylim = None
        self.ax.set_xlim(-0.5, self._W - 0.5)
        self.ax.set_ylim(self._H - 0.5, -0.5)
        self.canvas.draw_idle()

    def _on_press(self, event):
        if event.button == 3 and event.xdata is not None:
            self._pan_start = (event.xdata, event.ydata,
                               self.ax.get_xlim(), self.ax.get_ylim())

    def _on_motion(self, event):
        if self._pan_start is None or event.xdata is None:
            return
        x0, y0, xl, yl = self._pan_start
        dx, dy = event.xdata - x0, event.ydata - y0
        self.ax.set_xlim(xl[0] - dx, xl[1] - dx)
        self.ax.set_ylim(yl[0] - dy, yl[1] - dy)
        self.canvas.draw_idle()

    def _on_release(self, event):
        if event.button == 3:
            self._xlim = self.ax.get_xlim()
            self._ylim = self.ax.get_ylim()
            self._pan_start = None

    def _start_draw(self):
        from matplotlib.widgets import EllipseSelector, RectangleSelector, LassoSelector
        if self._selector:
            try:
                self._selector.set_active(False)
            except Exception:
                pass
        shape = self.shape_combo.currentText()
        if "Rectangle" in shape:
            self._selector = RectangleSelector(
                self.ax, self._on_rect,
                useblit=True, button=[1],
                minspanx=3, minspany=3, spancoords="pixels", interactive=True)
        elif "Freehand" in shape:
            self._selector = LassoSelector(self.ax, self._on_lasso, button=[1])
        else:
            self._selector = EllipseSelector(
                self.ax, self._on_ellipse,
                useblit=True, button=[1],
                minspanx=3, minspany=3, spancoords="pixels", interactive=True)
        self.canvas.draw_idle()

    def _on_rect(self, eclick, erelease):
        x1 = max(0, int(min(eclick.xdata, erelease.xdata)))
        y1 = max(0, int(min(eclick.ydata, erelease.ydata)))
        x2 = min(self._W, int(max(eclick.xdata, erelease.xdata)))
        y2 = min(self._H, int(max(eclick.ydata, erelease.ydata)))
        m  = np.zeros((self._H, self._W), dtype=bool)
        m[y1:y2, x1:x2] = True
        self._mask = m
        self.confirm_btn.setEnabled(True)

    def _on_ellipse(self, eclick, erelease):
        cx = (eclick.xdata + erelease.xdata) / 2
        cy = (eclick.ydata + erelease.ydata) / 2
        rx = abs(erelease.xdata - eclick.xdata) / 2
        ry = abs(erelease.ydata - eclick.ydata) / 2
        yg, xg = np.ogrid[:self._H, :self._W]
        self._mask = ((xg - cx)**2 / (rx+1e-9)**2 +
                      (yg - cy)**2 / (ry+1e-9)**2) <= 1.0
        self.confirm_btn.setEnabled(True)

    def _on_lasso(self, verts):
        from matplotlib.path import Path as MplPath
        path = MplPath(verts)
        xg, yg = np.meshgrid(np.arange(self._W), np.arange(self._H))
        pts = np.column_stack([xg.ravel(), yg.ravel()])
        self._mask = path.contains_points(pts).reshape(self._H, self._W)
        self.confirm_btn.setEnabled(True)

    @property
    def roi_mask(self):
        return self._mask


# ══════════════════════════════════════════════════════════════════════════════
#  Frame viewer widget
# ══════════════════════════════════════════════════════════════════════════════

class FrameViewerWidget(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(2)

        self.fig, self.ax = plt.subplots(figsize=(4, 4))
        self.fig.patch.set_facecolor("#152A3C")
        self.canvas = FigureCanvas(self.fig)
        self.canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        layout.addWidget(self.canvas, stretch=1)

        slider_row = QHBoxLayout()
        self._frame_lbl = _lbl("—", size=8)
        self._slider = QSlider(Qt.Horizontal)
        self._slider.setMinimum(0)
        self._slider.setMaximum(0)
        self._slider.setEnabled(False)
        self._slider.setFont(ARIAL_SM)
        slider_row.addWidget(_lbl("Frame:", size=8))
        slider_row.addWidget(self._slider, stretch=1)
        slider_row.addWidget(self._frame_lbl)
        layout.addLayout(slider_row)

        self._video = None
        self._slider.valueChanged.connect(self._on_slider)

        self.ax.set_facecolor("#152A3C")
        self.ax.text(0.5, 0.5, "No video loaded", color="#A9BDCD",
                     ha="center", va="center", transform=self.ax.transAxes,
                     fontsize=10, fontfamily="DejaVu Sans")
        self.ax.axis("off")
        self.canvas.draw()

    def load(self, video: np.ndarray):
        self._video = video
        self._slider.setMaximum(video.shape[2] - 1)
        self._slider.setValue(0)
        self._slider.setEnabled(True)
        self._show(0)

    def _on_slider(self, val):
        if self._video is not None:
            self._show(val)

    def _show(self, idx):
        self._frame_lbl.setText(f"{idx + 1} / {self._video.shape[2]}")
        self.ax.cla()
        self.ax.imshow(self._video[:, :, idx], cmap="gray",
                       aspect="equal", interpolation="nearest")
        self.ax.set_title(f"Loaded Frame  [{idx}]", fontsize=9, color="white")
        self.ax.axis("off")
        self.fig.tight_layout(pad=0.3)
        self.canvas.draw_idle()


# ══════════════════════════════════════════════════════════════════════════════
#  Activation Map panel
# ══════════════════════════════════════════════════════════════════════════════

class ActMapPanel(QWidget):
    def __init__(self):
        super().__init__()
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)

        self.frame_viewer = FrameViewerWidget()
        layout.addWidget(self.frame_viewer, stretch=1)

        mid = QWidget()
        mid_layout = QVBoxLayout(mid)
        mid_layout.setContentsMargins(0, 0, 0, 0)
        self.fig_mask, self.ax_mask = plt.subplots(figsize=(4, 4))
        self.fig_mask.patch.set_facecolor("#152A3C")
        self.canvas_mask = FigureCanvas(self.fig_mask)
        mid_layout.addWidget(self.canvas_mask)
        self._init_placeholder(self.ax_mask, "ROI Mask")
        layout.addWidget(mid, stretch=1)

        right = QWidget()
        right_layout = QVBoxLayout(right)
        right_layout.setContentsMargins(0, 0, 0, 0)
        self.fig_map = plt.figure(figsize=(6, 5))
        self.ax_map  = self.fig_map.add_axes([0.12, 0.20, 0.68, 0.68])
        self.ax_cbar = self.fig_map.add_axes([0.84, 0.15, 0.04, 0.70])
        self.canvas_map = FigureCanvas(self.fig_map)
        self.canvas_map.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        right_layout.addWidget(self.canvas_map)
        self._cbar = None
        self.ax_cbar.set_visible(False)
        self._init_placeholder(self.ax_map, "Activation Map")
        layout.addWidget(right, stretch=3)

    def _init_placeholder(self, ax, title):
        ax.figure.patch.set_facecolor("#152A3C")
        ax.set_facecolor("#152A3C")
        ax.text(0.5, 0.5, title, color="#A9BDCD",
                ha="center", va="center", transform=ax.transAxes,
                fontsize=10, fontfamily="DejaVu Sans")
        ax.axis("off")
        try:
            if ax.figure.get_axes() and all(
                a.get_subplotspec() is not None for a in ax.figure.get_axes()
            ):
                ax.figure.tight_layout(pad=0.3)
        except Exception:
            pass
        if ax.figure.canvas:
            ax.figure.canvas.draw()

    def load_video(self, video: np.ndarray):
        self.frame_viewer.load(video)

    def show_mask(self, frame: np.ndarray, mask: np.ndarray):
        from scipy.ndimage import binary_erosion
        self.ax_mask.cla()
        self.ax_mask.imshow(frame, cmap="gray", aspect="equal")
        boundary = mask & ~binary_erosion(mask)
        overlay  = np.zeros((*frame.shape, 4))
        overlay[boundary] = [1, 0.2, 0.2, 0.95]
        self.ax_mask.imshow(overlay)
        self.ax_mask.set_title("ROI mask", fontsize=9, color="white")
        self.ax_mask.axis("off")
        self.fig_mask.tight_layout(pad=0.3)
        self.canvas_mask.draw_idle()

    def show_arc_plot(self, arc_result):
        """
        Chip mode: overlay arc-length activation scatter + linear fit
        on the right-side activation map axes.
        Draws in a new figure popped as a small dialog (non-blocking).
        """
        import matplotlib.pyplot as plt
        from scipy.stats import linregress

        s = arc_result.arc_s
        t = arc_result.act_t * 1000   # → ms

        fig, ax = plt.subplots(figsize=(5, 3.5))
        fig.patch.set_facecolor("#152A3C")
        ax.set_facecolor("#152A3C")

        valid = ~__import__("numpy").isnan(t)
        ax.scatter(s[valid], t[valid], s=12, color="#4FC3F7", alpha=0.7,
                   label="Skeleton pixels", zorder=3)

        if valid.sum() >= 4:
            slope, intercept, r, *_ = linregress(s[valid], t[valid])
            s_fit = __import__("numpy").linspace(s[valid].min(), s[valid].max(), 200)
            t_fit = slope * s_fit + intercept
            cv = 1.0 / slope if abs(slope) > 1e-9 else float("nan")
            ax.plot(s_fit, t_fit, color="#FF7043", linewidth=1.8, zorder=4,
                    label=f"CV = {cv:.1f} mm/s  (R²={r**2:.3f})")

        ax.set_xlabel("Arc-length s  (mm)", color="white", fontsize=9)
        ax.set_ylabel("Activation time  (ms)", color="white", fontsize=9)
        ax.set_title("Chip Arc-Length Activation Plot", color="white", fontsize=10)
        ax.tick_params(colors="white")
        ax.spines[:].set_color("#444444")
        ax.legend(fontsize=8, labelcolor="white",
                  facecolor="#2a2a3e", edgecolor="#444444")
        fig.tight_layout(pad=0.8)

        # Embed in a small floating dialog so it doesn't block the main window
        from PyQt5.QtWidgets import QDialog, QVBoxLayout
        from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FC
        dlg = QDialog(self)
        dlg.setWindowTitle("Arc-Length Plot  —  Chip Mode")
        dlg.resize(520, 360)
        dlg_layout = QVBoxLayout(dlg)
        dlg_layout.addWidget(FC(fig))
        dlg.show()   # non-blocking
        # Keep reference so Python GC doesn't kill it
        if not hasattr(self, "_arc_dialogs"):
            self._arc_dialogs = []
        self._arc_dialogs.append(dlg)

    def show_map(self, act_result: ActivationResult, show_vectors=False):
        hires_ms, X_mm, Y_mm, mask_hr = prepare_hires_map(
            act_result.act_map, act_result.mask, act_result.px_to_mm)
        display = np.where(mask_hr, hires_ms, np.nan)

        self.fig_map.patch.set_facecolor("white")
        self.ax_map.cla()
        self.ax_map.set_facecolor("white")
        if self._cbar:
            try:
                self._cbar.remove()
            except Exception:
                pass

        im = self.ax_map.imshow(
            display,
            extent=[X_mm[0], X_mm[-1], Y_mm[-1], Y_mm[0]],
            cmap=ICAM_CMAP, origin="upper", aspect="equal")
        try:
            self.ax_cbar.cla()
        except Exception:
            self.ax_cbar = self.fig_map.add_axes([0.84, 0.15, 0.04, 0.70])
        self.ax_cbar.set_visible(True)
        self._cbar = self.fig_map.colorbar(im, cax=self.ax_cbar)
        self._cbar.set_label("Delay (ms)", fontsize=8)
        self._cbar.ax.tick_params(labelsize=7)

        if show_vectors:
            from core.activation_mapping import _fill_missing
            from scipy.ndimage import gaussian_filter
            filled   = _fill_missing(act_result.act_map)
            smoothed = gaussian_filter(filled, sigma=2.0)
            py, px_g = np.gradient(smoothed)
            mag = np.sqrt(px_g**2 + py**2) + 1e-9
            u = px_g / mag;  v = py / mag
            u[~act_result.mask] = np.nan
            v[~act_result.mask] = np.nan
            H, W = act_result.act_map.shape
            step  = 8
            ys = np.arange(0, H, step)
            xs = np.arange(0, W, step)
            Xs, Ys = np.meshgrid(xs * act_result.px_to_mm,
                                  ys * act_result.px_to_mm)
            self.ax_map.quiver(Xs, Ys, u[::step, ::step], -v[::step, ::step],
                               color="white", scale=30, width=0.003)

        self.ax_map.set_title(
            f"Activation Map  |  CV: {act_result.cv_mm_s:.2f} mm/s"
            f"  |  Delay: {act_result.max_delay_ms:.1f} ms", fontsize=9)
        self.ax_map.set_xlabel("Distance (mm)", fontsize=8)
        self.ax_map.set_ylabel("Distance (mm)", fontsize=8)
        self.canvas_map.draw_idle()


# ══════════════════════════════════════════════════════════════════════════════
#  Kinetics panel
# ══════════════════════════════════════════════════════════════════════════════

class KineticsPanel(QWidget):
    def __init__(self):
        super().__init__()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        self.fig, axes = plt.subplots(2, 2, figsize=(10, 6))
        self.ax_raw, self.ax_norm, self.ax_vel, self.ax_kin = axes.ravel()
        for ax, title in zip(axes.ravel(), ["Raw trace", "Normalized signal (ΔF/F₀)",
                                           "Calcium flux velocity", "Averaged transient"]):
            ax.set_title(title)
            ax.set_xticks([])
            ax.set_yticks([])
            ax.text(0.5, 0.5, "Awaiting signal", transform=ax.transAxes,
                    ha="center", va="center", color="#98A8B8", fontsize=9)
        self.canvas = FigureCanvas(self.fig)
        layout.addWidget(self.canvas)
        self.fig.set_layout_engine("tight", pad=1.8)

    def plot_raw(self, frames, signal):
        self.ax_raw.cla()
        self.ax_raw.plot(frames, signal, color="#087F8C", linewidth=0.9)
        self.ax_raw.set_title("Raw Trace")
        self.ax_raw.set_xlabel("Frames")
        self.ax_raw.set_ylabel("Intensity (AU)")
        self.ax_raw.grid(True, alpha=0.25)
        self.fig.set_layout_engine("tight", pad=1.8)
        self.canvas.draw_idle()

    def plot_results(self, result: KineticsResult, fps: float, signal: np.ndarray):
        t  = np.arange(len(signal)) / fps
        sy = np.sort(signal)
        bl = np.mean(sy[:max(1, round(len(sy) * 0.1))])
        bl = bl if bl > 0 else np.min(signal[signal > 0])
        dff   = (signal - bl) / bl
        dff_s = safe_sg(dff, 3, 11)

        self.ax_norm.cla()
        self.ax_norm.axhline(0, linestyle="--", color="#AAAAAA", linewidth=0.7)
        self.ax_norm.plot(t, dff_s, color="#087F8C", linewidth=1.2)
        self.ax_norm.set_title("Normalized Signal (ΔF/F₀)")
        self.ax_norm.set_xlabel("Time (s)");  self.ax_norm.set_ylabel("ΔF/F₀")
        if dff_s.max() > 0:
            self.ax_norm.set_ylim(dff_s.min() * 1.2, dff_s.max() * 1.3)
        self.ax_norm.grid(True, alpha=0.25)

        dy_dt   = np.append(np.diff(dff_s), 0) * fps
        win_dy  = max(5, 2 * int(fps * 0.03) + 1)
        dy_filt = safe_sg(dy_dt, 3, win_dy)
        self.ax_vel.cla()
        self.ax_vel.plot(t, dy_filt, color="#087F8C", linewidth=0.9)
        self.ax_vel.set_title("Ca²⁺ Flux Velocity")
        self.ax_vel.set_xlabel("Time (s)");  self.ax_vel.set_ylabel("d(ΔF/F₀)/dt (s⁻¹)")
        self.ax_vel.grid(True, alpha=0.25)

        self.ax_kin.cla()
        for col in result.all_transients:
            self.ax_kin.plot(result.avg_time, col, color="#DDDDDD", linewidth=0.4)
        self.ax_kin.plot(result.avg_time, result.avg_signal,
                         color="#111111", linewidth=2.2, label="Average")
        self.ax_kin.axhline(0, linestyle="--", color="#AAAAAA", linewidth=0.7)
        self.ax_kin.set_title("Kinetics Analysis")
        self.ax_kin.set_xlabel("Time (s)");  self.ax_kin.set_ylabel("ΔF/F₀")
        self.ax_kin.grid(True, alpha=0.15)

        self.fig.set_layout_engine("tight", pad=1.8)
        self.canvas.draw_idle()


# ══════════════════════════════════════════════════════════════════════════════
#  Main window
# ══════════════════════════════════════════════════════════════════════════════

class MainWindow(QMainWindow):
    def __init__(self, analysis_type: str = "fluorescence"):
        super().__init__()
        self._analysis_type = analysis_type   # "fluorescence" | "brightfield"

        mode_label = ("Ca²⁺ Fluorescence" if analysis_type == "fluorescence"
                      else "Brightfield Motion")
        self.setWindowTitle(
            f"iCAMAnalyzer — {mode_label}")
        self.resize(1440, 920)
        self.setMinimumSize(1080, 680)
        screen = QApplication.primaryScreen()
        if screen and screen.availableGeometry().width() >= 1100:
            available = screen.availableGeometry()
            self.resize(min(1440, available.width() - 40),
                        max(680, min(920, available.height() - 60)))
        self.setFont(ARIAL)
        self.setStatusBar(QStatusBar())
        self.statusBar().setFont(ARIAL_SM)

        self._load_worker: QThread | None = None
        self._map_worker:  QThread | None = None
        self._video_data   = None
        self._roi_mask     = None
        self._roi_data     = None
        self._org_mask     = None
        self._signal_data  = None
        self._frame_data   = None
        self._kinetics     = None
        self._act_result   = None
        self._arc_result   = None   # ChipArcResult (chip mode only)
        self._fps_o        = 250.0
        self._fps_analysis = 250.0
        self._px_to_mm     = 1 / 7.8
        self._sample_type  = "organoid"   # "organoid" | "chip"
        self._chip_template_img = None    # loaded template image for chip auto-mask

        self._build_ui()

    # ──────────────────────────────────────────
    #  Worker lifecycle helper
    # ──────────────────────────────────────────

    @staticmethod
    def _stop_worker(worker):
        """Gracefully stop a QThread worker before replacing it."""
        if worker is not None and worker.isRunning():
            worker.quit()
            if not worker.wait(2000):
                worker.terminate()
                worker.wait(500)

    # ──────────────────────────────────────────
    #  UI layout
    # ──────────────────────────────────────────

    def _build_ui(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        banner = QWidget()
        banner.setObjectName("appHeader")
        banner.setAttribute(Qt.WA_StyledBackground, True)
        bl = QHBoxLayout(banner)
        bl.setContentsMargins(22, 14, 22, 14)
        bl.setSpacing(14)
        bl.addWidget(SignalMark())
        brand = QVBoxLayout()
        brand.setSpacing(3)
        title = QLabel("iCAMAnalyzer")
        title.setObjectName("brandTitle")
        sub = QLabel("CALCIUM  +  MOTION ANALYSIS")
        sub.setObjectName("brandSubtitle")
        brand.addWidget(title)
        brand.addWidget(sub)
        bl.addLayout(brand)
        bl.addStretch()
        badge = QLabel("FLUORESCENCE" if self._analysis_type == "fluorescence" else "BRIGHTFIELD")
        badge.setObjectName("modeBadge")
        bl.addWidget(badge)
        switch_btn = button("Switch workspace")
        switch_btn.setObjectName("switchMode")
        switch_btn.clicked.connect(self._switch_mode)
        bl.addWidget(switch_btn)
        root.addWidget(banner)

        self.tabs = QTabWidget()
        self.tabs.tabBar().hide()
        root.addWidget(self.tabs, stretch=1)
        if self._analysis_type == "fluorescence":
            self._build_ca2_tab()
        else:
            self._build_bf_tab()
        self.statusBar().showMessage("Ready  ·  Load a recording to begin")

    def _build_ca2_tab(self):
        """Presentation-only layout; callbacks and data processing are unchanged."""
        ca2_widget = QWidget()
        root = QHBoxLayout(ca2_widget)
        root.setContentsMargins(16, 16, 16, 12)
        root.setSpacing(12)
        sidebar = QWidget()
        sidebar.setMinimumWidth(260)
        sidebar.setMaximumWidth(320)
        controls = QVBoxLayout(sidebar)
        controls.setContentsMargins(0, 0, 8, 0)
        controls.setSpacing(12)
        controls.addWidget(label("ANALYSIS WORKFLOW", True, 9, "eyebrow"))

        data = QGroupBox("01  /  Input data")
        dl = QVBoxLayout(data)
        dl.setSpacing(8)
        dl.addWidget(label("Sample type", size=9, role="muted"))
        self.cmb_sample_type = QComboBox()
        self.cmb_sample_type.addItems(["Organoid (spherical)", "Patterned chip"])
        self.cmb_sample_type.currentIndexChanged.connect(self._on_sample_type_changed)
        dl.addWidget(self.cmb_sample_type)
        self.btn_load = button("Load video", role="primary", bold=True)
        self.btn_load_trace = button("Load trace (.csv / .xlsx)")
        dl.addWidget(self.btn_load)
        dl.addWidget(self.btn_load_trace)
        self.btn_load_template = button("Load chip template")
        self.btn_load_template.setVisible(False)
        self.btn_load_template.clicked.connect(self._load_chip_template)
        self.lbl_template_status = label("No template loaded", size=9, role="muted")
        self.lbl_template_status.setWordWrap(True)
        self.lbl_template_status.setVisible(False)
        dl.addWidget(self.btn_load_template)
        dl.addWidget(self.lbl_template_status)
        controls.addWidget(data)

        region = QGroupBox("02  /  Region + calibration")
        rl = QVBoxLayout(region)
        rl.setSpacing(8)
        self.btn_roi = button("Select ROI")
        self.btn_confirm = button("Confirm ROI")
        self.btn_calib = button("Pixel calibration")
        for w in [self.btn_roi, self.btn_confirm, self.btn_calib]:
            rl.addWidget(w)
        controls.addWidget(region)

        analysis = QGroupBox("03  /  Analyze")
        al = QVBoxLayout(analysis)
        al.setSpacing(8)
        self.btn_map = button("Map calcium activation", role="primary", bold=True)
        self.btn_analyze = button("Analyze transients", role="primary", bold=True)
        self.chk_vec = QCheckBox("Show propagation vectors")
        al.addWidget(self.btn_map)
        al.addWidget(self.chk_vec)
        al.addWidget(self.btn_analyze)
        controls.addWidget(analysis)

        export = QGroupBox("04  /  Export")
        el = QVBoxLayout(export)
        el.setSpacing(8)
        self.btn_expmap = button("Export activation map")
        self.btn_export_excel = button("Export Excel")
        self.btn_export_img = button("Export images")
        for w in [self.btn_expmap, self.btn_export_excel, self.btn_export_img]:
            el.addWidget(w)
        controls.addWidget(export)
        controls.addStretch()
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setWidget(sidebar)
        scroll.setMinimumWidth(280)
        scroll.setMaximumWidth(336)
        root.addWidget(scroll)

        splitter = QSplitter(Qt.Vertical)
        splitter.setHandleWidth(12)
        splitter.setChildrenCollapsible(False)
        top, tl, self.lbl_step1 = card("Calcium activation mapping",
            "Organoid  ·  Frame, region of interest and spatial activation")
        self.act_panel = ActMapPanel()
        tl.addWidget(self.act_panel, stretch=1)
        splitter.addWidget(top)

        bottom, bl, _ = card("Transient kinetics", "Signal dynamics and beat-to-beat parameters")
        content = QHBoxLayout()
        content.setSpacing(12)
        self.kin_panel = KineticsPanel()
        content.addWidget(self.kin_panel, stretch=3)
        self.result_table = QTableWidget(0, 2)
        self.result_table.setFont(font(9))
        self.result_table.setHorizontalHeaderLabels(["Parameter", "Value"])
        self.result_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.result_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.result_table.setMinimumWidth(240)
        self.result_table.setMaximumWidth(300)
        style_table(self.result_table, editable=False)
        content.addWidget(self.result_table)
        bl.addLayout(content, stretch=1)
        splitter.addWidget(bottom)
        splitter.setSizes([350, 410])
        root.addWidget(splitter, stretch=1)
        self.tabs.addTab(ca2_widget, "Calcium analysis")

        self.btn_load.clicked.connect(self._load_video)
        self.btn_roi.clicked.connect(self._select_roi)
        self.btn_confirm.clicked.connect(self._confirm_roi)
        self.btn_map.clicked.connect(self._create_map)
        self.btn_calib.clicked.connect(self._set_calib)
        self.chk_vec.stateChanged.connect(self._refresh_map)
        self.btn_expmap.clicked.connect(self._export_map)
        self.btn_load_trace.clicked.connect(self._load_trace)
        self.btn_analyze.clicked.connect(self._analyze)
        self.btn_export_excel.clicked.connect(self._export_excel)
        self.btn_export_img.clicked.connect(self._export_images)

    # ──────────────────────────────────────────
    #  Sample type switching
    # ──────────────────────────────────────────

    def _on_sample_type_changed(self, idx):
        """Switch between Organoid and Patterned Chip modes."""
        self._sample_type = "chip" if idx == 1 else "organoid"
        is_chip = (self._sample_type == "chip")

        # Update header label
        if is_chip:
            self.lbl_step1.setText(
                "Calcium activation mapping · Patterned chip")
        else:
            self.lbl_step1.setText(
                "Calcium activation mapping · Organoid")

        # Show/hide chip-specific controls
        self.btn_load_template.setVisible(is_chip)
        self.lbl_template_status.setVisible(is_chip)

        # Reset derived state so we don't mix modes
        self._org_mask      = None
        self._act_result    = None
        self._arc_result    = None
        self._chip_template_img = None
        self.lbl_template_status.setText("No template loaded")
        self.statusBar().showMessage(
            f"Mode: {'Patterned Chip' if is_chip else 'Organoid'}  —  reload ROI to apply.")

    def _load_chip_template(self):
        """Load yellow chip image as template for auto-masking."""
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Chip Template Image", "",
            "Images (*.png *.jpg *.bmp *.tif *.tiff)")
        if not path:
            return
        img = cv2.imread(path)
        if img is None:
            QMessageBox.critical(self, "Error", "Could not load image.")
            return
        self._chip_template_img = img
        fname = Path(path).name
        self.lbl_template_status.setText(f"✔  {fname}")
        self.lbl_template_status.setStyleSheet("color: #1a7a1a;")
        self.statusBar().showMessage(f"Chip template loaded: {fname}")

    def _build_bf_tab(self):
        """Brightfield Contractility tab"""
        self.contractility_tab = ContractilityTab()
        self.tabs.addTab(self.contractility_tab, "🫀  Contractility")

    # ──────────────────────────────────────────
    #  Mode switching
    # ──────────────────────────────────────────

    def _switch_mode(self):
        dlg = AnalysisTypeDialog(self)
        if dlg.exec_() == QDialog.Accepted:
            new_type = dlg.choice
            if new_type != self._analysis_type:
                # Relaunch with new mode.
                # IMPORTANT: keep a reference on the *application* level
                # (via a module-level/global list), otherwise Python's GC
                # collects the new MainWindow as soon as this method
                # returns, which immediately destroys the new window too
                # (since nothing else holds a reference to it) — this is
                # what caused "the screen just goes blank" on Switch Mode.
                new_win = MainWindow(analysis_type=new_type)
                _OPEN_WINDOWS.append(new_win)
                new_win.show()
                self.close()

    # ──────────────────────────────────────────
    #  Ca²⁺ callbacks (Fluorescence mode only)
    # ──────────────────────────────────────────

    def _load_video(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Video", "",
            "Video files (*.avi *.mp4 *.tif *.tiff)")
        if not path:
            return
        fps_val, ok = QInputDialog.getDouble(
            self, "FPS", "Frames per second:", 250, 1, 10000, 1)
        if not ok:
            return
        self._fps_o = fps_val

        prog = QProgressDialog("Loading video…", None, 0, 100, self)
        prog.setFont(ARIAL)
        prog.setWindowModality(Qt.WindowModal)
        prog.show()

        self._stop_worker(self._load_worker)
        self._load_worker = VideoLoadWorker(path)
        self._load_worker.progress.connect(prog.setValue)
        self._load_worker.finished.connect(lambda d: (prog.close(),
                                                       self._on_loaded(d)))
        self._load_worker.error.connect(
            lambda e: QMessageBox.critical(self, "Error", e))
        self._load_worker.start()

    def _on_loaded(self, data):
        self._video_data = data
        self.act_panel.load_video(data)
        H, W, F = data.shape
        self.statusBar().showMessage(
            f"Loaded:  {F} frames  |  {W} × {H} px  |  FPS = {self._fps_o}")

    def _set_calib(self):
        dlg = CalibDialog(self, self._px_to_mm)
        if dlg.exec_() == QDialog.Accepted:
            self._px_to_mm = dlg.value
            self.statusBar().showMessage(
                f"Calibration:  {self._px_to_mm:.6f} mm/px")

    def _select_roi(self):
        if self._video_data is None:
            QMessageBox.warning(self, "No video", "Load a video first.")
            return
        dlg = ROISelectorDialog(self._video_data, self)
        if dlg.exec_() == QDialog.Accepted and dlg.roi_mask is not None:
            self._roi_mask = dlg.roi_mask
            self.statusBar().showMessage(
                "ROI selected — click Confirm ROI")

    def _confirm_roi(self):
        if self._roi_mask is None or self._video_data is None:
            QMessageBox.warning(self, "No ROI", "Select a ROI first.")
            return
        ys, xs = np.where(self._roi_mask)
        if len(ys) == 0:
            QMessageBox.warning(self, "Empty ROI", "ROI is empty — redraw.")
            return
        y0, y1 = ys.min(), ys.max() + 1
        x0, x1 = xs.min(), xs.max() + 1
        self._roi_data = self._video_data[y0:y1, x0:x1, :]
        shape_mask     = self._roi_mask[y0:y1, x0:x1]

        # ── Mask building: branch on sample type ─────────────────────────────
        if self._sample_type == "chip":
            self._org_mask = self._build_chip_mask_with_fallback(shape_mask)
        else:
            self._org_mask = build_organoid_mask(self._roi_data, shape_mask)

        self.act_panel.show_mask(self._roi_data[:, :, 0], self._org_mask)
        F     = self._roi_data.shape[2]
        trace = np.array([self._roi_data[:, :, f][self._org_mask].mean()
                          for f in range(F)])
        self._signal_data = trace
        self._frame_data  = np.arange(F)
        self.kin_panel.plot_raw(self._frame_data, self._signal_data)
        mode_str = "Chip" if self._sample_type == "chip" else "Organoid"
        self.statusBar().showMessage(
            f"ROI confirmed [{mode_str}]  —  trace extracted  |  ready for Map Activation")

    def _build_chip_mask_with_fallback(self, shape_mask: np.ndarray) -> np.ndarray:
        """
        Build chip mask using template (auto) if available,
        falling back to activity-based auto-mask if template match fails,
        then optionally letting user redraw if both fail.
        """
        # ① Try template-based auto-mask
        if self._chip_template_img is not None:
            frame0 = self._roi_data[:, :, 0]
            mask_t = build_chip_mask_from_template(frame0, self._chip_template_img,
                                                    shape_mask)
            if mask_t is not None and mask_t.sum() > 50:
                self.statusBar().showMessage(
                    "Chip mask: template matched ✔")
                return mask_t
            else:
                QMessageBox.warning(
                    self, "Template Match Failed",
                    "Could not match template to video frame.\n"
                    "Falling back to activity-based auto-mask.")

        # ② Activity-based auto-mask (STD + Mean combined)
        mask_a = build_chip_mask_auto(self._roi_data, shape_mask,
                                       activity_weight=0.6)
        if mask_a.sum() > 50:
            self.statusBar().showMessage(
                "Chip mask: activity-based auto-mask used.")
            return mask_a

        # ③ Ultimate fallback: just use the drawn shape polygon
        QMessageBox.information(
            self, "Mask Fallback",
            "Auto-masking returned an empty result.\n"
            "Using your drawn polygon as the mask.")
        return shape_mask.astype(bool)

    def _create_map(self):
        if self._roi_data is None or self._org_mask is None:
            QMessageBox.warning(self, "No ROI", "Confirm ROI first.")
            return
        self.btn_map.setEnabled(False)
        self.btn_map.setText("Computing…")
        self._stop_worker(self._map_worker)
        self._map_worker = ActMapWorker(
            self._roi_data, self._org_mask, self._fps_o, self._px_to_mm)
        self._map_worker.finished.connect(self._on_map_done)
        self._map_worker.error.connect(self._on_map_error)
        self._map_worker.start()

    def _on_map_done(self, result):
        self._act_result = result
        self.btn_map.setEnabled(True)
        self.btn_map.setText("Map calcium activation")
        self.act_panel.show_map(result, show_vectors=self.chk_vec.isChecked())

        # ── Chip mode: arc-length CV plot ─────────────────────────────────────
        if self._sample_type == "chip":
            try:
                arc_res = compute_arc_length_cv(
                    result.act_map, result.mask, result.px_to_mm)
                self._arc_result = arc_res
                self.act_panel.show_arc_plot(arc_res)
            except Exception as e:
                self._arc_result = None
                self.statusBar().showMessage(f"Arc-length plot failed: {e}")

        self._refresh_table()
        win_sz = 2 * result.window_radius + 1
        arc_info = ""
        if self._sample_type == "chip" and self._arc_result is not None:
            arc_info = (f"  |  Arc CV: {self._arc_result.cv_mm_s:.2f} mm/s"
                        f"  R²={self._arc_result.r_squared:.3f}")
        self.statusBar().showMessage(
            f"Done  |  CV: {result.cv_mm_s:.2f} mm/s  "
            f"|  Max delay: {result.max_delay_ms:.1f} ms  "
            f"|  Bayly window: {win_sz}×{win_sz}"
            f"{arc_info}")

    def _on_map_error(self, msg):
        self.btn_map.setEnabled(True)
        self.btn_map.setText("Map calcium activation")
        QMessageBox.critical(self, "Mapping error", msg)

    def _refresh_map(self):
        if self._act_result:
            self.act_panel.show_map(self._act_result,
                                     self.chk_vec.isChecked())

    def _export_map(self):
        if not self._act_result:
            QMessageBox.warning(self, "No map", "Run activation mapping first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Activation Map", "activation_map",
            "PNG (*.png);;TIFF (*.tif);;PDF (*.pdf)")
        if path:
            export_activation_map(path, self._act_result,
                                   show_vectors=self.chk_vec.isChecked())
            QMessageBox.information(self, "Saved", path)

    def _load_trace(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select Trace", "", "Data (*.csv *.xlsx *.xls)")
        if not path:
            return
        try:
            if path.lower().endswith(".csv"):
                data = np.genfromtxt(path, delimiter=",")
            else:
                import openpyxl
                wb = openpyxl.load_workbook(path, data_only=True)
                ws = wb.active
                data = np.array([[c.value for c in row]
                                  for row in ws.iter_rows()], dtype=float)
            self._signal_data = data[:, 1]
            self._frame_data  = data[:, 0]
            self.kin_panel.plot_raw(self._frame_data, self._signal_data)
            self.statusBar().showMessage(f"Trace loaded: {len(self._signal_data)} frames")
        except Exception as e:
            QMessageBox.critical(self, "Load error", str(e))

    def _analyze(self):
        if self._signal_data is None:
            QMessageBox.warning(self, "No data", "Load a trace first.")
            return
        fps_val, ok = QInputDialog.getDouble(
            self, "FPS", "Frames per second:", self._fps_analysis, 1, 10000, 1)
        if not ok:
            return
        self._fps_analysis = fps_val
        try:
            self._kinetics = analyze_transient(self._signal_data, fps_val)
        except ValueError as e:
            QMessageBox.critical(self, "Analysis error", str(e))
            return

        # ── Arrhythmia panel (alternans, beat irregularity, DAD, triggered)
        try:
            analyze_alternans(self._kinetics, ai_threshold=0.10)
        except Exception:
            pass
        try:
            analyze_beat_irregularity(self._kinetics)
        except Exception:
            pass
        try:
            detect_dad(self._kinetics, self._signal_data, fps_val)
        except Exception:
            pass
        try:
            detect_triggered_activity(self._kinetics)
        except Exception:
            pass

        if self._act_result:
            self._kinetics.cv_mm_s      = self._act_result.cv_mm_s
            self._kinetics.max_delay_ms = self._act_result.max_delay_ms
        self.kin_panel.plot_results(self._kinetics, fps_val, self._signal_data)
        self._refresh_table()
        self.statusBar().showMessage(
            f"Analysis complete  |  BPM: {self._kinetics.bpm:.1f}"
            f"  |  n = {self._kinetics.n_beats} beats")

    def _refresh_table(self):
        rows = []
        if self._kinetics:
            k = self._kinetics
            rows += [
                ("BPM",              f"{k.bpm:.1f}"),
                ("Amp (dF/F0)",      f"{k.amp_mean:.3f} ± {k.amp_sd:.3f}"),
                ("TTP (ms)",         f"{k.ttp_mean:.1f} ± {k.ttp_sd:.1f}"),
                ("CTD60 (ms)",       f"{k.ctd60_mean:.1f} ± {k.ctd60_sd:.1f}"),
                ("CTD90 (ms)",       f"{k.ctd90_mean:.1f} ± {k.ctd90_sd:.1f}"),
                ("Tau (ms)",         f"{k.tau_ms:.1f}"),
                ("Vmax (dF/F0/s)",   f"{k.vmax:.2f}"),
                ("Vrelax (dF/F0/s)", f"{k.vrelax:.2f}"),
                ("Vmax/Amp (s⁻¹)",   f"{k.vmax_norm:.2f}"),
                ("Vrelax/Amp (s⁻¹)", f"{k.vrelax_norm:.2f}"),
                ("TTP/CTD90 ratio",  f"{k.ttp_ctd90_ratio:.3f}"),
                ("Valid beats (n)",  str(k.n_beats)),
            ]
            # ── Arrhythmia panel ──────────────────────────
            if k.alternans is not None:
                a = k.alternans
                rows += [
                    ("Alternans AI (amp)",  f"{a.amp_ai:.3f}" +
                                             ("  ⚠ POSITIVE" if a.amp_alternans else "")),
                    ("Alternans AI (dur)",  f"{a.dur_ai:.3f}" +
                                             ("  ⚠ POSITIVE" if a.dur_alternans else "")),
                ]
            if not np.isnan(k.ibi_cv_pct):
                rows += [
                    ("IBI CV (%)",          f"{k.ibi_cv_pct:.1f}" +
                                             ("  ⚠ IRREGULAR" if k.ibi_cv_pct > 15 else "")),
                    ("Irregular beats (%)", f"{k.irregular_beat_pct:.1f}"),
                ]
            n_ead = sum(1 for b in k.beat_to_beat if b.ead_detected)
            if n_ead > 0:
                rows += [("EAD detected (beats)", f"{n_ead} / {k.n_beats}  ⚠")]
            if k.n_dad_beats > 0:
                rows += [("DAD detected (beats)", f"{k.n_dad_beats} / {k.n_beats}  ⚠")]
            if k.n_triggered > 0:
                rows += [("Triggered activity (n)", f"{k.n_triggered}  ⚠")]
        if self._act_result:
            ar = self._act_result
            win_sz = 2 * ar.window_radius + 1
            rows += [
                ("CV (mm/s)",           f"{ar.cv_mm_s:.2f}"),
                ("CV rough Pass-1",     f"{ar.cv_rough:.2f}"),
                ("Bayly window",        f"{win_sz}×{win_sz}  (r={ar.window_radius})"),
                ("IQR fence (mm/s)",    f"{ar.cv_iqr_lo:.1f} – {ar.cv_iqr_hi:.1f}"),
                ("Max delay (ms)",      f"{ar.max_delay_ms:.1f}"),
                ("px → mm",            f"{ar.px_to_mm:.6f}"),
            ]
        if self._arc_result is not None:
            arc = self._arc_result
            rows += [
                ("── Chip Arc-length ──", ""),
                ("Arc CV (mm/s)",       f"{arc.cv_mm_s:.2f}" if not __import__("numpy").isnan(arc.cv_mm_s) else "N/A"),
                ("Arc R²",              f"{arc.r_squared:.4f}" if not __import__("numpy").isnan(arc.r_squared) else "N/A"),
                ("Skeleton length (mm)",f"{float(arc.arc_s[-1]):.2f}" if len(arc.arc_s) else "N/A"),
            ]
        self.result_table.setRowCount(len(rows))
        for r, (name, val) in enumerate(rows):
            ni = QTableWidgetItem(name);  ni.setFont(ARIAL_SM)
            vi = QTableWidgetItem(val);   vi.setFont(ARIAL_SM)
            vi.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self.result_table.setItem(r, 0, ni)
            self.result_table.setItem(r, 1, vi)

    def _export_excel(self):
        if not self._kinetics:
            QMessageBox.warning(self, "No data", "Run analysis first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Excel", "iCAM_results.xlsx", "Excel (*.xlsx)")
        if path:
            export_excel(path, self._kinetics, self._act_result)
            QMessageBox.information(self, "Saved", path)

    def _export_images(self):
        if not self._kinetics or self._signal_data is None:
            QMessageBox.warning(self, "No data", "Run analysis first.")
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Save Images (base name)", "iCAM_figure",
            "PNG (*.png);;TIFF (*.tif);;PDF (*.pdf)")
        if not path:
            return
        base, ext = os.path.splitext(path)
        fps  = self._fps_analysis
        t    = np.arange(len(self._signal_data)) / fps
        sy   = np.sort(self._signal_data)
        bl   = np.mean(sy[:max(1, round(len(sy) * 0.1))])
        bl   = bl if bl > 0 else float(np.min(self._signal_data[self._signal_data > 0]))
        dff  = (self._signal_data - bl) / bl
        dff_s = safe_sg(dff, 3, 11)
        export_whole_trace(base + "_Whole" + ext, t, dff_s, fps)
        export_avg_transient(base + "_Average" + ext, self._kinetics)
        QMessageBox.information(self, "Saved",
            f"{base}_Whole{ext}\n{base}_Average{ext}")


# ══════════════════════════════════════════════════════════════════════════════
#  Entry point
# ══════════════════════════════════════════════════════════════════════════════

def launch():
    # ── Fix Windows DPI-scaling mismatch (desktop monitors often run a
    #    different scale % than laptops, which can squish/overlap the
    #    matplotlib panels and Qt widgets). Must run BEFORE QApplication
    #    is created. ──────────────────────────────────────────────────
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(2)  # per-monitor DPI aware
        except Exception:
            try:
                import ctypes
                ctypes.windll.user32.SetProcessDPIAware()
            except Exception:
                pass

    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    install_theme(app)

    # ── Startup modal ──────────────────────────────────────────────────────
    dlg = AnalysisTypeDialog()
    if dlg.exec_() != QDialog.Accepted:
        sys.exit(0)   # 사용자가 X 버튼으로 닫으면 종료

    win = MainWindow(analysis_type=dlg.choice)
    win.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    launch()
