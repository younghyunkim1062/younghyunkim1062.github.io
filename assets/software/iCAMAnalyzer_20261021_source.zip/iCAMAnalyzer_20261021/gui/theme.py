"""Shared presentation layer. No scientific calculations live in this module."""
import sys
from pathlib import Path
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont, QPalette, QColor, QPainter, QPainterPath, QPen
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QPushButton,
                             QVBoxLayout, QHBoxLayout, QTableWidget, QHeaderView)

FONT_FAMILY = "Segoe UI" if sys.platform.startswith("win") else "DejaVu Sans"
INK = "#183047"
MUTED = "#6D7D8E"
TEAL = "#087F8C"
NAVY = "#142C43"
SURFACE = "#FFFFFF"
CANVAS = "#F2F5F9"


def font(size=10, bold=False):
    return QFont(FONT_FAMILY, size, QFont.DemiBold if bold else QFont.Normal)


def label(text, bold=False, size=10, role=None):
    widget = QLabel(text)
    widget.setFont(font(size, bold))
    if role:
        widget.setProperty("role", role)
    return widget


def button(text, color=None, bold=False, role=None):
    # Older callers used pastel fills to denote actions. Keep their semantics
    # while giving the whole application one consistent visual language.
    text = text.lstrip("📂🔬💾🔍✏️✔↺↻▶🫀⇄⬛↓✕ ")
    widget = QPushButton(text)
    widget.setFont(font(10, bold))
    widget.setCursor(Qt.PointingHandCursor)
    widget.setMinimumHeight(34)
    if role is None:
        role = "primary" if color == "#d4f0d4" else "secondary"
    widget.setProperty("role", role)
    return widget


def style_table(table, editable=True):
    table.setAlternatingRowColors(True)
    table.setShowGrid(False)
    table.verticalHeader().setVisible(False)
    table.verticalHeader().setDefaultSectionSize(30)
    table.horizontalHeader().setMinimumSectionSize(40)
    table.setSelectionBehavior(QTableWidget.SelectRows)
    if not editable:
        table.setEditTriggers(QTableWidget.NoEditTriggers)
    def describe(item):
        if not item.toolTip():
            item.setToolTip(item.text())
    if not editable:
        table.itemChanged.connect(describe)


class SignalMark(QWidget):
    """A resolution-independent mark drawn by Qt; no external assets needed."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedSize(42, 42)

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(TEAL))
        p.drawRoundedRect(0, 0, 42, 42, 12, 12)
        path = QPainterPath()
        path.moveTo(7, 27)
        path.lineTo(12, 27)
        path.cubicTo(16, 27, 14, 11, 19, 11)
        path.cubicTo(24, 11, 22, 27, 30, 27)
        path.lineTo(35, 27)
        p.setPen(QPen(QColor("white"), 2.3, Qt.SolidLine, Qt.RoundCap))
        p.setBrush(Qt.NoBrush)
        p.drawPath(path)


def card(title, subtitle=None):
    widget = QWidget()
    widget.setObjectName("surfaceCard")
    widget.setAttribute(Qt.WA_StyledBackground, True)
    layout = QVBoxLayout(widget)
    layout.setContentsMargins(18, 14, 18, 14)
    layout.setSpacing(8)
    title_label = label(title, bold=True, size=11)
    layout.addWidget(title_label)
    if subtitle:
        layout.addWidget(label(subtitle, size=9, role="muted"))
    return widget, layout, title_label


def install_theme(app):
    app.setStyle("Fusion")
    app.setFont(font())
    pal = QPalette()
    for role, value in [(QPalette.Window, CANVAS), (QPalette.WindowText, INK),
                        (QPalette.Base, SURFACE), (QPalette.AlternateBase, "#F7F9FC"),
                        (QPalette.Text, INK), (QPalette.Button, SURFACE),
                        (QPalette.ButtonText, INK), (QPalette.Highlight, TEAL),
                        (QPalette.HighlightedText, "#FFFFFF"),
                        (QPalette.ToolTipBase, NAVY), (QPalette.ToolTipText, "#FFFFFF")]:
        pal.setColor(role, QColor(value))
    pal.setColor(QPalette.Disabled, QPalette.Text, QColor("#98A5B3"))
    pal.setColor(QPalette.Disabled, QPalette.ButtonText, QColor("#98A5B3"))
    app.setPalette(pal)
    assets = (Path(__file__).parent / "assets").resolve().as_posix()
    app.setStyleSheet(STYLESHEET.replace("@ASSETS@", assets))

    import matplotlib.pyplot as plt
    plt.rcParams.update({
        "font.family": "DejaVu Sans", "font.sans-serif": ["DejaVu Sans"],
        "figure.facecolor": "white", "axes.facecolor": "white",
        "axes.edgecolor": "#DCE3EB", "axes.labelcolor": "#54667A",
        "axes.titlecolor": INK, "text.color": INK,
        "xtick.color": "#6D7D8E", "ytick.color": "#6D7D8E",
        "axes.spines.top": False, "axes.spines.right": False,
        "grid.color": "#DCE3EB", "grid.linewidth": 0.6,
        "axes.titlesize": 10, "axes.labelsize": 9,
        "xtick.labelsize": 8, "ytick.labelsize": 8,
        "legend.fontsize": 8, "axes.titlepad": 10,
        "axes.unicode_minus": False,
    })


STYLESHEET = """
QWidget { color: #183047; }
QMainWindow, QDialog { background: #F2F5F9; }
QWidget#appHeader { background: #142C43; }
QLabel#brandTitle { color: #FFFFFF; font-size: 20px; font-weight: 600; }
QLabel#brandSubtitle { color: #A6BACD; font-size: 10px; letter-spacing: 1px; }
QLabel#modeBadge { color: #BDECE8; background: #23475A; border-radius: 12px;
                  padding: 6px 14px; font-weight: 600; }
QPushButton#switchMode { background: #233E55; color: #FFFFFF; border-color: #456077; }
QPushButton#switchMode:hover { background: #31556E; }
QWidget#surfaceCard, QWidget#sidebarFooter, QWidget#roiCard {
    background: #FFFFFF; border: 1px solid #DFE6EF; border-radius: 10px; }
QWidget#roiCard QLabel#roiTitle { color: #087F8C; background: #EDF7F8;
    border-radius: 6px; padding: 9px 12px; font-weight: 600; }
QLabel[role="muted"] { color: #6D7D8E; }
QLabel[role="eyebrow"] { color: #087F8C; font-size: 10px; font-weight: 600; }
QLabel#videoPreview { background: #152A3C; color: #AEC0CF;
    border: 1px solid #263E53; border-radius: 8px; }
QLabel#emptyState { color: #728397; background: #FFFFFF; border: 1px dashed #CED9E5;
    border-radius: 8px; padding: 30px; }
QPushButton { background: #FFFFFF; border: 1px solid #D4DFE9;
    border-radius: 6px; padding: 5px 10px; }
QPushButton:hover { background: #EDF5F8; border-color: #91BDC6; }
QPushButton:pressed { background: #DEEFF2; }
QPushButton:focus { border: 2px solid #36A3AF; }
QPushButton[role="primary"] { color: #FFFFFF; background: #087F8C;
    border: 1px solid #087F8C; font-weight: 600; }
QPushButton[role="primary"]:hover { background: #066B77; }
QPushButton[role="primary"]:pressed { background: #04545F; }
QPushButton:disabled { background: #F0F3F7; color: #98A5B3; border-color: #E4EAF1; }
QPushButton[role="primary"]:disabled { background: #CADDE1; color: #F6FAFB; }
QComboBox, QSpinBox, QDoubleSpinBox, QLineEdit {
    background: #FFFFFF; border: 1px solid #D4DFE9; border-radius: 5px;
    padding: 5px 6px; min-height: 20px; selection-background-color: #087F8C; }
QComboBox { padding-right: 22px; }
QComboBox:hover, QSpinBox:hover, QDoubleSpinBox:hover, QLineEdit:hover { border-color: #91BDC6; }
QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus, QLineEdit:focus { border-color: #087F8C; }
QComboBox:disabled, QSpinBox:disabled, QDoubleSpinBox:disabled { background: #F1F4F8; color: #98A5B3; }
QComboBox::drop-down { border: none; width: 22px; }
QComboBox::down-arrow { image: url("@ASSETS@/chevron_down.svg"); width: 12px; height: 12px; }
QSpinBox, QDoubleSpinBox { padding-right: 22px; }
QSpinBox::up-button, QDoubleSpinBox::up-button { subcontrol-origin: border;
    subcontrol-position: top right; width: 22px; border: none; background: transparent; }
QSpinBox::down-button, QDoubleSpinBox::down-button { subcontrol-origin: border;
    subcontrol-position: bottom right; width: 22px; border: none; background: transparent; }
QSpinBox::up-arrow, QDoubleSpinBox::up-arrow { image: url("@ASSETS@/chevron_up.svg"); width: 12px; height: 12px; }
QSpinBox::down-arrow, QDoubleSpinBox::down-arrow { image: url("@ASSETS@/chevron_down.svg"); width: 12px; height: 12px; }
QComboBox QAbstractItemView { border: 1px solid #D4DFE9; background: white;
    selection-background-color: #E1F2F3; selection-color: #087F8C; padding: 4px; }
QGroupBox { background: #FFFFFF; border: 1px solid #DFE6EF; border-radius: 8px;
    margin-top: 12px; padding: 14px 10px 10px 10px; font-weight: 600; }
QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top left;
    left: 14px; padding: 0 4px; color: #466079; }
QGroupBox QGroupBox { background: #F7F9FC; }
QCheckBox, QRadioButton { spacing: 7px; }
QCheckBox::indicator, QRadioButton::indicator { width: 15px; height: 15px; }
QRadioButton#modeOption { background: #FFFFFF; border: 1px solid #D6E1EB;
    border-radius: 9px; padding: 18px; spacing: 14px; }
QRadioButton#modeOption:checked { background: #EBF6F7; border: 2px solid #087F8C; }
QRadioButton#modeOption:hover { border-color: #087F8C; }
QTabWidget::pane { border: none; background: transparent; }
QTabBar::tab { background: transparent; padding: 10px 18px; margin-right: 4px;
    border-bottom: 2px solid transparent; color: #728397; }
QTabBar::tab:selected { color: #087F8C; background: #EAF4F6; border-bottom: 2px solid #087F8C; }
QTabBar::tab:hover { color: #183047; background: #EEF3F8; }
QTableWidget { background: #FFFFFF; alternate-background-color: #F7F9FC;
    border: 1px solid #E4EAF1; border-radius: 5px;
    selection-background-color: #E0F1F3; selection-color: #155A65; }
QTableWidget::item { padding: 5px; border: none; }
QHeaderView::section { background: #EEF3F8; color: #63768B;
    border: none; border-bottom: 1px solid #DFE6EF; padding: 8px 7px; font-weight: 600; }
QScrollArea { background: transparent; border: none; }
QScrollBar:vertical { background: transparent; width: 9px; margin: 2px; }
QScrollBar::handle:vertical { background: #C8D4E1; min-height: 30px; border-radius: 3px; }
QScrollBar:horizontal { background: transparent; height: 9px; margin: 2px; }
QScrollBar::handle:horizontal { background: #C8D4E1; min-width: 30px; border-radius: 3px; }
QScrollBar::add-line, QScrollBar::sub-line { width: 0px; height: 0px; }
QScrollBar::add-page, QScrollBar::sub-page { background: transparent; }
QSplitter::handle { background: transparent; }
QSplitter::handle:hover { background: #C8DCE6; }
QSlider::groove:horizontal { background: #DFE7EF; height: 4px; border-radius: 2px; }
QSlider::sub-page:horizontal { background: #087F8C; border-radius: 2px; }
QSlider::handle:horizontal { background: #FFFFFF; border: 2px solid #087F8C;
    width: 10px; margin: -5px 0; border-radius: 6px; }
QSlider::handle:horizontal:disabled { border-color: #B9C8D7; }
QProgressBar { background: #EAF0F6; border: none; border-radius: 4px;
    text-align: center; color: #31566A; }
QProgressBar::chunk { background: #63BFBE; border-radius: 4px; }
QStatusBar { background: #EAF0F6; color: #63768B; padding: 3px 12px; }
QStatusBar::item { border: none; }
QToolTip { color: #FFFFFF; background: #142C43; border: none; padding: 8px; }
"""
