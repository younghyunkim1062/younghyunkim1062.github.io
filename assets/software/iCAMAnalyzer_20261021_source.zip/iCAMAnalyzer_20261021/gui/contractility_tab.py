"""
gui/contractility_tab.py
Tab 2 — Multi-Organoid Contractility Analysis
PyQt5 port of app_multiCO.py (Streamlit → PyQt5)

범용성 확장:
  - ROI shape filter 완화 (solidity / aspect_ratio 슬라이더)
  - K-means cluster 수 선택 가능 (2–5)
  - Cluster label 사용자 정의
  - px/µm 자유 입력
  - 모델 타입 선택 (Organoid / EHT / 2D monolayer)
"""

import sys, os, tempfile, gc
from pathlib import Path

import numpy as np
import traceback
import cv2

# Cellpose detector (미설치 시 adaptive CV fallback 자동 사용)
try:
    from core.cellpose_detector import (
        detect_rois_auto, draw_roi_annotations,
        save_feedback, load_feedback,
        cellpose_available,
    )
    _CP_MODULE_OK = True
except ImportError:
    _CP_MODULE_OK = False


def _params_hash(params: dict) -> str:
    """파라미터 딕셔너리의 해시값 계산 — 추출 파라미터 변경 감지에 사용."""
    import hashlib, json
    return hashlib.md5(
        json.dumps(params, sort_keys=True, default=str).encode()
    ).hexdigest()[:12]
from scipy.signal import find_peaks, savgol_filter, peak_widths, detrend
from scipy.ndimage import percentile_filter
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QSplitter,
    QPushButton, QLabel, QFileDialog, QSlider, QRadioButton,
    QTableWidget, QTableWidgetItem, QHeaderView,
    QGroupBox, QDoubleSpinBox, QSpinBox, QComboBox,
    QProgressDialog, QProgressBar, QMessageBox, QScrollArea,
    QSizePolicy, QLineEdit, QFormLayout, QCheckBox,
    QDialog, QDialogButtonBox, QListWidget, QListWidgetItem,
    QAbstractItemView, QTabWidget, QGridLayout,
)
from PyQt5.QtCore import Qt, QThread, pyqtSignal, QTimer
from PyQt5.QtGui import QFont, QPixmap, QImage, QColor
from gui.theme import font, label, button, style_table, FONT_FAMILY

import matplotlib
matplotlib.use("Qt5Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas

# Use DejaVu Sans for matplotlib — supports unicode glyphs (⚠ ⁻¹ ₀ etc.)
# Arial on Windows lacks many unicode characters (glyphs 9888, 8315, etc.)
plt.rcParams.update({
    "font.family":      "DejaVu Sans",
    "font.sans-serif":  ["DejaVu Sans", "Arial", "sans-serif"],
    "axes.unicode_minus": False,
    "axes.titlesize":   9,
    "axes.labelsize":   8,
    "xtick.labelsize":  8,
    "ytick.labelsize":  8,
})

# ── Font helpers (reuse from main_window style) ───────────────────────────────
ARIAL    = QFont(FONT_FAMILY, 10)
ARIAL_SM = QFont(FONT_FAMILY, 9)
ARIAL_BD = QFont(FONT_FAMILY, 10, QFont.Bold)

def _btn(text, color=None, bold=False):
    return button(text, color, bold)

def _lbl(text, bold=False, size=10):
    return label(text, bold, size)


def _safe_two_slope_norm(v, vcenter=0.0):
    """
    TwoSlopeNorm requires vmin < vcenter < vmax.
    If data is all-zero or single-sided, fall back to a simple Normalize.
    """
    from matplotlib.colors import TwoSlopeNorm, Normalize
    vmin, vmax = -abs(v), abs(v)
    if vmin < vcenter < vmax:
        return TwoSlopeNorm(vmin=vmin, vcenter=vcenter, vmax=vmax)
    # fallback
    lo = min(vmin, vcenter) - 1e-6
    hi = max(vmax, vcenter) + 1e-6
    return Normalize(vmin=lo, vmax=hi)

def _robust_baseline_correct(x, fps, window_sec=6.0, return_baseline=False):
    """Remove slow baseline drift from a 1-D signal while preserving the
    fast beat-to-beat oscillations on top of it.

    Uses a rolling 10th-percentile (smoothed) as the baseline rather than
    scipy's plain linear `detrend`. A straight-line detrend can't follow a
    drift that isn't linear, and — critically — can't absorb an abrupt
    STEP change such as a mid-recording focus/illumination shift (e.g. the
    organoid briefly going out of focus, or the stage being bumped): a
    rolling local baseline adapts to that within roughly `window_sec`,
    instead of letting the step bias the whole trace and corrupt
    peak/duration detection downstream.
    """
    x = np.asarray(x, dtype=float)
    n = len(x)
    if n < 10:
        return (x.copy(), x.copy()) if return_baseline else x.copy()
    win = max(9, int(round(fps * window_sec)))
    if win % 2 == 0:
        win += 1
    win = min(win, n - (1 - n % 2))
    if win < 5:
        return (x.copy(), x.copy()) if return_baseline else x.copy()
    baseline = percentile_filter(x, percentile=10, size=win, mode="nearest")
    sg_win = win if win % 2 == 1 else win + 1
    sg_win = min(sg_win, n - (1 - n % 2))
    if sg_win >= 5:
        baseline = savgol_filter(baseline, sg_win, 2)
    corrected = x - baseline + np.median(x)
    return (corrected, baseline) if return_baseline else corrected


def _detect_unstable_ranges(baseline, fps, rel_jump=0.15, merge_gap_sec=2.0):
    """Flag time windows where the rolling baseline itself jumps abruptly —
    e.g. a focus/illumination shift or a sustained motion-blur burst — so
    the UI can warn the user instead of silently absorbing it into the
    'corrected' signal. Returns a list of (t_start, t_end) in seconds."""
    baseline = np.asarray(baseline, dtype=float)
    n = len(baseline)
    if n < 10:
        return []
    rng = np.percentile(baseline, 95) - np.percentile(baseline, 5)
    if rng <= 0:
        return []
    d = np.abs(np.diff(baseline))
    idx = np.where(d > rel_jump * rng)[0]
    if len(idx) == 0:
        return []
    ranges = []
    gap = max(1, int(merge_gap_sec * fps))
    start = prev = idx[0]
    for i in idx[1:]:
        if i - prev > gap:
            ranges.append((start, prev))
            start = i
        prev = i
    ranges.append((start, prev))
    return [(s / fps, e / fps) for s, e in ranges]


def _local_trough_width(signal, events, anchors, fps, rel_h, max_gap=None):
    """Generalized version of the local-trough-anchored width measurement
    used for Motion 'Duration': for each index in `events` (a local
    maximum of `signal`), walk outward until `signal` drops to `rel_h`
    of the way from the event's peak value down toward the nearest
    `anchors` (local minima) on either side, anchoring duration to where
    the signal actually returns toward rest rather than scipy's
    prominence-based saddle point.

    To reuse this for Area (where the contraction event is a local
    *minimum*, not maximum), call with signal=-area_s, events=area
    troughs, anchors=area peaks — same shape, inverted sign.

    Returns (left_idx, right_idx, target_height, local_base) arrays,
    one entry per event, in the same order as `events`.
    """
    signal  = np.asarray(signal, dtype=float)
    anchors = np.asarray(anchors, dtype=int)
    n = len(signal)
    if max_gap is None:
        max_gap = max(1, int(round(fps * 2.5)))
    lefts, rights, heights, bases = [], [], [], []
    for p in events:
        left_a  = anchors[(anchors < p) & (anchors >= p - max_gap)]
        right_a = anchors[(anchors > p) & (anchors <= p + max_gap)]
        if len(left_a):
            left_base = signal[left_a[-1]]
        elif len(right_a):
            left_base = signal[right_a[0]]
        else:
            lo, hi = max(0, p - max_gap), min(n, p + max_gap)
            left_base = np.percentile(signal[lo:hi], 10)
        if len(right_a):
            right_base = signal[right_a[0]]
        elif len(left_a):
            right_base = signal[left_a[-1]]
        else:
            right_base = left_base
        base_local = min(left_base, right_base)
        target = signal[p] - rel_h * (signal[p] - base_local)

        li = p
        while li > 0 and li > p - max_gap and signal[li] > target:
            li -= 1
        ri = p
        while ri < n - 1 and ri < p + max_gap and signal[ri] > target:
            ri += 1
        lefts.append(li); rights.append(ri); heights.append(target)
        bases.append(base_local)

    return (np.array(lefts, dtype=float), np.array(rights, dtype=float),
            np.array(heights), np.array(bases))


def _reject_outlier_peaks(values, n_mad=5.0):
    """Given one value per detected peak (e.g. its prominence above local
    baseline), flag peaks whose value is wildly larger than the rest as
    likely motion/focus artifacts rather than genuine beats, using a
    median + MAD (robust z-score) cutoff. Returns a boolean mask of which
    peaks to KEEP (True = keep, False = artifact)."""
    values = np.asarray(values, dtype=float)
    if len(values) < 4:
        return np.ones(len(values), dtype=bool)
    med = np.median(values)
    mad = np.median(np.abs(values - med)) + 1e-9
    robust_z = np.abs(values - med) / (1.4826 * mad)
    return robust_z <= n_mad


def _centered_box(cx, cy, w, h, W, H):
    """Return an integer (x, y, w, h) crop box of fixed size (w, h) centered
    on (cx, cy), clamped so it stays fully inside an image of size (W, H).
    Used to re-center the analysis window on the organoid's centroid every
    frame, instead of leaving it fixed at its frame-0 position."""
    x = int(round(cx - w / 2.0))
    y = int(round(cy - h / 2.0))
    x = max(0, min(x, max(W - w, 0)))
    y = max(0, min(y, max(H - h, 0)))
    return x, y, w, h


# ─────────────────────────────────────────────────────────────────────────────
#  Averaged Transient helpers  (ported from single_CO_20260617.py)
# ─────────────────────────────────────────────────────────────────────────────

def _compute_avg_segments(signal, peaks, pre_pad, post_pad,
                           baseline_subtract=True):
    """Extract per-beat segments from *signal* aligned on *peaks*.
    Returns (all_segs_2d, t_axis_frames, avg_smooth).
    Raises ValueError if no valid segments can be extracted.
    """
    segs = []
    for p in peaks:
        s, e = int(p) - pre_pad, int(p) + post_pad
        if s >= 0 and e < len(signal):
            seg = np.array(signal[s:e], dtype=float)
            if baseline_subtract:
                seg -= np.mean(seg[:pre_pad])
            segs.append(seg)
    if not segs:
        raise ValueError("주기 추출 범위를 벗어났습니다.")
    min_len = min(len(s) for s in segs)
    all_t   = np.array([s[:min_len] for s in segs])
    avg     = np.mean(all_t, axis=0)
    smooth  = savgol_filter(avg, 15, 3) if min_len > 15 else avg
    t_axis  = np.arange(min_len) - pre_pad          # in frames (not seconds)
    return all_t, t_axis, smooth


def _draw_motion_avg_ax(ax, all_t, t_frames, smooth_avg, fps):
    """Draw Motion averaged transient + kinetic markers onto *ax*.
    Returns t_sec array used for the x-axis.
    """
    from scipy.interpolate import interp1d as _i1d
    t_sec = t_frames / fps
    f_max = float(np.max(smooth_avg))
    p_idx = int(np.argmax(smooth_avg))

    # individual beats (light grey)
    for seg in all_t:
        ax.plot(t_sec, seg, color=[0.85, 0.85, 0.85], lw=0.5, zorder=1)
    # mean (blue, matching existing plot colour)
    ax.plot(t_sec, smooth_avg, color="#1f77b4", lw=2.5, zorder=2)
    ax.axhline(0, color="gray", linestyle="--", lw=1)
    ax.axvline(t_sec[p_idx], color="lightgray", linestyle=":", lw=1.5)

    # kinetic markers
    try:
        interp_on  = _i1d(smooth_avg[:p_idx+1], t_sec[:p_idx+1],
                           assume_sorted=False, fill_value="extrapolate")
        interp_off = _i1d(smooth_avg[p_idx:],   t_sec[p_idx:],
                           assume_sorted=False, fill_value="extrapolate")
        t10_on  = float(interp_on(0.1 * f_max))
        t50_off = float(interp_off(0.5 * f_max))
        t90_off = float(interp_off(0.1 * f_max))
    except Exception:
        t10_on = t50_off = t90_off = t_sec[-1]

    span = abs(t_sec[-1] - t_sec[0]) * 0.018
    mx_list = [t10_on,      t_sec[p_idx], t50_off,      t90_off]
    my_list = [0.1*f_max,   f_max,         0.5*f_max,    0.1*f_max]
    mc_list = ["#76AB2F", "#D95319", "#0072BD", "#A2142F"]
    ml_list = ["10% Onset", "Peak",    "CTD50",   "CTD90"]
    for mx, my, mc, ml in zip(mx_list, my_list, mc_list, ml_list):
        ax.plot(mx, my, "o", markersize=8,
                markerfacecolor=mc, markeredgecolor="white",
                markeredgewidth=1.5, zorder=3)
        ax.text(mx + span, my + 0.05 * f_max, ml,
                color=mc, fontsize=7, fontweight="bold")

    ax.set_title("Averaged Motion Trace & Kinetics", fontsize=9, fontweight="bold")
    ax.set_xlabel("Time from Peak (s)", fontsize=8)
    ax.set_ylabel("Motion (a.u.)", fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, linestyle=":", alpha=0.4)
    return t_sec


def _draw_area_avg_ax(ax, all_t_area, t_frames, smooth_area, fps):
    """Draw Area averaged transient onto *ax* (absolute µm² values)."""
    t_sec = t_frames / fps
    for seg in all_t_area:
        ax.plot(t_sec, seg, color=[0.85, 0.85, 0.85], lw=0.5, zorder=1)
    ax.plot(t_sec, smooth_area, color="black", lw=2.5, zorder=2)
    trough_idx = int(np.argmin(smooth_area))
    ax.axvline(t_sec[trough_idx], color="lightgray", linestyle=":", lw=1.5)
    ax.plot(t_sec[trough_idx], smooth_area[trough_idx], "o", markersize=8,
            markerfacecolor="#D95319", markeredgecolor="white",
            markeredgewidth=1.5, zorder=3, label="Min Area")
    ax.set_title("Averaged Area Trace", fontsize=9, fontweight="bold")
    ax.set_xlabel("Time from Motion Peak (s)", fontsize=8)
    ax.set_ylabel("Area (µm²)", fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, linestyle=":", alpha=0.4)
    return t_sec


def _draw_delta_area_avg_ax(ax, all_delta, t_frames, smooth_delta, fps):
    """Draw ΔArea averaged transient onto *ax* (baseline-subtracted µm²).

    Baseline = relaxed state before each beat → ΔArea = 0 at rest,
    negative (downward) at peak contraction.  This makes the waveform
    shape and amplitude directly comparable across organoids of different
    sizes.
    """
    t_sec = t_frames / fps
    for seg in all_delta:
        ax.plot(t_sec, seg, color=[0.85, 0.85, 0.85], lw=0.5, zorder=1)
    ax.plot(t_sec, smooth_delta, color="black", lw=2.5, zorder=2)
    trough_idx = int(np.argmin(smooth_delta))
    ax.axhline(0, color="gray", linestyle="--", lw=1.0, zorder=0)
    ax.axvline(t_sec[trough_idx], color="lightgray", linestyle=":", lw=1.5)
    ax.plot(t_sec[trough_idx], smooth_delta[trough_idx], "o", markersize=8,
            markerfacecolor="#D95319", markeredgecolor="white",
            markeredgewidth=1.5, zorder=3, label="Max contraction")
    ax.set_title("Averaged ΔArea Trace", fontsize=9, fontweight="bold")
    ax.set_xlabel("Time from Motion Peak (s)", fontsize=8)
    ax.set_ylabel("ΔArea (µm²)", fontsize=8)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(True, linestyle=":", alpha=0.4)
    return t_sec


def _build_avg_transient_df(cont_s, area_s, peaks, fps):
    """
    Compute averaged-transient segments + the Prism-friendly DataFrame,
    WITHOUT creating any matplotlib Figure.

    Returns dict with keys:
        all_motion, all_area (or None), t_frames, smooth_motion,
        smooth_area (or None), df
    or None on failure (too few peaks / extraction error).

    This is split out from the old _build_avg_transient() specifically so
    that interactive callbacks (e.g. dragging the prominence/distance
    spinboxes) can update the *existing* embedded axes directly via
    _draw_motion_avg_ax()/_draw_area_avg_ax() instead of creating a brand
    new Figure on every keystroke and copying its contents over — that
    extra create/copy/plt.close() cycle was the main cause of the UI
    feeling sluggish once more analyses were added.
    """
    import pandas as pd

    if len(peaks) < 2:
        return None

    intervals = np.diff(peaks)
    mean_int  = int(np.mean(intervals))
    pre_pad   = int(mean_int * 0.2)
    post_pad  = int(mean_int * 0.8)

    try:
        all_motion, t_frames, smooth_motion = _compute_avg_segments(
            cont_s, peaks, pre_pad, post_pad, baseline_subtract=True)
    except ValueError:
        return None

    has_area = area_s is not None and len(area_s) >= len(cont_s)
    all_area = smooth_area = None
    if has_area:
        try:
            all_area, _, smooth_area = _compute_avg_segments(
                area_s, peaks, pre_pad, post_pad, baseline_subtract=False)
            ml = min(all_motion.shape[1], all_area.shape[1])
            all_motion    = all_motion[:, :ml]
            all_area      = all_area[:, :ml]
            smooth_motion = smooth_motion[:ml]
            smooth_area   = smooth_area[:ml]
            t_frames      = t_frames[:ml]
        except Exception:
            has_area = False
            all_area = smooth_area = None

    t_sec = t_frames / fps
    n_beats = all_motion.shape[0]

    # ── Absolute Area DataFrame (original) ───────────────────────────────────
    data = {"Time from Peak (s)": t_sec}
    for i in range(n_beats):
        data[f"Motion_Beat_{i+1} (a.u.)"] = all_motion[i]
    data["Motion Mean (a.u.)"] = smooth_motion
    if has_area:
        for i in range(n_beats):
            data[f"Area_Beat_{i+1} (µm²)"] = all_area[i]
        data["Area Mean (µm²)"] = smooth_area

    # ── ΔArea DataFrame (baseline-subtracted per beat) ────────────────────────
    # Baseline = mean of the first pre_pad frames of each segment (relaxed state)
    # so ΔArea = 0 at rest, negative when contracted.
    delta_data = None
    all_delta = None
    smooth_delta = None
    if has_area:
        # Per-beat baseline = mean of first pre_pad points of each segment
        baselines = np.array([np.mean(seg[:pre_pad]) for seg in all_area])
        all_delta = all_area - baselines[:, np.newaxis]   # shape (n_beats, L)
        smooth_delta = np.mean(all_delta, axis=0)
        from scipy.signal import savgol_filter as _sg
        if len(smooth_delta) > 15:
            smooth_delta = _sg(smooth_delta, 15, 3)

        delta_data = {"Time from Peak (s)": t_sec}
        for i in range(n_beats):
            delta_data[f"DeltaArea_Beat_{i+1} (µm²)"] = all_delta[i]
        delta_data["DeltaArea Mean (µm²)"] = smooth_delta

    return {
        "all_motion": all_motion, "all_area": all_area,
        "all_delta": all_delta,
        "t_frames": t_frames, "smooth_motion": smooth_motion,
        "smooth_area": smooth_area, "smooth_delta": smooth_delta,
        "has_area": has_area,
        "pre_pad": pre_pad,
        "df": pd.DataFrame(data),
        "df_delta": pd.DataFrame(delta_data) if delta_data else None,
    }


def _build_avg_transient(cont_s, area_s, peaks, fps):
    """Compute averaged transients for Motion and Area aligned on *peaks*.

    Returns (fig, df_avg) or (None, None) on failure.

    df_avg columns (Prism XY table format):
        Time from Peak (s)
        Motion_Beat_1 (a.u.) … Motion_Beat_N (a.u.)
        Motion Mean (a.u.)
        Area_Beat_1 (µm²)   … Area_Beat_N (µm²)
        Area Mean (µm²)
    """
    import pandas as pd

    if len(peaks) < 2:
        return None, None

    intervals = np.diff(peaks)
    mean_int  = int(np.mean(intervals))
    pre_pad   = int(mean_int * 0.2)
    post_pad  = int(mean_int * 0.8)

    # ── Motion ───────────────────────────────────────────────────────────────
    try:
        all_motion, t_frames, smooth_motion = _compute_avg_segments(
            cont_s, peaks, pre_pad, post_pad, baseline_subtract=True)
    except ValueError:
        return None, None

    # ── Area (optional) ──────────────────────────────────────────────────────
    has_area = area_s is not None and len(area_s) >= len(cont_s)
    if has_area:
        try:
            all_area, _, smooth_area = _compute_avg_segments(
                area_s, peaks, pre_pad, post_pad, baseline_subtract=False)
            # align lengths
            ml = min(all_motion.shape[1], all_area.shape[1])
            all_motion   = all_motion[:, :ml]
            all_area     = all_area[:, :ml]
            smooth_motion = smooth_motion[:ml]
            smooth_area   = smooth_area[:ml]
            t_frames      = t_frames[:ml]
        except Exception:
            has_area = False

    # ── Figure ───────────────────────────────────────────────────────────────
    n_rows = 2 if has_area else 1
    fig, axes = plt.subplots(n_rows, 1, figsize=(9, 3.5 * n_rows), sharex=(n_rows > 1))
    if n_rows == 1:
        axes = [axes]

    t_sec = _draw_motion_avg_ax(axes[0], all_motion, t_frames, smooth_motion, fps)
    if has_area:
        axes[0].set_xlabel("")          # shared x — label only on bottom
        _draw_area_avg_ax(axes[1], all_area, t_frames, smooth_area, fps)

    fig.tight_layout(pad=1.5)

    # ── Prism-friendly DataFrame ──────────────────────────────────────────
    n_beats = all_motion.shape[0]
    data = {"Time from Peak (s)": t_sec}
    for i in range(n_beats):
        data[f"Motion_Beat_{i+1} (a.u.)"] = all_motion[i]
    data["Motion Mean (a.u.)"] = smooth_motion
    if has_area:
        for i in range(n_beats):
            data[f"Area_Beat_{i+1} (µm²)"] = all_area[i]
        data["Area Mean (µm²)"] = smooth_area

    return fig, pd.DataFrame(data)


# ─────────────────────────────────────────────────────────────────────────────
#  Worker: ROI detection from first frame
# ─────────────────────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────────────────────
#  Worker: 여러 영상을 백그라운드에서 프로브 (튕김 방지)
# ─────────────────────────────────────────────────────────────────────────────

class QueueProbeWorker(QThread):
    """
    영상 파일 목록을 받아 각 파일의 fps/duration/auto-threshold를
    백그라운드에서 읽어 반환.  메인 스레드 블로킹 없음.
    """
    one_done = pyqtSignal(str, float, float, int)   # path, fps, dur_s, auto_thr
    all_done  = pyqtSignal()
    error     = pyqtSignal(str, str)                # path, error_msg

    def __init__(self, paths: list):
        super().__init__()
        self.paths = paths

    def run(self):
        for path in self.paths:
            try:
                cap   = cv2.VideoCapture(path)
                fps_s = cap.get(cv2.CAP_PROP_FPS)
                n_fr  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
                ret, fr = cap.read()
                cap.release()

                if not fps_s or np.isnan(fps_s) or fps_s <= 0:
                    fps_s = 30.0
                dur_s = n_fr / fps_s if fps_s > 0 else 0.0

                if ret:
                    gray = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
                    blur = cv2.GaussianBlur(gray, (11, 11), 0)
                    ov, _ = cv2.threshold(blur, 0, 255,
                                           cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
                    auto_thr = max(10, min(220, int(ov * 0.85)))
                else:
                    auto_thr = 60
                    dur_s    = 0.0

                self.one_done.emit(path, fps_s, dur_s, auto_thr)
            except Exception as e:
                self.error.emit(path, str(e))
        self.all_done.emit()

class ROIDetectWorker(QThread):
    """Manual Override용 단일 프레임 ROI 탐색 워커."""
    finished = pyqtSignal(list, object, str)
    error    = pyqtSignal(str)

    def __init__(self, video_path, threshold, max_rois,
                 min_solidity, min_ar, max_ar, min_area_frac, max_area_frac,
                 frame_idx: int = 0, use_cellpose: bool = False):
        super().__init__()
        self.path          = video_path
        self.threshold     = threshold
        self.max_rois      = max_rois
        self.min_solidity  = min_solidity
        self.min_ar        = min_ar
        self.max_ar        = max_ar
        self.min_area_frac = min_area_frac
        self.max_area_frac = max_area_frac
        self.frame_idx     = frame_idx

    def run(self):
        try:
            cap = cv2.VideoCapture(self.path)
            if self.frame_idx > 0:
                cap.set(cv2.CAP_PROP_POS_FRAMES, self.frame_idx)
            ret, frame = cap.read()
            cap.release()
            if not ret:
                self.error.emit("Cannot read frame.")
                return

            gray  = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            blur  = cv2.GaussianBlur(gray, (11, 11), 0)
            _, th = cv2.threshold(blur, self.threshold, 255, cv2.THRESH_BINARY_INV)
            kernel = np.ones((5, 5), np.uint8)
            th = cv2.morphologyEx(th, cv2.MORPH_OPEN, kernel, iterations=2)
            cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            H, W = gray.shape
            total_px = H * W
            valid = []
            if cnts:
                for c in sorted(cnts, key=cv2.contourArea, reverse=True):
                    area = cv2.contourArea(c)
                    frac = area / total_px
                    if not (self.min_area_frac <= frac <= self.max_area_frac):
                        continue
                    hull_area = cv2.contourArea(cv2.convexHull(c))
                    if hull_area <= 0:
                        continue
                    solidity = area / hull_area
                    x, y, w, h = cv2.boundingRect(c)
                    ar = w / max(h, 1)
                    if solidity >= self.min_solidity and self.min_ar <= ar <= self.max_ar:
                        valid.append({"box": (x, y, w, h), "contour": c})
                    if len(valid) >= self.max_rois:
                        break

            vis = frame.copy()
            for i, roi in enumerate(valid):
                x, y, w, h = roi["box"]
                cv2.drawContours(vis, [roi["contour"]], -1, (0, 0, 255), 2)
                cv2.rectangle(vis, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(vis, f"ROI {i+1}", (x, max(y-8, 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                Mc = cv2.moments(roi["contour"])
                ccx = int(Mc["m10"]/Mc["m00"]) if Mc["m00"] > 0 else x+w//2
                ccy = int(Mc["m01"]/Mc["m00"]) if Mc["m00"] > 0 else y+h//2
                arm = 18
                cv2.line(vis, (ccx-arm,ccy),(ccx+arm,ccy),(0,165,255),2)
                cv2.line(vis, (ccx,ccy-arm),(ccx,ccy+arm),(0,165,255),2)
                cv2.circle(vis,(ccx,ccy),5,(0,165,255),-1)
                cv2.putText(vis, f"cx={ccx} cy={ccy}", (ccx+8, max(ccy-8,10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0,165,255), 1)
            vis_rgb = cv2.cvtColor(vis, cv2.COLOR_BGR2RGB)
            self.finished.emit(valid, vis_rgb, "cv_manual")

        except Exception as e:
            self.error.emit(str(e))



# ─────────────────────────────────────────────────────────────────────────────
#  Worker: AutoROIScanner
#  영상 로드 시 백그라운드에서 자동 실행:
#    1. Otsu로 첫 프레임 ROI 탐색
#    2. 전체 프레임을 N 간격으로 스캔 → 면적/솔리디티 체크
#    3. 안정성 점수(0~1)와 이상 구간 목록을 반환
# ─────────────────────────────────────────────────────────────────────────────

class AutoROIScanResult:
    """AutoROIScanner 결과 컨테이너."""
    def __init__(self):
        self.rois:          list  = []       # 첫 프레임 ROI 목록
        self.vis_rgb:       object = None    # 첫 프레임 오버레이 이미지
        self.threshold:     int   = 60       # 사용된 Otsu threshold
        self.stability:     float = 1.0      # 0(불안정) ~ 1(완전 안정)
        self.bad_ranges:    list  = []       # [(start_s, end_s, reason), ...]
        self.scan_areas:    list  = []       # 스캔 프레임별 면적 (디버그용)
        self.scan_frames:   list  = []       # 스캔 프레임 인덱스
        self.fps:           float = 30.0
        self.total_frames:  int   = 0


class AutoROIScanner(QThread):
    """
    영상 업로드 직후 백그라운드에서 실행.
    - Otsu threshold 자동 결정 → 첫 프레임 ROI 탐색
    - scan_step 간격으로 전체 프레임 스캔
    - 각 스캔 프레임에서 "잡힌 ROI 면적"을 기록
    - 면적이 중앙값 대비 40% 이상 벗어나거나 ROI가 아예 사라지면 bad_range로 표시
    - stability = (정상 스캔 프레임 수) / (전체 스캔 프레임 수)
    """
    finished = pyqtSignal(object)   # AutoROIScanResult
    progress = pyqtSignal(int)      # 0~100
    error    = pyqtSignal(str)

    def __init__(self, video_path: str, threshold: int,
                 max_rois: int, min_solidity: float,
                 min_ar: float, max_ar: float,
                 scan_step: int = 10):
        super().__init__()
        self.path        = video_path
        self.threshold   = threshold
        self.max_rois    = max_rois
        self.min_solidity = min_solidity
        self.min_ar      = min_ar
        self.max_ar      = max_ar
        self.scan_step   = scan_step   # 몇 프레임마다 체크할지

    def _detect_frame(self, frame, threshold):
        """단일 프레임에서 ROI 탐색. (면적, contour, solidity) 리스트 반환."""
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (11, 11), 0)
        _, th = cv2.threshold(blur, threshold, 255, cv2.THRESH_BINARY_INV)
        kernel = np.ones((5, 5), np.uint8)
        th = cv2.morphologyEx(th, cv2.MORPH_OPEN, kernel, iterations=2)
        cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        H, W = gray.shape
        total = H * W
        results = []
        if cnts:
            for c in sorted(cnts, key=cv2.contourArea, reverse=True):
                area = cv2.contourArea(c)
                frac = area / total
                if not (0.001 <= frac <= 0.80):
                    continue
                hull_a = cv2.contourArea(cv2.convexHull(c))
                if hull_a <= 0:
                    continue
                sol = area / hull_a
                x, y, w, h = cv2.boundingRect(c)
                ar = w / max(h, 1)
                if sol >= self.min_solidity and self.min_ar <= ar <= self.max_ar:
                    results.append({"area": area, "contour": c,
                                     "solidity": sol, "box": (x, y, w, h)})
                if len(results) >= self.max_rois:
                    break
        return results

    def run(self):
        try:
            result = AutoROIScanResult()
            cap = cv2.VideoCapture(self.path)
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            result.fps = fps
            result.total_frames = total

            # ── Step 1: 첫 프레임 Otsu threshold + ROI 탐색 ─────────────────
            ret, frame0 = cap.read()
            if not ret:
                self.error.emit("Cannot read first frame.")
                cap.release()
                return

            gray0 = cv2.cvtColor(frame0, cv2.COLOR_BGR2GRAY)
            blur0 = cv2.GaussianBlur(gray0, (11, 11), 0)
            ov, _ = cv2.threshold(blur0, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            auto_thr = max(10, min(220, int(ov * 0.85)))
            # 사용자가 이미 조정한 threshold가 있으면 그걸 우선 사용
            thr = self.threshold if self.threshold != 60 else auto_thr
            result.threshold = thr

            rois0 = self._detect_frame(frame0, thr)
            result.rois = rois0

            # 첫 프레임 오버레이 이미지 생성
            vis = frame0.copy()
            for i, roi in enumerate(rois0):
                x, y, w, h = roi["box"]
                cv2.drawContours(vis, [roi["contour"]], -1, (0, 0, 255), 2)
                cv2.rectangle(vis, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(vis, f"ROI {i+1}", (x, max(y-8, 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                Mc = cv2.moments(roi["contour"])
                ccx = int(Mc["m10"]/Mc["m00"]) if Mc["m00"] > 0 else x+w//2
                ccy = int(Mc["m01"]/Mc["m00"]) if Mc["m00"] > 0 else y+h//2
                arm = 18
                cv2.line(vis, (ccx-arm,ccy),(ccx+arm,ccy),(0,165,255),2)
                cv2.line(vis, (ccx,ccy-arm),(ccx,ccy+arm),(0,165,255),2)
                cv2.circle(vis,(ccx,ccy),5,(0,165,255),-1)
            result.vis_rgb = cv2.cvtColor(vis, cv2.COLOR_BGR2RGB)

            if not rois0:
                # 첫 프레임에서 ROI 못 찾으면 스캔 생략
                result.stability = 0.0
                result.bad_ranges = [(0.0, total/fps, "ROI not found")]
                self.finished.emit(result)
                cap.release()
                return

            # 기준 면적: 첫 프레임 ROI 면적
            ref_area = sum(r["area"] for r in rois0) / max(len(rois0), 1)

            # ── Step 2: 전체 프레임 스캔 ────────────────────────────────────
            scan_indices = list(range(0, total, self.scan_step))
            areas = []
            bad_frames = []

            for si, fidx in enumerate(scan_indices):
                cap.set(cv2.CAP_PROP_POS_FRAMES, fidx)
                ret, frame = cap.read()
                if not ret:
                    bad_frames.append(fidx)
                    areas.append(0)
                    continue

                rois_f = self._detect_frame(frame, thr)
                if not rois_f:
                    bad_frames.append(fidx)
                    areas.append(0)
                else:
                    fa = sum(r["area"] for r in rois_f) / max(len(rois_f), 1)
                    areas.append(fa)
                    # 면적이 기준 대비 50% 이상 벗어나면 이상
                    if ref_area > 0 and abs(fa - ref_area) / ref_area > 0.50:
                        bad_frames.append(fidx)

                self.progress.emit(int(20 + 75 * si / max(len(scan_indices)-1, 1)))

            cap.release()

            result.scan_frames = scan_indices
            result.scan_areas  = areas

            # ── Step 3: bad_ranges 생성 (연속된 bad_frames를 구간으로 묶음) ─
            bad_ranges = []
            if bad_frames:
                bad_frames_sorted = sorted(set(bad_frames))
                gap = self.scan_step * 3  # 인접 프레임 간 최대 gap
                seg_start = bad_frames_sorted[0]
                seg_end   = bad_frames_sorted[0]
                for f in bad_frames_sorted[1:]:
                    if f - seg_end <= gap:
                        seg_end = f
                    else:
                        bad_ranges.append((seg_start/fps, seg_end/fps,
                                           "area anomaly / ROI lost"))
                        seg_start = seg_end = f
                bad_ranges.append((seg_start/fps, seg_end/fps,
                                   "area anomaly / ROI lost"))

            result.bad_ranges = bad_ranges
            n_bad  = len(bad_frames)
            n_total = max(len(scan_indices), 1)
            result.stability = max(0.0, 1.0 - n_bad / n_total)

            self.progress.emit(100)
            self.finished.emit(result)

        except Exception as e:
            self.error.emit(str(e))


# ─────────────────────────────────────────────────────────────────────────────
#  Worker: ROI-overlay video export (+ scale bar)
# ─────────────────────────────────────────────────────────────────────────────

def _nice_scale_length_um(view_width_um: float) -> float:
    """
    Pick a 'nice' round scale-bar length (in µm) that spans roughly
    10-20% of the visible frame width — mirrors how ImageJ/Fiji and
    most microscopy software choose scale-bar lengths (1/2/5 × 10^n).
    """
    target = view_width_um * 0.15
    if target <= 0:
        return 100.0
    exponent = np.floor(np.log10(target))
    base = target / (10 ** exponent)
    if base < 1.5:
        nice = 1
    elif base < 3.5:
        nice = 2
    elif base < 7.5:
        nice = 5
    else:
        nice = 10
    return float(nice * (10 ** exponent))


def draw_scale_bar(img_bgr: np.ndarray, px_per_um: float,
                    margin_px: int = 24) -> np.ndarray:
    """
    Draw a scale bar with label in the bottom-right corner of img_bgr.
    px_per_um: pixels per micrometer (as set in the GUI's 'px/µm' field).
    Returns a new image (does not mutate the input).
    """
    out = img_bgr.copy()
    H, W = out.shape[:2]

    if px_per_um <= 0:
        return out

    view_width_um = W / px_per_um
    bar_um  = _nice_scale_length_um(view_width_um)
    bar_px  = int(round(bar_um * px_per_um))
    bar_px  = max(10, min(bar_px, W - 2 * margin_px))  # keep on-screen

    bar_h = 5
    x2 = W - margin_px
    x1 = x2 - bar_px
    y  = H - margin_px

    label = f"{bar_um:g} um" if bar_um < 1000 else f"{bar_um/1000:g} mm"
    font  = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.55
    thickness  = 2
    (tw, th), _ = cv2.getTextSize(label, font, font_scale, thickness)

    # Semi-transparent backing box so the bar/label stay legible on
    # both bright and dark backgrounds.
    pad = 8
    box_x1 = x1 - pad
    box_y1 = y - th - bar_h - pad * 2
    box_x2 = x2 + pad
    box_y2 = y + pad
    box_x1 = max(0, box_x1); box_y1 = max(0, box_y1)
    overlay = out.copy()
    cv2.rectangle(overlay, (box_x1, box_y1), (box_x2, box_y2),
                  (0, 0, 0), thickness=-1)
    out = cv2.addWeighted(overlay, 0.35, out, 0.65, 0)

    # Bar (white, with thin black outline for contrast)
    cv2.line(out, (x1, y), (x2, y), (0, 0, 0), bar_h + 2)
    cv2.line(out, (x1, y), (x2, y), (255, 255, 255), bar_h)
    # End caps
    cap_h = 6
    cv2.line(out, (x1, y - cap_h), (x1, y + cap_h), (255, 255, 255), 2)
    cv2.line(out, (x2, y - cap_h), (x2, y + cap_h), (255, 255, 255), 2)

    # Label centered above the bar
    label_x = x1 + (bar_px - tw) // 2
    label_y = y - bar_h - 10
    cv2.putText(out, label, (label_x, label_y), font, font_scale,
                (255, 255, 255), thickness, cv2.LINE_AA)

    return out


# ─────────────────────────────────────────────────────────────────────────────
#  Publication-quality figure export helpers for Motion Heatmap & Contour
# ─────────────────────────────────────────────────────────────────────────────

def _save_heatmap_figure(path: str, hm_img_rgb: np.ndarray,
                          px_per_um: float, roi_name: str = "") -> None:
    """
    Save the Motion Heatmap as a publication-quality matplotlib figure.

    Renders the heatmap with:
      - JET colormap + colorbar (Motion Intensity, a.u.)
      - Physical axis labels in µm (if px_per_um > 0) or pixels
      - Title including ROI name
      - Clean, white-background figure at 300 DPI
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    H, W = hm_img_rgb.shape[:2]

    fig, ax = plt.subplots(figsize=(6, 5))

    if px_per_um > 0:
        extent_um = [0, W / px_per_um, H / px_per_um, 0]   # [left, right, bottom, top]
        im = ax.imshow(hm_img_rgb, extent=extent_um, aspect="equal", origin="upper")
        ax.set_xlabel("Distance (µm)", fontsize=11, fontweight="bold")
        ax.set_ylabel("Distance (µm)", fontsize=11, fontweight="bold")
    else:
        im = ax.imshow(hm_img_rgb, aspect="equal", origin="upper")
        ax.set_xlabel("X (pixels)", fontsize=11, fontweight="bold")
        ax.set_ylabel("Y (pixels)", fontsize=11, fontweight="bold")

    # Colorbar — map the raw RGB luminance to a scalar for the colorbar proxy
    import matplotlib.colors as mcolors
    import matplotlib.cm as cm
    cmap_jet = cm.get_cmap("jet")
    sm = plt.cm.ScalarMappable(
        cmap=cmap_jet,
        norm=mcolors.Normalize(vmin=0, vmax=1)
    )
    sm.set_array([])
    cb = fig.colorbar(sm, ax=ax, fraction=0.046, pad=0.04)
    cb.set_label("Motion Intensity (a.u., normalized)", fontsize=10,
                 fontweight="bold")
    cb.set_ticks([0, 0.25, 0.5, 0.75, 1.0])
    cb.set_ticklabels(["Low", "", "Medium", "", "High"])

    title = "Motion Heatmap"
    if roi_name:
        title = f"Motion Heatmap — {roi_name}"
    ax.set_title(title, fontsize=12, fontweight="bold", pad=8)

    fig.tight_layout()
    fig.savefig(path, dpi=300, bbox_inches="tight",
                facecolor="white", edgecolor="none")
    plt.close(fig)


def _save_contour_figure(path: str, cnt_img_rgb: np.ndarray,
                          px_per_um: float, roi_name: str = "",
                          max_area_um2: float = None,
                          min_area_um2: float = None) -> None:
    """
    Save the Max↔Min Contour overlay as a publication-quality matplotlib figure.

    Renders:
      - Brightfield background (grayscale)
      - Red contour  = Max-area frame (organoid fully relaxed)
      - Blue contour = Min-area frame (organoid fully contracted)
      - Scale bar in µm (bottom-right corner)
      - Legend explaining line colours
      - Title including ROI name and optional area values
    """
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.lines import Line2D
    from matplotlib.patches import FancyArrowPatch

    H, W = cnt_img_rgb.shape[:2]

    fig, ax = plt.subplots(figsize=(6, 5.2))
    ax.imshow(cnt_img_rgb, aspect="equal", origin="upper")
    ax.set_axis_off()

    # ── Scale bar (bottom-right, in µm) ──────────────────────────────────────
    if px_per_um > 0:
        view_w_um = W / px_per_um
        # Pick a round scale-bar length (~15% of frame width)
        target = view_w_um * 0.15
        exp = np.floor(np.log10(max(target, 1e-9)))
        base_v = target / (10 ** exp)
        nice = 1 if base_v < 1.5 else (2 if base_v < 3.5 else (5 if base_v < 7.5 else 10))
        bar_um = float(nice * (10 ** exp))
        bar_px = bar_um * px_per_um          # length in image pixels

        # Draw in image-pixel coordinates (imshow axes = pixel space)
        margin = W * 0.04
        x2 = W - margin
        x1 = x2 - bar_px
        y  = H - margin
        cap_h = H * 0.012

        # Semi-transparent backing for legibility on bright/dark backgrounds
        backing = plt.Rectangle(
            (x1 - W * 0.02, y - H * 0.06),
            bar_px + W * 0.04, H * 0.09,
            linewidth=0, facecolor="black", alpha=0.45, zorder=4,
        )
        ax.add_patch(backing)

        # White bar + end caps
        ax.plot([x1, x2], [y, y], color="white", lw=3,
                solid_capstyle="butt", zorder=5)
        ax.plot([x1, x1], [y - cap_h, y + cap_h], color="white", lw=2, zorder=5)
        ax.plot([x2, x2], [y - cap_h, y + cap_h], color="white", lw=2, zorder=5)

        bar_label = f"{bar_um:g} µm" if bar_um < 1000 else f"{bar_um/1000:g} mm"
        ax.text((x1 + x2) / 2, y - H * 0.025, bar_label,
                ha="center", va="bottom",
                color="white", fontsize=9, fontweight="bold", zorder=5)

    # ── Legend ────────────────────────────────────────────────────────────────
    max_label = "Max area (Relaxed)"
    min_label = "Min area (Contracted)"
    if max_area_um2 is not None:
        max_label += f"\n({max_area_um2:.0f} µm²)"
    if min_area_um2 is not None:
        min_label += f"\n({min_area_um2:.0f} µm²)"

    legend_elements = [
        Line2D([0], [0], color=(1.0, 0.0, 0.0), linewidth=2.5, label=max_label),
        Line2D([0], [0], color=(0.0, 0.0, 1.0), linewidth=2.5, label=min_label),
    ]
    legend = ax.legend(
        handles=legend_elements,
        loc="upper left",
        fontsize=8,
        framealpha=0.75,
        facecolor="white",
        edgecolor="#888888",
        frameon=True,
        handlelength=1.8,
    )

    # ── Title ─────────────────────────────────────────────────────────────────
    title = "Max ↔ Min Contour Overlay"
    if roi_name:
        title = f"Max ↔ Min Contour — {roi_name}"
    ax.set_title(title, fontsize=12, fontweight="bold", pad=8)

    fig.tight_layout(pad=0.5)
    fig.savefig(path, dpi=300, bbox_inches="tight",
                facecolor="white", edgecolor="none")
    plt.close(fig)


class VideoExportWorker(QThread):
    """
    Re-encodes the loaded video with ROI overlay (contour + bounding box
    + centroid cross-hair, matching the live preview) and an optional
    scale bar burned into every frame, then writes it to disk as .mp4.

    The overlay is re-tracked on every frame using the same
    nearest-centroid re-detection algorithm as SignalExtractWorker, so
    the box/contour/centroid follow the organoid as it moves instead of
    staying frozen at its frame-0 position.
    """
    progress = pyqtSignal(int)     # 0-100
    finished = pyqtSignal(str)     # output path
    error    = pyqtSignal(str)

    def __init__(self, video_path, rois, out_path, threshold,
                 px_per_um=0.0, draw_scale_bar_flag=True,
                 draw_roi_overlay=True, parent=None):
        super().__init__(parent)
        self.video_path = video_path
        self.rois = rois
        self.out_path = out_path
        self.threshold = threshold
        self.px_per_um = px_per_um
        self.draw_scale_bar_flag = draw_scale_bar_flag
        self.draw_roi_overlay = draw_roi_overlay

    def run(self):
        try:
            cap = cv2.VideoCapture(self.video_path)
            if not cap.isOpened():
                self.error.emit("Could not open source video.")
                return

            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            W   = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            H   = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT)) or 1

            fourcc = cv2.VideoWriter_fourcc(*"mp4v")
            writer = cv2.VideoWriter(self.out_path, fourcc, fps, (W, H))
            if not writer.isOpened():
                self.error.emit("Could not create output video writer "
                                 "(check codec support / output path).")
                return

            # ── Initialise per-ROI tracking state (frame-0 box/contour) ─────
            kernel = np.ones((5, 5), np.uint8)
            track_states = []
            if self.draw_roi_overlay:
                for roi in self.rois:
                    x, y, w, h = roi["box"]
                    cnt0 = roi.get("contour")
                    if cnt0 is not None:
                        M = cv2.moments(cnt0)
                        if M["m00"] > 0:
                            cx0, cy0 = M["m10"] / M["m00"], M["m01"] / M["m00"]
                        else:
                            cx0, cy0 = x + w / 2.0, y + h / 2.0
                    else:
                        cx0, cy0 = x + w / 2.0, y + h / 2.0
                    track_states.append({
                        "w": w, "h": h,
                        "center": (cx0, cy0),
                        "cnt": cnt0,
                        "box": (x, y, w, h),
                    })

            frame_idx = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    break
                vis = frame.copy()

                if self.draw_roi_overlay:
                    # ── Re-locate every ROI on this frame ───────────────────
                    # Nearest contour to where each organoid was last seen
                    # (same logic as SignalExtractWorker), with a fallback
                    # to the largest detected contour if track is lost, so
                    # the overlay keeps following the organoid frame-to-frame
                    # instead of staying fixed at its initial position.
                    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                    blur = cv2.GaussianBlur(gray, (11, 11), 0)
                    _, th_full = cv2.threshold(blur, self.threshold, 255,
                                                cv2.THRESH_BINARY_INV)
                    th_full = cv2.morphologyEx(th_full, cv2.MORPH_OPEN,
                                                kernel, iterations=3)
                    cnts_all, _ = cv2.findContours(th_full, cv2.RETR_EXTERNAL,
                                                    cv2.CHAIN_APPROX_SIMPLE)

                    for i, st in enumerate(track_states):
                        cx_prev, cy_prev = st["center"]
                        w, h = st["w"], st["h"]
                        search_r = max(w, h) * 0.6   # max plausible drift/frame

                        best, best_d = None, None
                        for c in cnts_all:
                            if cv2.contourArea(c) < 30:
                                continue
                            Mc = cv2.moments(c)
                            if Mc["m00"] <= 0:
                                continue
                            ccx, ccy = Mc["m10"]/Mc["m00"], Mc["m01"]/Mc["m00"]
                            d = ((ccx-cx_prev)**2 + (ccy-cy_prev)**2) ** 0.5
                            if d <= search_r and (best_d is None or d < best_d):
                                best, best_d = c, d

                        if best is None and cnts_all:
                            cand = max(cnts_all, key=cv2.contourArea)
                            if cv2.contourArea(cand) >= 30:
                                best = cand

                        if best is not None:
                            Mc = cv2.moments(best)
                            cx, cy = Mc["m10"]/Mc["m00"], Mc["m01"]/Mc["m00"]
                            st["center"] = (cx, cy)
                            st["cnt"]    = best
                            st["box"]    = cv2.boundingRect(best)
                        # else: track briefly lost — keep last known box/contour

                        x, y, w, h = st["box"]
                        cnt = st["cnt"]
                        if cnt is not None:
                            cv2.drawContours(vis, [cnt], -1, (0, 0, 255), 2)
                        cv2.rectangle(vis, (x, y), (x + w, y + h),
                                      (0, 255, 0), 2)
                        cv2.putText(vis, f"ROI {i+1}", (x, max(y - 8, 10)),
                                    cv2.FONT_HERSHEY_SIMPLEX, 0.7,
                                    (0, 255, 255), 2)
                        if cnt is not None:
                            ccx, ccy = (int(round(st["center"][0])),
                                        int(round(st["center"][1])))
                            arm = 18
                            cv2.line(vis, (ccx - arm, ccy), (ccx + arm, ccy),
                                      (0, 165, 255), 2)
                            cv2.line(vis, (ccx, ccy - arm), (ccx, ccy + arm),
                                      (0, 165, 255), 2)
                            cv2.circle(vis, (ccx, ccy), 5, (0, 165, 255), -1)

                if self.draw_scale_bar_flag and self.px_per_um > 0:
                    vis = draw_scale_bar(vis, self.px_per_um)

                # ── Timestamp label (top-left) ────────────────────────────
                t_sec = frame_idx / fps
                ts_text = f"{t_sec:.2f} s"
                font      = cv2.FONT_HERSHEY_SIMPLEX
                ts_scale  = max(0.8, H / 600)
                ts_thick  = max(2, int(ts_scale * 2))
                (tw, th), baseline = cv2.getTextSize(ts_text, font, ts_scale, ts_thick)
                pad = 10
                cv2.rectangle(vis, (pad-4, pad-4), (pad+tw+4, pad+th+baseline+4), (0,0,0), -1)
                cv2.putText(vis, ts_text, (pad, pad+th), font, ts_scale,
                            (255,255,255), ts_thick, cv2.LINE_AA)

                writer.write(vis)
                frame_idx += 1
                if frame_idx % 5 == 0 or frame_idx == total:
                    self.progress.emit(int(frame_idx / total * 100))

            cap.release()
            writer.release()
            self.finished.emit(self.out_path)
        except Exception as e:
            self.error.emit(str(e))


# ─────────────────────────────────────────────────────────────────────────────
#  Worker: signal extraction
# ─────────────────────────────────────────────────────────────────────────────

class SignalExtractWorker(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal(dict)   # roi_name → data dict
    error    = pyqtSignal(str)

    def __init__(self, video_path, rois, px_per_um, threshold,
                 fps_override=None, trim_start_s=0.0, trim_end_s=0.0):
        super().__init__()
        self.path          = video_path
        self.rois          = rois
        self.px_per_um     = px_per_um
        self.threshold     = threshold
        self.fps_override  = fps_override
        self.trim_start_s  = float(trim_start_s)
        self.trim_end_s    = float(trim_end_s)    # 0 = until end

    def run(self):
        try:
            cap = cv2.VideoCapture(self.path)
            fps = cap.get(cv2.CAP_PROP_FPS)
            if fps == 0 or np.isnan(fps):
                fps = 30.0
            if self.fps_override:
                fps = float(self.fps_override)
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

            # ── Trim: compute frame range ────────────────────────────────────
            trim_start_fr = int(round(self.trim_start_s * fps))
            trim_start_fr = max(0, min(trim_start_fr, total_frames - 1))
            if self.trim_end_s > 0:
                trim_end_fr = int(round(self.trim_end_s * fps))
                trim_end_fr = min(trim_end_fr, total_frames)
            else:
                trim_end_fr = total_frames   # 0 = no trim → use full video

            # Seek to trim start
            if trim_start_fr > 0:
                cap.set(cv2.CAP_PROP_POS_FRAMES, trim_start_fr)

            ret, frame0 = cap.read()
            if not ret:
                self.error.emit("Cannot read video frames.")
                cap.release()
                return

            gray0 = cv2.cvtColor(frame0, cv2.COLOR_BGR2GRAY)
            H, W = gray0.shape
            kernel = np.ones((5, 5), np.uint8)
            px2 = self.px_per_um ** 2

            # Initialise per-ROI tracking state. Each ROI is tracked by its
            # centroid frame-to-frame, so the analysis window follows the
            # organoid instead of staying fixed at its frame-0 position.
            states = []
            for roi in self.rois:
                x, y, w, h = roi["box"]
                cnt0 = roi["contour"]
                M = cv2.moments(cnt0)
                if M["m00"] > 0:
                    cx0, cy0 = M["m10"] / M["m00"], M["m01"] / M["m00"]
                else:
                    cx0, cy0 = x + w / 2.0, y + h / 2.0

                # Add 30% padding on each side so the organoid stays fully
                # inside the crop window even when it relaxes (expands) beyond
                # its frame-0 bounding-box size. The same padded w/h is used
                # for every frame so the crop window size is consistent.
                PAD = 0.30
                w = min(int(round(w * (1 + PAD))), W)
                h = min(int(round(h * (1 + PAD))), H)

                x0, y0, cw, ch = _centered_box(cx0, cy0, w, h, W, H)
                mask_full = np.zeros_like(gray0)
                cv2.drawContours(mask_full, [cnt0], -1, 255, thickness=cv2.FILLED)
                roi_mask = mask_full[y0:y0+ch, x0:x0+cw]
                ref_roi  = gray0[y0:y0+ch, x0:x0+cw]
                ref_roi  = cv2.bitwise_and(ref_roi, ref_roi, mask=roi_mask)
                # Rolling-reference window: keep the last N valid frames so
                # the reference slowly adapts to lighting/position drift
                # instead of staying fixed at frame-0 forever.
                _ref_window_sec = 2.0   # seconds of history to average
                states.append({
                    "w": w, "h": h, "center": (cx0, cy0),
                    "center0": (cx0, cy0),
                    "mask": roi_mask,
                    "ref": ref_roi, "prev": ref_roi.copy(),
                    "ref_buf": [ref_roi.astype(np.float32)],
                    "ref_win_frames": max(1, int(round(fps * _ref_window_sec))),
                    "motion_accum": np.zeros_like(ref_roi, dtype=np.float32),
                    "c": [], "v": [], "a": [],
                    "frame_cnts": [],   # per-frame contour (local coords)
                    "frame_bgs":  [],   # per-frame crop image
                    "frame_offsets": [], # per-frame (dcx, dcy) centroid offset
                    "max_area": -1, "min_area": float("inf"),
                    "max_cnt": None, "min_cnt": None, "max_bg": None,
                    "max_dcx": 0, "max_dcy": 0,
                    "min_dcx": 0, "min_dcy": 0,
                    "lost_count": 0,
                })

            frame_idx = 0   # relative index within trimmed range
            abs_frame = trim_start_fr  # absolute position in video
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break
                # Stop at trim end
                if abs_frame >= trim_end_fr:
                    break
                abs_frame += 1
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                blur = cv2.GaussianBlur(gray, (11, 11), 0)
                _, th_full = cv2.threshold(blur, self.threshold, 255,
                                            cv2.THRESH_BINARY_INV)
                th_full = cv2.morphologyEx(th_full, cv2.MORPH_OPEN,
                                            kernel, iterations=3)
                cnts_all, _ = cv2.findContours(th_full, cv2.RETR_EXTERNAL,
                                                cv2.CHAIN_APPROX_SIMPLE)

                for st in states:
                    cx_prev, cy_prev = st["center"]
                    w, h = st["w"], st["h"]
                    search_r = max(w, h) * 0.6   # max plausible drift/frame

                    # ── re-locate the organoid: nearest contour to where it
                    #    was last seen, so a translating organoid is still
                    #    tracked correctly even as it drifts across frames ──
                    best, best_d = None, None
                    for c in cnts_all:
                        if cv2.contourArea(c) < 30:
                            continue
                        Mc = cv2.moments(c)
                        if Mc["m00"] <= 0:
                            continue
                        ccx, ccy = Mc["m10"]/Mc["m00"], Mc["m01"]/Mc["m00"]
                        d = ((ccx-cx_prev)**2 + (ccy-cy_prev)**2) ** 0.5
                        if d <= search_r and (best_d is None or d < best_d):
                            best, best_d = c, d

                    if best is None and cnts_all:
                        # Lost track (organoid drifted further than expected,
                        # or briefly dropped out) — fall back to the largest
                        # detected contour so tracking recovers automatically.
                        cand = max(cnts_all, key=cv2.contourArea)
                        if cv2.contourArea(cand) >= 30:
                            best = cand

                    if best is not None:
                        Mc = cv2.moments(best)
                        cx, cy = Mc["m10"]/Mc["m00"], Mc["m01"]/Mc["m00"]

                        # ── ROI 이상 감지 (면적 급변 / centroid 급이동 / solidity 저하) ──
                        av_raw = cv2.contourArea(best) / px2
                        hull_a = cv2.contourArea(cv2.convexHull(best))
                        solidity = (av_raw * px2 / hull_a) if hull_a > 0 else 1.0
                        anomaly = False

                        if len(st["a"]) >= 5:
                            ref_area = np.median(st["a"][-10:])  # 최근 10프레임 중앙값
                            # 면적이 기준의 40% 이상 갑자기 변하면 이상
                            if ref_area > 0 and abs(av_raw - ref_area) / ref_area > 0.40:
                                anomaly = True
                            # centroid가 organoid 지름의 25% 이상 점프하면 이상
                            organoid_r = (ref_area * px2 / np.pi) ** 0.5
                            if ((cx - cx_prev)**2 + (cy - cy_prev)**2) ** 0.5 > organoid_r * 0.5:
                                anomaly = True
                            # solidity가 갑자기 0.45 이하로 떨어지면 이상
                            if solidity < 0.45:
                                anomaly = True

                        if anomaly:
                            st["anomaly_count"] = st.get("anomaly_count", 0) + 1
                            # 이상 시 → 직전 유효값 유지 (freeze)
                            cx, cy = cx_prev, cy_prev
                            av = st["a"][-1] if st["a"] else av_raw
                            cnt_full = None  # 마지막 정상 mask 재사용
                            # 3프레임 연속 이상이면 Otsu로 재탐색
                            if st.get("anomaly_count", 0) >= 3:
                                redet_cnts = [c for c in cnts_all
                                              if cv2.contourArea(c) > 30]
                                if redet_cnts:
                                    # 화면 중심에 가장 가까운 contour로 재초기화
                                    frame_cx, frame_cy = W / 2, H / 2
                                    best_redet = min(
                                        redet_cnts,
                                        key=lambda c: (
                                            (cv2.moments(c)["m10"] / max(cv2.moments(c)["m00"], 1) - frame_cx) ** 2 +
                                            (cv2.moments(c)["m01"] / max(cv2.moments(c)["m00"], 1) - frame_cy) ** 2
                                        )
                                    )
                                    Mc2 = cv2.moments(best_redet)
                                    if Mc2["m00"] > 0:
                                        cx, cy = Mc2["m10"]/Mc2["m00"], Mc2["m01"]/Mc2["m00"]
                                        av = cv2.contourArea(best_redet) / px2
                                        cnt_full = best_redet
                                        st["anomaly_count"] = 0
                        else:
                            st["anomaly_count"] = 0
                            av = av_raw
                            cnt_full = best   # ← 정상 프레임: best contour 사용

                        st["center"]     = (cx, cy)
                        st["lost_count"] = 0
                    else:
                        cx, cy = cx_prev, cy_prev
                        st["lost_count"] += 1
                        av = st["a"][-1] if st["a"] else 0.0
                        cnt_full = None

                    # Crop re-centered on the (tracked) current centroid —
                    # this is what removes whole-organoid translation from
                    # the area / intensity signals below.
                    x2, y2, cw, ch = _centered_box(cx, cy, w, h, W, H)
                    curr_full = gray[y2:y2+ch, x2:x2+cw]

                    if cnt_full is not None:
                        local_cnt  = cnt_full - np.array([[x2, y2]])
                        local_mask = np.zeros((ch, cw), np.uint8)
                        cv2.drawContours(local_mask, [local_cnt], -1, 255,
                                          thickness=cv2.FILLED)
                    else:
                        local_mask = st["mask"]   # reuse last good mask
                        local_cnt  = None

                    # ── Centroid offset for contour normalization ────────────
                    # Store the displacement of the current centroid from the
                    # initial centroid (cx0, cy0) so that max/min contours can
                    # later be shifted to a common coordinate system, removing
                    # whole-organoid translation from the overlay image.
                    cx0_st, cy0_st = st["center0"]
                    dcx = int(round(cx - cx0_st))
                    dcy = int(round(cy - cy0_st))

                    if av > st["max_area"]:
                        st["max_area"] = av
                        st["max_cnt"]  = local_cnt
                        st["max_bg"]   = curr_full.copy()
                        st["max_dcx"]  = dcx
                        st["max_dcy"]  = dcy
                    if 0 < av < st["min_area"]:
                        st["min_area"] = av
                        st["min_cnt"]  = local_cnt
                        st["min_dcx"]  = dcx
                        st["min_dcy"]  = dcy
                    st["a"].append(av)
                    # Store per-frame contour + background + crop origin (float)
                    st["frame_cnts"].append(local_cnt)
                    st["frame_bgs"].append(curr_full.copy())
                    st["frame_offsets"].append((float(x2), float(y2)))

                    curr = cv2.bitwise_and(curr_full, curr_full, mask=local_mask)

                    # ── Rolling reference ────────────────────────────────────
                    if curr.shape == st["ref"].shape:
                        st["ref_buf"].append(curr.astype(np.float32))
                        if len(st["ref_buf"]) > st["ref_win_frames"]:
                            st["ref_buf"].pop(0)
                        rolling_ref = np.mean(st["ref_buf"], axis=0).astype(np.uint8)
                    else:
                        rolling_ref = st["ref"]

                    # ── ECC sub-pixel alignment ──────────────────────────────
                    # Estimate and remove the residual translation between
                    # rolling_ref and curr (sub-pixel drift not fully absorbed
                    # by centroid re-centering) before computing the diff.
                    # This means the heatmap and motion signal reflect only
                    # genuine contractile deformation, not rigid-body motion.
                    try:
                        warp_matrix = np.eye(2, 3, dtype=np.float32)
                        criteria = (cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT,
                                    30, 1e-3)
                        _, warp_matrix = cv2.findTransformECC(
                            rolling_ref.astype(np.float32),
                            curr.astype(np.float32),
                            warp_matrix,
                            cv2.MOTION_TRANSLATION,
                            criteria,
                            inputMask=local_mask,
                            gaussFiltSize=5,
                        )
                        curr_aligned = cv2.warpAffine(
                            curr, warp_matrix,
                            (curr.shape[1], curr.shape[0]),
                            flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                        )
                    except cv2.error:
                        curr_aligned = curr  # ECC failed — use as-is

                    # Erode mask slightly so boundary pixels (where warp
                    # introduces edge artefacts) are excluded from the diff.
                    erode_k = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
                    inner_mask = cv2.erode(local_mask, erode_k, iterations=1)

                    diff_raw = cv2.absdiff(rolling_ref, curr_aligned)
                    diff = cv2.bitwise_and(diff_raw, diff_raw, mask=inner_mask)
                    # ─────────────────────────────────────────────────────────

                    st["motion_accum"] += diff
                    st["c"].append(float(np.sum(diff)) / 1000.0)
                    if curr.shape == st["prev"].shape:
                        st["v"].append(float(np.sum(cv2.absdiff(st["prev"], curr))) / 1000.0)
                    else:
                        st["v"].append(st["v"][-1] if st["v"] else 0.0)
                    st["prev"] = curr
                    st["mask"] = local_mask

                frame_idx += 1
                trim_total = max(trim_end_fr - trim_start_fr, 1)
                if frame_idx % 20 == 0:
                    self.progress.emit(int(frame_idx / trim_total * 100))

            cap.release()
            gc.collect()

            # Package results
            results = {}
            for i, st in enumerate(states):
                c = np.array(st["c"]); v = np.array(st["v"]); a = np.array(st["a"])
                c_corr, c_base = _robust_baseline_correct(c, fps, return_baseline=True) if len(c) else (c, c)
                v_corr = _robust_baseline_correct(v, fps) if len(v) else v
                a_corr, a_base = _robust_baseline_correct(a, fps, return_baseline=True) if len(a) else (a, a)

                unstable = _detect_unstable_ranges(c_base, fps) + _detect_unstable_ranges(a_base, fps)
                unstable = sorted(unstable)
                merged = []
                for s, e in unstable:
                    if merged and s <= merged[-1][1] + 1.0:
                        merged[-1] = (merged[-1][0], max(merged[-1][1], e))
                    else:
                        merged.append((s, e))

                mn = cv2.normalize(st["motion_accum"], None, 0, 255,
                                    cv2.NORM_MINMAX).astype(np.uint8)
                hm = cv2.applyColorMap(mn, cv2.COLORMAP_JET)
                ref_c = cv2.cvtColor(st["ref"], cv2.COLOR_GRAY2BGR)
                hm_blend = cv2.addWeighted(ref_c, 0.4, hm, 0.6, 0)

                # ── Cycle-based Max↔Min contour selection ────────────────────
                # Find the most representative beat cycle in the area signal,
                # then pick the max-area frame (relaxed) and min-area frame
                # (contracted) from WITHIN that same cycle so both contours
                # share the same coordinate frame and the overlay is accurate.
                area_arr = np.array(st["a"])
                best_max_idx = None
                best_min_idx = None
                peaks_a   = np.array([], dtype=int)
                troughs_a = np.array([], dtype=int)
                try:
                    from scipy.signal import find_peaks
                    cycle_dist = max(1, int(fps * 1.0))
                    peaks_a,  _ = find_peaks( area_arr, distance=cycle_dist)
                    troughs_a, _ = find_peaks(-area_arr, distance=cycle_dist)
                    if len(peaks_a) and len(troughs_a):
                        # Pick the cycle with the largest area swing
                        best_swing = -1
                        for pk in peaks_a:
                            # nearest trough after this peak
                            after = troughs_a[troughs_a > pk]
                            if len(after) == 0:
                                continue
                            tr = after[0]
                            swing = area_arr[pk] - area_arr[tr]
                            if swing > best_swing:
                                best_swing = swing
                                best_max_idx = int(pk)
                                best_min_idx = int(tr)
                except Exception:
                    pass

                # Fall back to whole-video max/min if cycle detection failed
                if best_max_idx is None:
                    best_max_idx = int(np.argmax(area_arr)) if len(area_arr) else None
                if best_min_idx is None:
                    best_min_idx = int(np.argmin(area_arr)) if len(area_arr) else None

                # Build the contour overlay using the selected cycle frames
                frame_cnts = st["frame_cnts"]
                frame_bgs  = st["frame_bgs"]
                max_cnt = frame_cnts[best_max_idx] if best_max_idx is not None and best_max_idx < len(frame_cnts) else st["max_cnt"]
                min_cnt = frame_cnts[best_min_idx] if best_min_idx is not None and best_min_idx < len(frame_cnts) else st["min_cnt"]
                max_bg  = frame_bgs[best_max_idx]  if best_max_idx is not None and best_max_idx < len(frame_bgs)  else st["max_bg"]

                cnt_vis = cv2.cvtColor(
                    max_bg if max_bg is not None else st["ref"],
                    cv2.COLOR_GRAY2BGR)
                if max_cnt is not None:
                    cv2.drawContours(cnt_vis, [max_cnt], -1, (0, 0, 255), 2)
                if min_cnt is not None:
                    cv2.drawContours(cnt_vis, [min_cnt], -1, (255, 0, 0), 2)
                # ─────────────────────────────────────────────────────────────

                results[f"ROI {i+1}"] = {
                    "amp": c_corr.tolist(), "vel": v_corr.tolist(),
                    "area": a_corr.tolist(), "fps": fps,
                    "heatmap": cv2.cvtColor(hm_blend, cv2.COLOR_BGR2RGB),
                    "contour_img": cv2.cvtColor(cnt_vis, cv2.COLOR_BGR2RGB),
                    "unstable_ranges": merged,
                    "frame_cnts":   st["frame_cnts"],
                    "frame_bgs":    st["frame_bgs"],
                    "frame_offsets": st["frame_offsets"],
                    "rest_idx":     best_max_idx,
                    "peak_idx":     best_min_idx,
                    "area_peaks":   peaks_a.tolist()   if len(peaks_a)   else [],
                    "area_troughs": troughs_a.tolist() if len(troughs_a) else [],
                }
            self.finished.emit(results)
        except Exception as e:
            self.error.emit(str(e))


# ─────────────────────────────────────────────────────────────────────────────
#  Per-ROI result card widget
# ─────────────────────────────────────────────────────────────────────────────

class ROICard(QWidget):
    """Shows heatmap + contour overlay + signal plot + extracted features."""

    def __init__(self, roi_name: str, data: dict,
                 sg_window: int, baseline_pct: int, parent=None):
        super().__init__(parent)
        self._name      = roi_name
        self._data      = data
        self._sg_win    = sg_window
        self._bl_pct    = baseline_pct
        self._features: dict = {}
        self._beat_stats_df  = None   # pd.DataFrame — beat-to-beat CSV
        self._avg_stats_df   = None   # pd.DataFrame — averaged transient CSV
        self._avg_delta_stats_df = None  # pd.DataFrame — ΔArea averaged transient CSV

        # Debounce timer for the prominence/distance spinboxes: re-running
        # peak-detection + both plots on every single click/keystroke is
        # what made the UI feel sluggish once more panels were added.
        # Coalescing rapid changes into one redraw ~120ms after the user
        # stops adjusting keeps the UI responsive while typing/dragging.
        self._update_timer = QTimer(self)
        self._update_timer.setSingleShot(True)
        self._update_timer.timeout.connect(self._update_plot)

        self.setObjectName("roiCard")
        self.setAttribute(Qt.WA_StyledBackground, True)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(12)

        # Title
        title = _lbl(f"  {roi_name}", bold=True, size=10)
        title.setObjectName("roiTitle")
        layout.addWidget(title)

        body = QHBoxLayout()

        # Left: Contour only (heatmap removed; contour updated by Compute Activation Map)
        left = QVBoxLayout()
        self._hm_lbl  = QLabel()   # hidden, kept for compat
        self._cnt_lbl = QLabel()
        self._cnt_lbl.setFixedSize(160, 160)
        self._cnt_lbl.setAlignment(Qt.AlignCenter)
        self._cnt_lbl.setStyleSheet("border:1px solid #ccc;")
        self._cnt_lbl.setText("Max↔Min\nContour")
        left.addWidget(_lbl("Max↔Min Contour", size=8))
        left.addWidget(self._cnt_lbl)
        left.addStretch()
        body.addLayout(left)

        # Centre: signal plots (Motion + Area full trace, then Averaged Transients)
        centre_layout = QVBoxLayout()

        self._fig, (self._ax1, self._ax2) = plt.subplots(
            2, 1, figsize=(7, 4), sharex=True)
        self._canvas = FigureCanvas(self._fig)
        self._canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self._canvas.setMinimumHeight(290)
        centre_layout.addWidget(self._canvas, stretch=1)

        # ── Averaged Transient sub-plots (Motion + Area) ──────────────────
        avg_lbl = _lbl("AVERAGED TRANSIENTS  /  MOTION & AREA", size=8)
        avg_lbl.setStyleSheet("color:#444; padding-top:6px;")
        centre_layout.addWidget(avg_lbl)
        self._avg_fig, (self._avg_ax_motion,
                        self._avg_ax_area) = plt.subplots(
            1, 2, figsize=(10, 3.2))
        self._avg_canvas = FigureCanvas(self._avg_fig)
        self._avg_canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self._avg_canvas.setFixedHeight(280)
        centre_layout.addWidget(self._avg_canvas)

        body.addLayout(centre_layout, stretch=1)

        # Right: sliders + feature table
        right = QVBoxLayout()
        right.addWidget(_lbl("Peak detection", bold=True, size=9))

        self._prom_spin = QDoubleSpinBox()
        self._prom_spin.setRange(0.01, 20.0); self._prom_spin.setValue(0.5)
        self._prom_spin.setSingleStep(0.1); self._prom_spin.setFont(ARIAL_SM)
        self._dist_spin = QSpinBox()
        self._dist_spin.setRange(1, 300); self._dist_spin.setValue(15)
        self._dist_spin.setFont(ARIAL_SM)

        form = QFormLayout()
        form.addRow("Min prominence:", self._prom_spin)
        form.addRow("Min distance (fr):", self._dist_spin)
        right.addLayout(form)

        self._btn_update = _btn("↻ Update", color="#d4f0d4")
        right.addWidget(self._btn_update)
        right.addSpacing(6)

        self._feat_table = QTableWidget(0, 2)
        self._feat_table.setHorizontalHeaderLabels(["Parameter", "Value"])
        self._feat_table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.Stretch)
        self._feat_table.horizontalHeader().setSectionResizeMode(
            1, QHeaderView.ResizeToContents)
        self._feat_table.setFont(ARIAL_SM)
        self._feat_table.setMinimumWidth(230)
        style_table(self._feat_table, editable=False)
        right.addWidget(self._feat_table, stretch=1)
        body.addLayout(right)

        layout.addLayout(body)

        # Wire up
        self._btn_update.clicked.connect(self._update_plot)
        self._prom_spin.valueChanged.connect(self._schedule_update)
        self._dist_spin.valueChanged.connect(self._schedule_update)

        self._show_images()
        self._update_plot()

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _np_to_pixmap(self, arr: np.ndarray, w: int, h: int) -> QPixmap:
        arr = np.ascontiguousarray(arr)
        qi  = QImage(arr.data, arr.shape[1], arr.shape[0],
                     arr.strides[0], QImage.Format_RGB888)
        return QPixmap.fromImage(qi).scaled(w, h, Qt.KeepAspectRatio,
                                             Qt.SmoothTransformation)

    def _show_images(self):
        hm  = self._data.get("heatmap")
        cnt = self._data.get("contour_img")
        if hm  is not None: self._hm_lbl.setPixmap(self._np_to_pixmap(hm, 160, 140))
        if cnt is not None: self._cnt_lbl.setPixmap(self._np_to_pixmap(cnt, 160, 140))

    def _schedule_update(self):
        """Restart the debounce timer; only the *last* change within the
        120ms window actually triggers a recompute + redraw."""
        self._update_timer.start(120)

    def _update_plot(self):
        amp  = np.array(self._data["amp"])
        area = np.array(self._data["area"])
        fps  = float(self._data["fps"])
        unstable_ranges = self._data.get("unstable_ranges", [])
        win  = self._sg_win if self._sg_win % 2 == 1 else self._sg_win + 1
        win  = max(5, min(win, len(amp) - (len(amp) % 2 == 0)))

        cont_s = savgol_filter(amp,  win, 3) if len(amp)  > win else amp.copy()
        area_s = savgol_filter(area, win, 3) if len(area) > win else area.copy()

        prom = self._prom_spin.value()
        dist = self._dist_spin.value()
        # Local (rolling), rather than single global, height cutoff: a video
        # can have one segment that's genuinely lower-contrast (e.g. after a
        # focus/illumination shift) than the rest. A single global min-max
        # or percentile range pulls the cutoff up to whatever the loudest
        # part of the recording looks like, silently dropping real — just
        # smaller-amplitude — beats in the quieter segment. Computing the
        # 5th/95th percentile in a rolling window instead lets the cutoff
        # track local signal scale.
        win_h = max(9, int(round(fps * 6)))
        if win_h % 2 == 0:
            win_h += 1
        win_h = min(win_h, len(cont_s) - (1 - len(cont_s) % 2))
        if win_h >= 5:
            local_p5  = percentile_filter(cont_s, 5,  size=win_h, mode="nearest")
            local_p95 = percentile_filter(cont_s, 95, size=win_h, mode="nearest")
            cutoff = local_p5 + (local_p95 - local_p5) * 0.20
        else:
            p5, p95 = np.percentile(cont_s, [5, 95])
            cutoff = p5 + (p95 - p5) * 0.20
        peaks, _ = find_peaks(cont_s, prominence=prom, distance=dist,
                               height=cutoff)

        # Features
        bpm = dur = rel = amp_m = area_m = fac = 0.0
        rise = ai = cr_ratio = fwhm = vco_score = bpm_area = dur_area = 0.0
        rise_area = rel_area = 0.0
        rise_area_k = rel_area_k = dur_area_k = fac_k = np.array([])
        subtype = "N/A"
        troughs = np.array([], dtype=int)
        peak_frame = 0
        n_artifacts = 0
        left_ips = right_ips = wh = np.array([])
        keep = np.array([], dtype=bool)

        if len(peaks) > 0:
            rel_h = self._bl_pct / 100.0
            troughs, _ = find_peaks(-cont_s, distance=dist)

            # ── Local-trough-based width (replaces scipy's peak_widths) ────
            # scipy.signal.peak_widths anchors each peak's width to the
            # HIGHER of its two neighboring minima (prominence-based), which
            # — when the baseline drifts between beats — can sit well above
            # the true local trough, showing up as a width/duration line
            # that visually "floats" mid-trace instead of reaching down near
            # the actual baseline. Anchoring to the LOWER (deeper) of the
            # two adjacent troughs keeps the measured duration tied to
            # where the signal actually returns toward rest on each side.
            n = len(cont_s)
            max_gap = max(dist, int(round(fps * 2.5)))   # don't reach further
                                                           # than ~2.5s for a
                                                           # "local" trough
            lefts, rights, heights, bases = [], [], [], []
            for p in peaks:
                left_tr  = troughs[(troughs < p) & (troughs >= p - max_gap)]
                right_tr = troughs[(troughs > p) & (troughs <= p + max_gap)]
                if len(left_tr):
                    left_base = cont_s[left_tr[-1]]
                elif len(right_tr):
                    left_base = cont_s[right_tr[0]]
                else:
                    lo, hi = max(0, p - max_gap), min(n, p + max_gap)
                    left_base = np.percentile(cont_s[lo:hi], 10)
                if len(right_tr):
                    right_base = cont_s[right_tr[0]]
                elif len(left_tr):
                    right_base = cont_s[left_tr[-1]]
                else:
                    right_base = left_base
                base_local = min(left_base, right_base)
                target = cont_s[p] - rel_h * (cont_s[p] - base_local)

                li = p
                while li > 0 and li > p - max_gap and cont_s[li] > target:
                    li -= 1
                ri = p
                while ri < n - 1 and ri < p + max_gap and cont_s[ri] > target:
                    ri += 1
                lefts.append(li); rights.append(ri); heights.append(target)
                bases.append(base_local)

            left_ips  = np.array(lefts,  dtype=float)
            right_ips = np.array(rights, dtype=float)
            wh        = np.array(heights)

            # ── Reject artifact beats ───────────────────────────────────────
            # A motion/focus artifact (camera shake, brief defocus) usually
            # shows up as one or two beats with a prominence far larger than
            # the rest — these get excluded from the averaged BPM/duration/
            # amplitude stats (but are still plotted, in red, so nothing is
            # hidden from view).
            prominences = cont_s[peaks] - np.array(bases)
            keep = _reject_outlier_peaks(prominences)
            n_artifacts = int(np.sum(~keep))

            peaks_k, left_k, right_k = peaks[keep], left_ips[keep], right_ips[keep]
            if len(peaks_k) == 0:           # everything got flagged — fall back
                peaks_k, left_k, right_k, keep = peaks, left_ips, right_ips, np.ones(len(peaks), dtype=bool)
                n_artifacts = 0

            bpm = (60.0 / (np.mean(np.diff(peaks_k)) / fps)
                   if len(peaks_k) > 1 else 0.0)
            base = np.mean(cont_s[troughs]) if len(troughs) else cont_s.min()
            amp_m  = float(np.mean(cont_s[peaks_k]) - base)
            dur    = float(np.mean(right_k - left_k) * 1000.0 / fps)
            rel    = float(np.mean(right_k - peaks_k) * 1000.0 / fps)

            # ── Rise time: left edge → peak (contraction phase) ─────────────
            rise   = float(np.mean(peaks_k - left_k) * 1000.0 / fps)

            # ── Asymmetry Index: (decay - rise) / (decay + rise) ─────────────
            # vCO: long plateau → decay >> rise → AI closer to +1
            # aCO: triangular    → decay ≈ rise  → AI closer to 0
            decay = rel   # frames from peak → right edge (in ms already)
            rise_ms = rise
            decay_ms = decay
            ai = ((decay_ms - rise_ms) / (decay_ms + rise_ms)
                  if (decay_ms + rise_ms) > 0 else 0.0)

            # ── Contraction / Relaxation ratio ────────────────────────────────
            # vCO: relaxation >> contraction → CR_ratio < 1
            # aCO: roughly equal             → CR_ratio ≈ 1
            cr_ratio = (rise_ms / decay_ms
                        if decay_ms > 0 else np.nan)

            # ── FWHM (Full Width at Half Maximum) — per-beat, then averaged ──
            fwhm_list = []
            for p, lp, rp in zip(peaks_k,
                                  left_k.astype(int),
                                  right_k.astype(int)):
                pk_val  = cont_s[p]
                # Use the actual local base for this beat (already stored in bases[])
                b_idx   = np.where(peaks == p)[0]
                lb      = float(bases[b_idx[0]]) if len(b_idx) else base
                half    = lb + 0.5 * (pk_val - lb)
                # Walk left from peak to find half-max crossing
                li_fw = p
                while li_fw > lp and cont_s[li_fw] > half:
                    li_fw -= 1
                # Walk right from peak to find half-max crossing
                ri_fw = p
                n_sig = len(cont_s)
                while ri_fw < min(rp, n_sig - 1) and cont_s[ri_fw] > half:
                    ri_fw += 1
                fwhm_list.append((ri_fw - li_fw) * 1000.0 / fps)
            fwhm = float(np.mean(fwhm_list)) if fwhm_list else np.nan

            # ── vCO/aCO score (heuristic) ─────────────────────────────────────
            # Combines AI + CR_ratio into a 0–1 score where:
            #   score > 0.5  → vCO-like (asymmetric, slow relaxation)
            #   score < 0.5  → aCO-like (symmetric, fast relaxation)
            if not np.isnan(cr_ratio) and cr_ratio > 0:
                # Normalise each metric to [0,1] with expected ranges
                ai_norm  = np.clip((ai + 0.2) / 0.7, 0, 1)     # AI: -0.2 … 0.5
                cr_norm  = np.clip((1 - cr_ratio) / 0.8, 0, 1)  # CR: 0.2 … 1.0
                vco_score = float(0.6 * ai_norm + 0.4 * cr_norm)
                subtype   = "vCO-like" if vco_score >= 0.5 else "aCO-like"
            else:
                vco_score = np.nan
                subtype   = "N/A"

            # Area: troughs = contraction min, relaxation baseline = peaks of area
            area_troughs_feat, _ = find_peaks(-area_s, distance=dist)
            area_peaks_feat,   _ = find_peaks( area_s, distance=dist)
            peak_vals   = area_s[area_peaks_feat]
            trough_vals = area_s[area_troughs_feat]
            keep_pk = _reject_outlier_peaks(peak_vals)   if len(peak_vals)   else np.array([], dtype=bool)
            keep_tr = _reject_outlier_peaks(trough_vals) if len(trough_vals) else np.array([], dtype=bool)
            if len(peak_vals) and len(trough_vals):
                base_a = np.mean(peak_vals[keep_pk])   if keep_pk.any()   else np.mean(peak_vals)
                peak_a = np.mean(trough_vals[keep_tr]) if keep_tr.any()   else np.mean(trough_vals)
                area_m = float(base_a - peak_a)
            elif len(trough_vals):
                base_a = area_s.max()
                area_m = float(base_a - (np.mean(trough_vals[keep_tr]) if keep_tr.any() else np.mean(trough_vals)))
            else:
                base_a = area_s.max(); area_m = 0.0
            fac    = (area_m / base_a * 100) if base_a > 0 else 0.0
            peak_frame = int(peaks[0])

            # ── BPM from the Area trace (peak-to-peak), as an alternative to
            #    the Motion-trace BPM above. Area change is often a cleaner
            #    signal (less local-vector noise than optical-flow motion),
            #    so this is reported alongside Motion BPM for cross-checking
            #    rather than replacing it. ────────────────────────────────────
            area_peaks_k = (area_peaks_feat[keep_pk]
                             if len(area_peaks_feat) and keep_pk.any()
                             else area_peaks_feat)
            bpm_area = (60.0 / (np.mean(np.diff(area_peaks_k)) / fps)
                        if len(area_peaks_k) > 1 else 0.0)

            # ── Duration / Rise / Relaxation from the Area trace ────────────
            #    Area TROUGHS = contraction minimum (organoid most contracted)
            #    Area PEAKS   = relaxed baseline
            #    Rise (Area)        : relaxed baseline → trough  (contraction phase)
            #    Relaxation (Area)  : trough → relaxed baseline  (re-expansion phase)
            #    Duration (Area)    : left edge → right edge at rel_h (= Rise + Relaxation)
            rise_area = 0.0
            rel_area  = 0.0
            # Per-beat arrays (same length as peaks_k) for CSV export
            rise_area_k  = np.array([])
            rel_area_k   = np.array([])
            dur_area_k   = np.array([])
            fac_k        = np.array([])
            if len(area_troughs_feat) > 0:
                a_left, a_right, a_wh, a_bases = _local_trough_width(
                    -area_s, area_troughs_feat, area_peaks_feat,
                    fps, rel_h, max_gap=max_gap)
                a_prom = (-area_s)[area_troughs_feat] - np.array(a_bases)
                a_keep = (_reject_outlier_peaks(a_prom)
                          if len(a_prom) else np.array([], dtype=bool))
                a_left_k    = a_left[a_keep]           if a_keep.any() else a_left
                a_right_k   = a_right[a_keep]          if a_keep.any() else a_right
                a_troughs_k = area_troughs_feat[a_keep] if a_keep.any() else area_troughs_feat
                dur_area  = (float(np.mean(a_right_k - a_left_k) * 1000.0 / fps)
                             if len(a_left_k) else 0.0)
                # Mean summary values
                rise_area = (float(np.mean(a_troughs_k - a_left_k)  * 1000.0 / fps)
                             if len(a_troughs_k) else 0.0)
                rel_area  = (float(np.mean(a_right_k - a_troughs_k) * 1000.0 / fps)
                             if len(a_troughs_k) else 0.0)
                # ── Per-beat arrays ──────────────────────────────────────────
                # Each Area trough is matched to the nearest Motion peak so
                # the per-beat rows align with the Motion beat index.
                # Strategy: for each kept motion peak, find the closest Area
                # trough within ±half an RR interval.
                if len(peaks) > 0 and keep.any():
                    peaks_k_tmp = peaks[keep]
                    rr_half = (np.mean(np.diff(peaks_k_tmp)) / 2
                               if len(peaks_k_tmp) > 1 else fps)
                    _rise_list = []
                    _rel_list  = []
                    _dur_list  = []
                    _fac_list  = []
                    for mp in peaks_k_tmp:
                        # nearest area trough to this motion peak
                        dists = np.abs(a_troughs_k.astype(float) - float(mp))
                        if len(dists) == 0 or dists.min() > rr_half:
                            # no matching trough → fill with NaN
                            _rise_list.append(np.nan)
                            _rel_list.append(np.nan)
                            _dur_list.append(np.nan)
                            _fac_list.append(np.nan)
                            continue
                        idx = int(np.argmin(dists))
                        _rise_list.append((a_troughs_k[idx] - a_left_k[idx])  * 1000.0 / fps)
                        _rel_list.append( (a_right_k[idx]  - a_troughs_k[idx]) * 1000.0 / fps)
                        _dur_list.append( (a_right_k[idx]  - a_left_k[idx])    * 1000.0 / fps)
                        # Per-beat FAC: need baseline (left or right peak) vs trough
                        tr_idx = a_troughs_k[idx]
                        # nearest area peaks flanking this trough
                        left_pk  = area_peaks_feat[area_peaks_feat <  tr_idx]
                        right_pk = area_peaks_feat[area_peaks_feat >  tr_idx]
                        bl_left  = area_s[left_pk[-1]]  if len(left_pk)  else area_s.max()
                        bl_right = area_s[right_pk[0]]  if len(right_pk) else area_s.max()
                        beat_base = (bl_left + bl_right) / 2.0
                        beat_min  = area_s[tr_idx]
                        beat_fac  = ((beat_base - beat_min) / beat_base * 100
                                     if beat_base > 0 else np.nan)
                        _fac_list.append(beat_fac)
                    rise_area_k = np.array(_rise_list)
                    rel_area_k  = np.array(_rel_list)
                    dur_area_k  = np.array(_dur_list)
                    fac_k       = np.array(_fac_list)

        self._features = {
            # ── Timing / kinetics — Motion is the canonical source (better
            #    onset sensitivity than the area silhouette) ────────────────
            "BPM":                     round(bpm, 1),
            "Relaxation time (ms)":    round(rel, 1),
            "Rise time (ms)":          round(rise, 1),
            "FWHM (ms)":               round(fwhm, 1) if not np.isnan(fwhm) else "N/A",
            "Asymmetry Index":         round(ai, 3),
            "C/R ratio":               round(cr_ratio, 3) if not np.isnan(cr_ratio) else "N/A",
            "vCO/aCO score":           round(vco_score, 3) if not np.isnan(vco_score) else "N/A",
            "Subtype (heuristic)":     subtype,

            # ── Duration — measurable from either signal, so both are
            #    reported for cross-checking rather than picking one ───────
            "Contraction dur. (ms)":   round(dur, 1),        # Motion
            "Duration (Area) (ms)":    round(dur_area, 1),   # Area
            "Rise time (Area) (ms)":   round(rise_area, 1),  # Area contraction phase
            "Relaxation (Area) (ms)":  round(rel_area, 1),   # Area re-expansion phase

            # ── Amplitude / contraction-size quantification — Area is the
            #    canonical source (physical µm², more comparable across
            #    samples/sessions than Motion's arbitrary-unit signal) ──────
            "FAC (%)":                 round(fac, 2),
            "Area change (µm²)":       round(area_m, 3),

            # ── Secondary cross-check values only (not used for K-means
            #    clustering / subtype scoring — kept for QC, not reporting) ─
            "BPM (Area, cross-check)":         round(bpm_area, 1),
            "Amplitude (Motion, cross-check)": round(amp_m, 2),

            "FPS":                     round(fps, 1),
            "Artifacts excluded (beats)": n_artifacts,
            "_peak_frame":             peak_frame,
        }
        if unstable_ranges:
            self._features["Stability warning"] = ", ".join(
                f"t={s:.1f}-{e:.1f}s" for s, e in unstable_ranges)

        # Plot
        t = np.arange(len(cont_s)) / fps
        self._ax1.cla(); self._ax2.cla()
        for s, e in unstable_ranges:
            self._ax1.axvspan(s, e, color="red", alpha=0.12, lw=0)
            self._ax2.axvspan(s, e, color="red", alpha=0.12, lw=0)
        self._ax1.plot(t, cont_s, color="#1f77b4", linewidth=1.5)
        if len(peaks):
            good_p, bad_p = peaks[keep], peaks[~keep]
            if len(good_p):
                self._ax1.plot(t[good_p], cont_s[good_p], "x",
                                color="black", markersize=7, markeredgewidth=2)
            if len(bad_p):
                self._ax1.plot(t[bad_p], cont_s[bad_p], "x",
                                color="red", markersize=9, markeredgewidth=2,
                                label="excluded (artifact)")
            if keep.any():
                self._ax1.hlines(wh[keep], left_ips[keep]/fps, right_ips[keep]/fps,
                                  color="#2ca02c", linewidth=1.5)
            if (~keep).any():
                self._ax1.hlines(wh[~keep], left_ips[~keep]/fps, right_ips[~keep]/fps,
                                  color="red", linewidth=1.0, linestyle="--")
        self._ax1.set_ylabel("Motion (a.u.)")
        title2 = f"Motion  |  {bpm:.1f} BPM  |  {dur:.0f} ms"
        if n_artifacts:
            title2 += f"  |  QC: {n_artifacts} excluded"
        self._ax1.set_title(title2, fontsize=8, fontweight="bold")
        self._ax1.grid(True, alpha=0.25)

        self._ax2.plot(t, area_s, color="black", linewidth=1.2)
        # Area troughs = organoid most contracted (sync with motion peaks)
        area_troughs, _ = find_peaks(-area_s, distance=dist)
        # Area peaks = organoid most relaxed
        area_peaks, _   = find_peaks(area_s,  distance=dist)
        if len(area_troughs):
            self._ax2.plot(t[area_troughs], area_s[area_troughs], "o",
                            markeredgecolor="red", markerfacecolor="none",
                            markersize=6, label="contraction min")
        if len(area_peaks):
            self._ax2.plot(t[area_peaks], area_s[area_peaks], "o",
                            markeredgecolor="blue", markerfacecolor="none",
                            markersize=6, label="relaxation max")
        self._ax2.set_xlabel("Time (s)")
        self._ax2.set_ylabel("Area (µm²)")
        self._ax2.set_title(
            f"Area  |  FAC: {fac:.1f}%  |  Change: {area_m:.0f} µm²",
            fontsize=8, fontweight="bold")
        self._ax2.grid(True, alpha=0.25)

        self._fig.set_layout_engine("tight", pad=1.6)
        self._canvas.draw_idle()

        # Keep the smoothed (Savitzky-Golay) traces actually shown on screen,
        # so CSV export can match the on-screen plot 1:1 instead of only
        # offering the noisier pre-smoothing per-frame signal.
        self._cont_s = cont_s
        self._area_s = area_s
        self._t_s    = t

        # ── Beat-to-beat DataFrame (for CSV export) ───────────────────────
        import pandas as pd
        if len(peaks) > 0 and keep.any():
            peaks_k = peaks[keep]
            left_k  = left_ips[keep]
            right_k = right_ips[keep]
            n_beats = len(peaks_k)
            dur_k   = (right_k - left_k) * 1000.0 / fps
            rel_k   = (right_k - peaks_k) * 1000.0 / fps
            rise_k  = (peaks_k - left_k)  * 1000.0 / fps   # Motion rise per beat
            base_s  = np.mean(cont_s[troughs]) if len(troughs) else cont_s.min()
            amp_k   = cont_s[peaks_k] - base_s
            ibi_k   = np.concatenate([np.diff(peaks_k) / fps * 1000.0, [np.nan]])
            bpm_k   = np.where(ibi_k[:-1] > 0, 60000.0 / ibi_k[:-1], np.nan)
            bpm_k   = np.concatenate([bpm_k, [np.nan]])

            # ── Per-beat BPM from Area peaks ─────────────────────────────────
            # For each motion beat, find the nearest Area peak and compute
            # BPM from the interval to the next Area peak.
            area_peaks_all, _ = find_peaks(area_s, distance=dist)
            bpm_area_k = np.full(n_beats, np.nan)
            if len(area_peaks_all) >= 2:
                rr_half = (np.mean(np.diff(peaks_k)) / 2
                           if len(peaks_k) > 1 else fps)
                for bi, mp in enumerate(peaks_k):
                    dists_ap = np.abs(area_peaks_all.astype(float) - float(mp))
                    if dists_ap.min() > rr_half:
                        continue
                    idx_ap = int(np.argmin(dists_ap))
                    # interval to the next area peak
                    if idx_ap + 1 < len(area_peaks_all):
                        ibi_ap = (area_peaks_all[idx_ap + 1] -
                                  area_peaks_all[idx_ap]) / fps * 1000.0
                        bpm_area_k[bi] = 60000.0 / ibi_ap if ibi_ap > 0 else np.nan

            # Align per-beat Area arrays to motion beat count (pad with NaN)
            def _align(arr, n):
                if len(arr) == n:
                    return arr
                out = np.full(n, np.nan)
                out[:min(len(arr), n)] = arr[:min(len(arr), n)]
                return out

            df_b = pd.DataFrame({
                "Beat":                   np.arange(1, n_beats + 1),
                "IBI (ms)":               ibi_k,
                "BPM_Motion":             bpm_k,
                "BPM_Area":               bpm_area_k,
                # ── Motion kinetics ──────────────────────────────────────────
                "Duration_Motion (ms)":   dur_k,
                "Rise_Motion (ms)":       rise_k,
                "Relaxation_Motion (ms)": rel_k,
                # ── Area kinetics ────────────────────────────────────────────
                "Duration_Area (ms)":     _align(dur_area_k,  n_beats),
                "Rise_Area (ms)":         _align(rise_area_k, n_beats),
                "Relaxation_Area (ms)":   _align(rel_area_k,  n_beats),
                # ── Amplitude / FAC ──────────────────────────────────────────
                "FAC_per_beat (%)":       _align(fac_k, n_beats),
                "Amplitude_Motion (a.u.)": amp_k,
            })
            # ── MEAN / SD / n rows (listwise deletion) ───────────────────────
            # If ANY column in a beat row is NaN, that entire beat is excluded
            # from Mean/SD so all summary statistics share the same n.
            # This is cleaner than per-column NaN exclusion (which would give
            # different n values per column and confuse the reader).
            numeric_cols = df_b.select_dtypes(include="number").columns.tolist()
            df_valid     = df_b[numeric_cols].dropna(how="any")
            n_valid      = len(df_valid)

            mean_vals = df_valid.mean().to_dict()
            mean_vals["Beat"] = "MEAN"

            std_vals  = df_valid.std(ddof=1).to_dict()
            std_vals["Beat"]  = "SD"

            # Single n row — same value for every column
            n_vals = {col: n_valid for col in numeric_cols}
            n_vals["Beat"] = "n"

            self._beat_stats_df = pd.concat(
                [df_b, pd.DataFrame([mean_vals, std_vals, n_vals])],
                ignore_index=True)
        else:
            self._beat_stats_df = pd.DataFrame()

        # ── Averaged Transient canvas (Motion + Area) ─────────────────────
        # Draw directly onto the *existing* embedded axes instead of
        # building a throwaway Figure and copying its artists over —
        # this used to run on every prominence/distance spinbox tick and
        # was the main source of UI lag once more panels were added.
        self._avg_ax_motion.cla()
        self._avg_ax_area.cla()
        if len(peaks) >= 2:
            avg_data = _build_avg_transient_df(cont_s, area_s, peaks, fps)
            if avg_data is not None:
                _draw_motion_avg_ax(
                    self._avg_ax_motion, avg_data["all_motion"],
                    avg_data["t_frames"], avg_data["smooth_motion"], fps)
                if avg_data["has_area"]:
                    _draw_area_avg_ax(
                        self._avg_ax_area, avg_data["all_area"],
                        avg_data["t_frames"], avg_data["smooth_area"], fps)
                else:
                    self._avg_ax_area.text(
                        0.5, 0.5, "Area 데이터 없음", ha="center", va="center",
                        transform=self._avg_ax_area.transAxes,
                        color="gray", fontsize=9)
                self._avg_stats_df       = avg_data["df"]
                self._avg_delta_stats_df = avg_data.get("df_delta")
            else:
                for ax_ in (self._avg_ax_motion, self._avg_ax_area):
                    ax_.text(0.5, 0.5, "계산 실패", ha="center", va="center",
                             transform=ax_.transAxes, color="gray", fontsize=9)
                self._avg_stats_df = None
                self._avg_delta_stats_df = None
        else:
            for ax_ in (self._avg_ax_motion, self._avg_ax_area):
                ax_.text(0.5, 0.5, "피크 2개 이상 필요",
                         ha="center", va="center",
                         transform=ax_.transAxes, color="gray", fontsize=9)
            self._avg_stats_df = None
            self._avg_delta_stats_df = None

        self._avg_fig.set_layout_engine("tight", pad=1.6, w_pad=2.5)
        self._avg_canvas.draw_idle()

        # Feature table
        show = {k: v for k, v in self._features.items()
                if not k.startswith("_")}
        self._feat_table.setRowCount(len(show))
        for r, (k, v) in enumerate(show.items()):
            ki = QTableWidgetItem(k);     ki.setFont(ARIAL_SM)
            vi = QTableWidgetItem(str(v)); vi.setFont(ARIAL_SM)
            vi.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            self._feat_table.setItem(r, 0, ki)
            self._feat_table.setItem(r, 1, vi)

    def get_features(self) -> dict:
        return {k: v for k, v in self._features.items()
                if not k.startswith("_")}

    def get_beat_stats(self):
        """Beat-to-beat DataFrame for CSV export."""
        return self._beat_stats_df

    def get_avg_stats(self):
        """Averaged-transient DataFrame (Motion + Area absolute µm²) for CSV export."""
        return self._avg_stats_df

    def get_avg_delta_stats(self):
        """Averaged-transient DataFrame with ΔArea (baseline-subtracted µm²) for CSV export."""
        return getattr(self, "_avg_delta_stats_df", None)

    def get_smoothed_traces(self):
        """(time_s, motion_smoothed, area_smoothed) — the exact
        Savitzky-Golay-filtered traces rendered in the Motion/Area plot
        above. Use this for CSV export so a Prism re-plot matches what's
        shown on screen; the raw per-frame signal (get_features() / the
        underlying timeseries) is noisier and was never smoothed."""
        return (getattr(self, "_t_s", None),
                getattr(self, "_cont_s", None),
                getattr(self, "_area_s", None))

    def get_trace_figure(self):
        """Matplotlib Figure for the top Motion/Area detail trace plot
        (BPM/Duration/Amplitude title, artifact markers, threshold line)."""
        return self._fig

    def get_avg_figure(self):
        """Matplotlib Figure for the Averaged Transient Traces panel
        (Motion kinetics + Area, side by side)."""
        return self._avg_fig

    def get_heatmap_img(self):
        """Full-resolution Motion Heatmap image (RGB ndarray), or None
        if this ROI has no heatmap (e.g. brightfield-only contour mode)."""
        return self._data.get("heatmap")

    def get_contour_img(self):
        """Full-resolution Max<->Min Contour overlay image (RGB ndarray),
        or None."""
        return self._data.get("contour_img")

    def get_peak_frame(self) -> int:
        return self._features.get("_peak_frame", 0)

    def get_roi_name(self) -> str:
        return self._name


# ─────────────────────────────────────────────────────────────────────────────
#  Main Tab widget
# ─────────────────────────────────────────────────────────────────────────────

class BatchSelectDialog(QDialog):
    """
    영상별 추출 상태를 표시하고 선택하는 다이얼로그.

    상태 표시:
      ✅ Done     — 현재 파라미터와 동일하게 이미 추출됨 → 기본 체크 해제 (스킵)
      🔄 Updated  — 파라미터가 바뀌어서 재추출 필요 → 기본 체크 (추출)
      ⏳ Pending  — 아직 추출 안 됨 → 기본 체크 (추출)
      ⚠ No ROI   — ROI 없음 → 선택 불가
    """
    def __init__(self, queue_rows: list, roi_store: dict,
                 extract_state_store: dict, extract_params_store: dict,
                 parent=None):
        super().__init__(parent)
        self.setWindowTitle("Extract Signals — 영상 선택")
        self.setMinimumWidth(540)
        self.setFont(ARIAL)
        layout = QVBoxLayout(self)

        layout.addWidget(_lbl("추출할 영상을 선택하세요:", bold=True))
        note = _lbl(
            "✅ Done = 이미 최신 추출 완료 (파라미터 변경 없음) → 기본 스킵\n"
            "🔄 Updated = 파라미터가 변경됨 → 재추출 필요\n"
            "⏳ Pending = 아직 추출 안 됨", size=8)
        note.setStyleSheet("color: #555;")
        note.setWordWrap(True)
        layout.addWidget(note)

        self.list_widget = QListWidget()
        self.list_widget.setFont(ARIAL_SM)
        self.list_widget.setSelectionMode(QAbstractItemView.NoSelection)
        self.list_widget.setMinimumHeight(180)
        layout.addWidget(self.list_widget)

        self._row_map: list = []

        for row_data in queue_rows:
            r, path, fps, thr, ts, te = row_data
            name = Path(path).name
            has_rois = bool(roi_store.get(path))
            n_rois   = len(roi_store.get(path, []))

            # 현재 파라미터 해시
            cur_params = extract_params_store.get(path, {})
            cur_hash   = _params_hash({**cur_params,
                                        "thr": thr, "fps": fps,
                                        "ts": ts, "te": te})

            state      = extract_state_store.get(path, {})
            done_hash  = state.get("params_hash")
            status     = state.get("status", "pending")

            item = QListWidgetItem()
            if not has_rois:
                item.setFlags(Qt.NoItemFlags)
                item.setCheckState(Qt.Unchecked)
                item.setText(f"  {name}  ⚠ No ROI — detect first")
                item.setForeground(Qt.GlobalColor.gray)
            elif status == "done" and done_hash == cur_hash:
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Unchecked)   # 기본 스킵
                item.setText(f"  {name}  ✅ Done ({n_rois} ROI) — 파라미터 동일")
                item.setForeground(QColor("#1a5e1a"))
            elif status == "done" and done_hash != cur_hash:
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Checked)     # 파라미터 바뀜 → 재추출
                item.setText(f"  {name}  🔄 Updated ({n_rois} ROI) — 파라미터 변경")
                item.setForeground(QColor("#a04000"))
            else:
                item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
                item.setCheckState(Qt.Checked)     # 미추출 → 추출
                item.setText(f"  {name}  ⏳ Pending ({n_rois} ROI)")
                item.setForeground(QColor("#2a6a9a"))

            self.list_widget.addItem(item)
            self._row_map.append(row_data)

        # Select / Deselect 버튼
        sel_row = QHBoxLayout()
        btn_all      = _btn("전체 선택")
        btn_none     = _btn("전체 해제")
        btn_pending  = _btn("📋  미완료만 선택")
        for b in [btn_all, btn_none, btn_pending]:
            sel_row.addWidget(b)
        sel_row.addStretch()
        btn_all.clicked.connect(self._select_all)
        btn_none.clicked.connect(self._deselect_all)
        btn_pending.clicked.connect(self._select_pending)
        layout.addLayout(sel_row)

        btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        btns.setFont(ARIAL)
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

    def _select_all(self):
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.flags() & Qt.ItemIsEnabled:
                item.setCheckState(Qt.Checked)

    def _deselect_all(self):
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.flags() & Qt.ItemIsEnabled:
                item.setCheckState(Qt.Unchecked)

    def _select_pending(self):
        """Done(최신)은 해제, Updated/Pending만 선택."""
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if not (item.flags() & Qt.ItemIsEnabled):
                continue
            text = item.text()
            if "✅ Done" in text:
                item.setCheckState(Qt.Unchecked)
            else:
                item.setCheckState(Qt.Checked)

    def selected_rows(self) -> list:
        result = []
        for i in range(self.list_widget.count()):
            item = self.list_widget.item(i)
            if item.checkState() == Qt.Checked:
                result.append(self._row_map[i])
        return result


class ContractilityTab(QWidget):
    """
    Tab 2: Multi-Organoid Contractility Analysis
    Replaces Streamlit app_multiCO.py with a native PyQt5 UI.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._video_path: str | None = None   # current preview video
        self._video_queue: list[str] = []     # ordered list of paths in the batch
        self._roi_store:    dict[str, list] = {}  # path -> ROI list
        self._thresh_store: dict[str, int]  = {}  # path -> threshold value
        self._mode_store:   dict[str, str]  = {}  # path -> 'ai' | 'manual'
        self._scan_store:   dict[str, object] = {} # path -> AutoROIScanResult
        self._manual_override_frame: dict[str, int] = {}  # path -> frame_idx
        self._extract_params_store: dict[str, dict] = {}  # path -> extraction params
        self._extract_state_store:  dict[str, dict] = {}  # path -> {status, hash, result}
        self._last_frame_rgb = None
        self._rois: list = []
        self._raw_signals: dict = {}
        self._roi_cards: list[ROICard] = []

        # ── Worker references (kept so we can safely stop them) ──────────────
        self._scan_worker:         QThread | None = None
        self._detect_worker:       QThread | None = None
        self._extract_worker:      QThread | None = None
        self._video_export_worker: QThread | None = None

        # ── Frame-by-frame ROI tracking scrubber state ──────────────────────
        self._scrub_cap   = None  # persistent cv2.VideoCapture for scrubbing
        self._probe_worker = None  # QueueProbeWorker (백그라운드 파일 프로브)
        self._total_frames = 0
        self._fps = 30.0
        self._scrub_timer = QTimer(self)        # debounce slider drag → redraw
        self._scrub_timer.setSingleShot(True)
        self._scrub_timer.timeout.connect(self._render_current_frame)
        self._play_timer = QTimer(self)         # auto-advance for playback
        self._play_timer.timeout.connect(self._advance_playback)

        self._build_ui()

    # ─────────────────────────────────────────────────────────────────────────
    #  Worker lifecycle helper
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _stop_worker(worker: QThread | None) -> None:
        """Gracefully stop a QThread worker before replacing it.
        Prevents 'QThread: Destroyed while thread is still running' warnings.
        """
        if worker is not None and worker.isRunning():
            worker.quit()
            if not worker.wait(2000):   # give it 2 s to finish
                worker.terminate()
                worker.wait(500)

    # ─────────────────────────────────────────────────────────────────────────
    #  UI layout
    # ─────────────────────────────────────────────────────────────────────────

    def _build_ui(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(16, 16, 16, 12)
        root.setSpacing(12)

        # ── Top: title + model selector ──────────────────────────────────────
        title_row = QHBoxLayout()
        t = _lbl("Motion & contractility", bold=True, size=11)
        title_row.addWidget(t)
        title_row.addStretch()
        title_row.addWidget(_lbl("Model type:", size=9))
        self.model_combo = QComboBox(); self.model_combo.setFont(ARIAL)
        self.model_combo.addItems(["Cardiac Organoid",
                                    "Engineered Heart Tissue (EHT)",
                                    "2D Monolayer",
                                    "Other"])
        title_row.addWidget(self.model_combo)
        root.addLayout(title_row)

        splitter = QSplitter(Qt.Horizontal)
        root.addWidget(splitter, stretch=1)

        # ── LEFT: controls panel ─────────────────────────────────────────────
        ctrl_widget = QWidget()
        ctrl_widget.setMinimumWidth(306)
        ctrl_layout = QVBoxLayout(ctrl_widget)
        ctrl_layout.setContentsMargins(0, 0, 8, 0)
        ctrl_layout.setSpacing(12)

        # Step 1 — Batch Queue
        grp1 = QGroupBox("01  /  Recordings")
        grp1.setFont(ARIAL_BD)
        g1l  = QVBoxLayout(grp1)

        # Buttons row
        q_btn_row = QGridLayout()
        self.btn_load    = _btn("📂  Add Videos")
        self.btn_remove  = _btn("Remove selected")
        self.btn_clear   = _btn("Clear All")
        self.btn_apply_shared = _btn("Apply shared settings to queue")
        self.btn_apply_shared.setToolTip(
            "Overwrites fps / threshold / trim in every queue row\n"
            "with the current values in Steps 2-3 controls")
        self.btn_load.setProperty("role", "primary")
        q_btn_row.addWidget(self.btn_load, 0, 0, 1, 2)
        q_btn_row.addWidget(self.btn_remove, 1, 0)
        q_btn_row.addWidget(self.btn_clear, 1, 1)
        q_btn_row.addWidget(self.btn_apply_shared, 2, 0, 1, 2)
        g1l.addLayout(q_btn_row)

        # Batch queue table
        # Columns: #, Filename, fps, Threshold, Trim start (s), Trim end (s), Status
        self._QUEUE_COLS = ["#", "Filename", "fps",
                            "Threshold", "Trim start (s)", "Trim end (s)", "Status"]
        self._COL_FPS   = 2
        self._COL_THR   = 3
        self._COL_TS    = 4
        self._COL_TE    = 5
        self._COL_STAT  = 6

        self.queue_table = QTableWidget(0, len(self._QUEUE_COLS))
        self.queue_table.setFont(ARIAL_SM)
        self.queue_table.horizontalHeader().setFont(ARIAL_SM)
        self.queue_table.setHorizontalHeaderLabels(self._QUEUE_COLS)
        self.queue_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        for c in [0, 2, 3, 4, 5, 6]:
            self.queue_table.horizontalHeader().setSectionResizeMode(
                c, QHeaderView.ResizeToContents)
        self.queue_table.setSelectionBehavior(QTableWidget.SelectRows)
        self.queue_table.setMinimumHeight(110)
        self.queue_table.setMaximumHeight(180)
        style_table(self.queue_table)

        # "Currently previewing" label (replaces old self.video_label)
        self.video_label = _lbl("No video loaded", size=8)
        self.video_label.setWordWrap(True)
        self.video_label.setStyleSheet("color: gray;")
        g1l.addWidget(self.video_label)

        ctrl_layout.addWidget(grp1)

        # Step 2 — ROI Detection
        grp2 = QGroupBox("02  /  Region of interest")
        grp2.setFont(ARIAL_BD)
        g2l  = QVBoxLayout(grp2)

        # ── 상태 라벨 ────────────────────────────────────────────────────────
        self.ai_status_lbl = _lbl("Load a recording to start the ROI scan.", size=8)
        self.ai_status_lbl.setStyleSheet("color: #555;")
        self.ai_status_lbl.setWordWrap(True)
        g2l.addWidget(self.ai_status_lbl)

        # 안정성 바
        stab_row = QHBoxLayout()
        stab_row.addWidget(_lbl("Stability:", size=8))
        self.stability_bar = QProgressBar()
        self.stability_bar.setRange(0, 100)
        self.stability_bar.setValue(0)
        self.stability_bar.setTextVisible(True)
        self.stability_bar.setFixedHeight(14)
        self.stability_bar.setFont(ARIAL_SM)
        stab_row.addWidget(self.stability_bar, stretch=1)
        g2l.addLayout(stab_row)

        # 이상 구간 라벨
        self.bad_range_lbl = _lbl("", size=8)
        self.bad_range_lbl.setStyleSheet("color: #c0392b;")
        self.bad_range_lbl.setWordWrap(True)
        g2l.addWidget(self.bad_range_lbl)

        # ── [A] Auto Detect 버튼 ─────────────────────────────────────────────
        self.btn_detect = _btn("🔍  Auto Detect ROI", color="#d4f0d4", bold=True)
        self.btn_detect.setToolTip(
            "Otsu threshold로 첫 프레임 ROI를 자동 탐색하고\n"
            "전체 프레임을 스캔해서 안정성을 확인합니다.")
        g2l.addWidget(self.btn_detect)

        # ── 파라미터 (접을 수 있도록 별도 그룹) ─────────────────────────────
        param_grp = QGroupBox("Detection parameters")
        param_grp.setFont(ARIAL_SM)
        param_grp.setCheckable(False)
        p2l = QFormLayout(param_grp)
        p2l.setRowWrapPolicy(QFormLayout.WrapLongRows)

        self.thresh_slider = QSlider(Qt.Horizontal)
        self.thresh_slider.setRange(10, 220); self.thresh_slider.setValue(60)
        self.thresh_slider.setEnabled(False)   # Auto 모드 기본값: 잠금
        self.thresh_slider.setToolTip(
            "Auto Detect 후 Otsu 값이 자동 설정됩니다.\n"
            "직접 조정하려면 '✏️ Manual Override' 버튼을 누르세요.")
        self.thresh_lbl = _lbl("60", size=9)
        th_row = QHBoxLayout()
        th_row.addWidget(self.thresh_slider, stretch=1)
        th_row.addWidget(self.thresh_lbl)
        p2l.addRow("Threshold:", th_row)

        self.maxroi_spin = QSpinBox()
        self.maxroi_spin.setRange(1, 50); self.maxroi_spin.setValue(9)
        self.maxroi_spin.setFont(ARIAL)
        p2l.addRow("Max ROIs:", self.maxroi_spin)

        self.solidity_spin = QDoubleSpinBox()
        self.solidity_spin.setRange(0.0, 1.0); self.solidity_spin.setValue(0.6)
        self.solidity_spin.setSingleStep(0.05); self.solidity_spin.setFont(ARIAL)
        p2l.addRow("Min solidity:", self.solidity_spin)

        ar_row = QHBoxLayout()
        self.ar_min_spin = QDoubleSpinBox()
        self.ar_min_spin.setRange(0.1, 5.0); self.ar_min_spin.setValue(0.5)
        self.ar_min_spin.setSingleStep(0.1); self.ar_min_spin.setFont(ARIAL)
        self.ar_max_spin = QDoubleSpinBox()
        self.ar_max_spin.setRange(0.1, 10.0); self.ar_max_spin.setValue(2.0)
        self.ar_max_spin.setSingleStep(0.1); self.ar_max_spin.setFont(ARIAL)
        self.ar_min_spin.setMinimumWidth(84)
        self.ar_max_spin.setMinimumWidth(84)
        ar_row.addWidget(self.ar_min_spin)
        ar_row.addWidget(_lbl("–", size=9))
        ar_row.addWidget(self.ar_max_spin)
        p2l.addRow("Aspect ratio:", ar_row)
        g2l.addWidget(param_grp)

        # ── [B] Manual Override 구분선 ────────────────────────────────────────
        sep = QLabel("Need to refine the detected region?")
        sep.setAlignment(Qt.AlignCenter)
        sep.setStyleSheet("color: #888; font-size: 8pt;")
        g2l.addWidget(sep)

        # 현재 scrubber 프레임 표시
        self.detect_frame_lbl = _lbl("Manual: Frame 0 (first frame)", size=8)
        self.detect_frame_lbl.setStyleSheet("color: #2a6a9a;")
        g2l.addWidget(self.detect_frame_lbl)

        self.btn_manual_detect = _btn(
            "Refine ROI at current frame", color="#fff0cc", bold=True)
        self.btn_manual_detect.setToolTip(
            "scrubber를 이상 없는 프레임으로 이동 후 클릭.\n"
            "threshold를 조정하고 이 버튼으로 ROI를 직접 지정합니다.")
        g2l.addWidget(self.btn_manual_detect)

        self.btn_save_roi = _btn("💾  Save ROI (current)", color="#d4e8ff")
        self.btn_save_roi.setEnabled(False)
        g2l.addWidget(self.btn_save_roi)

        ctrl_layout.addWidget(grp2)

        # Step 3 — Extraction settings
        grp3 = QGroupBox("03  /  Signal settings")
        grp3.setFont(ARIAL_BD)
        g3l  = QFormLayout(grp3)
        g3l.setRowWrapPolicy(QFormLayout.WrapLongRows)

        self.px_um_spin = QDoubleSpinBox()
        self.px_um_spin.setRange(0.1, 10000.0); self.px_um_spin.setValue(576.0)
        self.px_um_spin.setSingleStep(1.0); self.px_um_spin.setFont(ARIAL)
        self.px_um_spin.setToolTip("Pixels per µm — check your microscope spec")
        g3l.addRow("px/µm:", self.px_um_spin)

        # FPS override — the video file's CAP_PROP_FPS metadata can be wrong
        # (e.g. for screen-recorded captures where the saved frame rate
        # doesn't match the true elapsed time of the source feed). When
        # checked, this value is used instead of the file's reported FPS.
        fps_row = QHBoxLayout()
        self.fps_override_chk = QCheckBox("Override:")
        self.fps_override_chk.setFont(ARIAL)
        self.fps_spin = QDoubleSpinBox()
        self.fps_spin.setRange(0.1, 10000.0); self.fps_spin.setValue(30.0)
        self.fps_spin.setSingleStep(1.0); self.fps_spin.setFont(ARIAL)
        self.fps_spin.setEnabled(False)
        self.fps_override_chk.toggled.connect(self.fps_spin.setEnabled)
        fps_row.addWidget(self.fps_override_chk)
        fps_row.addWidget(self.fps_spin)
        self.fps_detected_lbl = _lbl("fps", size=9)
        fps_row.addWidget(self.fps_detected_lbl)
        self.fps_override_chk.setToolTip(
            "Use this if the file's frame rate metadata is unreliable\n"
            "(e.g. screen-recorded videos) — calibrate manually using a\n"
            "known time interval (on-screen timestamp, etc.) instead of\n"
            "trusting the container's reported FPS.")
        g3l.addRow("Frame rate:", fps_row)

        self.sg_spin = QSpinBox()
        self.sg_spin.setRange(3, 51); self.sg_spin.setValue(11)
        self.sg_spin.setSingleStep(2); self.sg_spin.setFont(ARIAL)
        g3l.addRow("SG window:", self.sg_spin)

        self.baseline_spin = QSpinBox()
        self.baseline_spin.setRange(50, 99); self.baseline_spin.setValue(90)
        self.baseline_spin.setFont(ARIAL)
        g3l.addRow("Baseline % (dur.):", self.baseline_spin)

        # ── Trim range ───────────────────────────────────────────────────────
        # Restrict analysis to [start, end] seconds so that unstable regions
        # (e.g. a sudden jump at the end of the recording) are excluded from
        # signal extraction, all kinetic calculations, and all exports.
        trim_row = QHBoxLayout()
        self.trim_start_spin = QDoubleSpinBox()
        self.trim_start_spin.setRange(0.0, 99999.0); self.trim_start_spin.setValue(0.0)
        self.trim_start_spin.setSingleStep(1.0); self.trim_start_spin.setFont(ARIAL)
        self.trim_start_spin.setDecimals(1)
        self.trim_end_spin = QDoubleSpinBox()
        self.trim_end_spin.setRange(0.0, 99999.0); self.trim_end_spin.setValue(0.0)
        self.trim_end_spin.setSingleStep(1.0); self.trim_end_spin.setFont(ARIAL)
        self.trim_end_spin.setDecimals(1)
        self.trim_end_spin.setToolTip("0 = use until the end of the video")
        self.trim_start_spin.setMinimumWidth(88)
        self.trim_end_spin.setMinimumWidth(88)
        trim_row.addWidget(self.trim_start_spin)
        trim_row.addWidget(_lbl("–", size=9))
        trim_row.addWidget(self.trim_end_spin)
        trim_row.addWidget(_lbl("s", size=9))
        g3l.addRow("Trim (s):", trim_row)
        g3l.addRow("", _lbl("0 – 0 = no trim (full video)", size=8))

        # 파라미터 자동 저장 안내
        save_note = _lbl("Settings are saved separately for each recording.", size=8)
        save_note.setStyleSheet("color: #2a6a9a;")
        save_note.setWordWrap(True)
        g3l.addRow(save_note)

        self.btn_extract = _btn("▶  Extract Signals", color="#d4f0d4", bold=True)
        self.btn_extract.setMinimumHeight(32)
        # Primary actions stay visible below the scrollable settings.
        ctrl_layout.addWidget(grp3)

        # Step 4 — Activation / Mechanical Maps
        grp5 = QGroupBox("04  /  Mechanical maps")
        grp5.setFont(ARIAL_BD)
        g5l  = QVBoxLayout(grp5)
        self.btn_strain = _btn("Compute mechanical maps")
        g5l.addWidget(self.btn_strain)

        thresh_row = QHBoxLayout()
        thresh_row.addWidget(_lbl("Act. threshold:", size=8))
        self.act_thresh_spin = QDoubleSpinBox()
        self.act_thresh_spin.setRange(0.01, 0.50)
        self.act_thresh_spin.setSingleStep(0.01)
        self.act_thresh_spin.setValue(0.05)
        self.act_thresh_spin.setDecimals(2)
        self.act_thresh_spin.setMinimumWidth(80)
        self.act_thresh_spin.setToolTip(
            "Activation threshold: fraction of peak inward displacement.\n"
            "Lower = more points detected (sensitive)\n"
            "Higher = only strong movers (strict)\n"
            "Default 0.05")
        thresh_row.addWidget(self.act_thresh_spin)
        thresh_row.addWidget(_lbl("× peak", size=8))
        thresh_row.addStretch()
        g5l.addLayout(thresh_row)
        ctrl_layout.addWidget(grp5)

        ctrl_layout.addStretch()

        ctrl_scroll = QScrollArea()
        ctrl_scroll.setWidget(ctrl_widget)
        ctrl_scroll.setWidgetResizable(True)
        ctrl_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        ctrl_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        ctrl_scroll.setFrameShape(ctrl_scroll.NoFrame)

        sidebar = QWidget()
        sidebar.setMinimumWidth(330)
        sidebar.setMaximumWidth(390)
        sidebar_layout = QVBoxLayout(sidebar)
        sidebar_layout.setContentsMargins(0, 0, 4, 0)
        sidebar_layout.setSpacing(10)
        sidebar_layout.addWidget(ctrl_scroll, stretch=1)
        footer = QWidget()
        footer.setObjectName("sidebarFooter")
        footer.setAttribute(Qt.WA_StyledBackground, True)
        footer_layout = QVBoxLayout(footer)
        footer_layout.setContentsMargins(12, 12, 12, 12)
        footer_layout.setSpacing(8)
        footer_layout.addWidget(self.btn_extract)
        self.btn_export = _btn("Export all results")
        footer_layout.addWidget(self.btn_export)
        sidebar_layout.addWidget(footer)
        splitter.addWidget(sidebar)

        # ── RIGHT: results area ──────────────────────────────────────────────
        right_widget = QWidget()
        right_layout = QVBoxLayout(right_widget)
        right_layout.setContentsMargins(0, 0, 0, 0)

        # The original narrow columns hid plots and controls. Each result
        # now has a full-width workspace while retaining the same widgets.
        self.result_tabs = QTabWidget()
        self.result_tabs.setDocumentMode(True)

        # ── LEFT half: video preview + scrubber ─────────────────────────────
        preview_widget = QWidget()
        preview_layout = QVBoxLayout(preview_widget)
        preview_layout.setContentsMargins(8, 12, 0, 0)

        self.roi_preview_lbl = QLabel("Your recording, in focus\n\nAdd a video to inspect and track regions of interest.")
        self.roi_preview_lbl.setAlignment(Qt.AlignCenter)
        self.roi_preview_lbl.setMinimumHeight(220)
        self.roi_preview_lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.roi_preview_lbl.setObjectName("videoPreview")
        self.roi_preview_lbl.setFont(font(12))
        preview_layout.addWidget(self.roi_preview_lbl, stretch=1)

        scrub_box = QGroupBox("Frame-by-frame tracking")
        scrub_box.setFont(ARIAL_BD)
        scrub_layout = QVBoxLayout(scrub_box)
        scrub_layout.setSpacing(3)

        slider_row = QHBoxLayout()
        self.btn_play = _btn("Play")
        self.btn_play.setToolTip("Play or pause the recording")
        self.btn_play.setFixedWidth(54)
        self.btn_play.setEnabled(False)
        self.frame_slider = QSlider(Qt.Horizontal)
        self.frame_slider.setRange(0, 0)
        self.frame_slider.setEnabled(False)
        self.frame_info_lbl = _lbl("Frame: – / –", size=9)
        self.frame_info_lbl.setMinimumWidth(150)
        slider_row.addWidget(self.btn_play)
        slider_row.addWidget(self.frame_slider, stretch=1)
        slider_row.addWidget(self.frame_info_lbl)
        scrub_layout.addLayout(slider_row)

        self.roi_count_lbl = _lbl(
            "Load a video and run Detect ROIs, then drag the slider "
            "(or press ▶) to confirm the ROI tracks correctly on every frame.",
            size=8)
        self.roi_count_lbl.setWordWrap(True)
        self.roi_count_lbl.setStyleSheet("color: gray;")
        scrub_layout.addWidget(self.roi_count_lbl)

        # ── Frame-by-frame map overlay (shown after Compute Activation Map) ──
        # ROI selector row (visible only when maps are computed)
        self._map_roi_row_widget = QWidget()
        _map_roi_row = QHBoxLayout(self._map_roi_row_widget)
        _map_roi_row.setContentsMargins(0, 0, 0, 0)
        _map_roi_row.addWidget(_lbl("Map ROI:", size=8))
        self._map_roi_combo = QComboBox()
        self._map_roi_combo.setMinimumWidth(260)
        self._map_roi_combo.setToolTip("Select which ROI's activation map to display")
        self._map_roi_combo.currentIndexChanged.connect(
            lambda _: (self._update_map_overlay(self.frame_slider.value()),
                       self._draw_mech_map_result()))
        _map_roi_row.addWidget(self._map_roi_combo)
        _map_roi_row.addStretch()
        self._map_roi_row_widget.setVisible(False)
        right_layout.addWidget(self._map_roi_row_widget)

        self._map_overlay_fig, self._map_overlay_ax = plt.subplots(
            1, 4, figsize=(10, 2.2))
        self._map_overlay_fig.patch.set_facecolor('#0d0d0d')
        self._map_overlay_fig.subplots_adjust(
            left=0.04, right=0.97, top=0.88, bottom=0.15, wspace=0.35)
        for ax in self._map_overlay_ax:
            ax.set_facecolor('#0d0d0d')
            ax.tick_params(colors='#e8e8e8', labelsize=6)
            for sp in ax.spines.values():
                sp.set_color('#333')
        self._map_overlay_canvas = FigureCanvas(self._map_overlay_fig)
        self._map_overlay_canvas.setFixedHeight(160)
        self._map_overlay_canvas.setVisible(False)   # hidden until maps computed
        scrub_layout.addWidget(self._map_overlay_canvas)

        preview_layout.addWidget(scrub_box, stretch=0)
        queue_group = QGroupBox("Recording queue  /  per-video settings")
        queue_layout = QVBoxLayout(queue_group)
        queue_layout.addWidget(self.queue_table)
        preview_layout.addWidget(queue_group)
        self.result_tabs.addTab(preview_widget, "Preview + tracking")

        # ── RIGHT half: ROI cards + cluster plot ────────────────────────────
        cards_widget = QWidget()
        cards_layout = QVBoxLayout(cards_widget)
        cards_layout.setContentsMargins(8, 12, 0, 0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self._cards_container = QWidget()
        self._cards_layout    = QVBoxLayout(self._cards_container)
        self._cards_layout.setContentsMargins(0, 0, 8, 0)
        self._cards_layout.setSpacing(12)
        self._results_hint = label("Signals will appear here\n\nDetect ROIs, review your settings, then select Extract Signals.", size=11)
        self._results_hint.setObjectName("emptyState")
        self._results_hint.setAlignment(Qt.AlignCenter)
        self._results_hint.setWordWrap(True)
        self._cards_layout.addWidget(self._results_hint)
        scroll.setWidget(self._cards_container)
        cards_layout.addWidget(scroll, stretch=1)

        self.result_tabs.addTab(cards_widget, "Signals + features")

        maps_widget = QWidget()
        maps_layout = QVBoxLayout(maps_widget)
        maps_layout.setContentsMargins(8, 12, 0, 0)
        self._result_fig = plt.figure(figsize=(12, 7))
        axes = self._result_fig.subplots(2, 2)
        self._ax_disp, self._ax_strain, self._ax_kappa, self._ax_mact = axes.ravel()
        for ax, title in zip(axes.ravel(), ["Displacement", "Strain", "Curvature change", "Mechanical activation"]):
            ax.set_title(title)
            ax.text(0.5, 0.5, "Compute maps after signal extraction", ha="center", va="center",
                    color="#98A8B8", fontsize=9, transform=ax.transAxes)
            ax.set_xticks([])
            ax.set_yticks([])
        self._result_fig.tight_layout(pad=3)
        self._result_ax = self._ax_disp
        self._result_canvas = FigureCanvas(self._result_fig)
        self._result_canvas.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        maps_layout.addWidget(self._result_canvas, stretch=1)
        self.result_tabs.addTab(maps_widget, "Mechanical maps")
        right_layout.addWidget(self.result_tabs, stretch=1)
        splitter.addWidget(right_widget)
        splitter.setHandleWidth(12)
        splitter.setChildrenCollapsible(False)
        splitter.setSizes([340, 1080])

        # ── Wire up ──────────────────────────────────────────────────────────
        self.thresh_slider.valueChanged.connect(self._on_thresh_changed)
        self.thresh_slider.valueChanged.connect(
            lambda v: self.thresh_lbl.setText(str(v)))
        self.model_combo.currentTextChanged.connect(self._on_model_changed)
        self.btn_load.clicked.connect(self._add_videos)
        self.btn_remove.clicked.connect(self._remove_selected_videos)
        self.btn_clear.clicked.connect(self._clear_queue)
        self.btn_apply_shared.clicked.connect(self._apply_shared_to_all)
        self.queue_table.itemSelectionChanged.connect(self._on_queue_selection_changed)
        self.btn_detect.clicked.connect(self._auto_detect_rois)
        self.btn_manual_detect.clicked.connect(self._manual_detect_rois)
        self.btn_save_roi.clicked.connect(self._save_roi_feedback)
        self.btn_extract.clicked.connect(self._extract_signals)
        self.btn_strain.clicked.connect(self._compute_strain)
        self.btn_export.clicked.connect(self._export_all)
        self.frame_slider.valueChanged.connect(self._on_frame_slider_changed)
        self.frame_slider.valueChanged.connect(self._update_detect_frame_lbl)
        self.btn_play.clicked.connect(self._toggle_playback)

        # ── Step 3 파라미터 변경 시 현재 영상에 자동 저장 ───────────────────
        for _w in [self.px_um_spin, self.fps_spin, self.sg_spin,
                   self.baseline_spin, self.trim_start_spin, self.trim_end_spin]:
            _w.valueChanged.connect(self._save_extract_params)
        self.fps_override_chk.toggled.connect(self._save_extract_params)

    # ─────────────────────────────────────────────────────────────────────────
    #  Model type change
    # ─────────────────────────────────────────────────────────────────────────

    def _on_model_changed(self, model_text: str):
        """Show/hide ROI detection controls based on model type."""
        is_monolayer = "2D Monolayer" in model_text
        # Disable ROI detection group — not needed for monolayer
        for widget in [self.thresh_slider, self.maxroi_spin,
                       self.solidity_spin, self.ar_min_spin,
                       self.ar_max_spin, self.btn_detect]:
            widget.setEnabled(not is_monolayer)
        if is_monolayer:
            self.btn_detect.setText("Use full frame (auto)")
            # If video already loaded, auto-set whole-frame ROI
            if self._video_path:
                self._set_fullframe_roi()
        else:
            self.btn_detect.setText("Detect ROIs")

    def _set_fullframe_roi(self):
        """Set entire frame as single ROI for 2D monolayer analysis."""
        cap = cv2.VideoCapture(self._video_path)
        ret, frame = cap.read()
        cap.release()
        if not ret:
            return
        H, W = frame.shape[:2]
        # One ROI = full frame, contour = frame boundary rectangle
        full_contour = np.array([[0,0],[W-1,0],[W-1,H-1],[0,H-1]], dtype=np.int32)
        full_contour = full_contour.reshape((-1, 1, 2))
        self._rois = [{
            "box": (0, 0, W, H),
            "contour": full_contour,
        }]
        # Show full frame as preview with green border
        vis = frame.copy()
        cv2.rectangle(vis, (2, 2), (W-3, H-3), (0, 255, 0), 3)
        cv2.putText(vis, "ROI 1 (Full Frame)", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 255), 2)
        rgb = cv2.cvtColor(vis, cv2.COLOR_BGR2RGB)
        self._show_in_preview(rgb, f"2D Monolayer — Full frame ROI  ({W}×{H} px)")

    # ─────────────────────────────────────────────────────────────────────────
    #  Threshold live preview
    # ─────────────────────────────────────────────────────────────────────────

    def _detect_and_draw(self, frame_bgr: np.ndarray, threshold: int):
        """Shared ROI-detection + overlay drawing logic for a single frame.
        Used by both the live threshold preview and the all-frame scrubber,
        so what you see while dragging either slider always matches what
        Detect ROIs / Extract Signals will actually do.
        Returns (annotated_rgb, n_valid_rois).
        """
        gray  = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
        blur  = cv2.GaussianBlur(gray, (11, 11), 0)
        _, th = cv2.threshold(blur, threshold, 255, cv2.THRESH_BINARY_INV)
        kernel = np.ones((5, 5), np.uint8)
        th = cv2.morphologyEx(th, cv2.MORPH_OPEN, kernel, iterations=2)
        cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        H, W = gray.shape
        vis = frame_bgr.copy()
        n_valid = 0
        if cnts:
            sol   = self.solidity_spin.value()
            ar_lo = self.ar_min_spin.value()
            ar_hi = self.ar_max_spin.value()
            for c in sorted(cnts, key=cv2.contourArea, reverse=True):
                area = cv2.contourArea(c)
                frac = area / (H * W)
                if not (0.001 <= frac <= 0.80):
                    continue
                hull_a = cv2.contourArea(cv2.convexHull(c))
                if hull_a <= 0:
                    continue
                if float(area) / hull_a < sol:
                    continue
                x, y, w, h = cv2.boundingRect(c)
                ar = w / max(h, 1)
                if not (ar_lo <= ar <= ar_hi):
                    continue
                cv2.drawContours(vis, [c], -1, (0, 0, 255), 2)
                cv2.rectangle(vis, (x, y), (x+w, y+h), (0, 255, 0), 2)
                cv2.putText(vis, f"ROI {n_valid+1}", (x, max(y-8, 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
                # ── Centroid cross-hair (orange) ─────────────────────────────
                Mc = cv2.moments(c)
                if Mc["m00"] > 0:
                    ccx = int(round(Mc["m10"] / Mc["m00"]))
                    ccy = int(round(Mc["m01"] / Mc["m00"]))
                else:
                    ccx, ccy = x + w // 2, y + h // 2
                arm = 18
                cv2.line(vis, (ccx - arm, ccy), (ccx + arm, ccy), (0, 165, 255), 2)
                cv2.line(vis, (ccx, ccy - arm), (ccx, ccy + arm), (0, 165, 255), 2)
                cv2.circle(vis, (ccx, ccy), 5, (0, 165, 255), -1)
                cv2.putText(vis, f"cx={ccx} cy={ccy}", (ccx + 8, max(ccy - 8, 10)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 165, 255), 1)
                n_valid += 1
                if n_valid >= self.maxroi_spin.value():
                    break
        return cv2.cvtColor(vis, cv2.COLOR_BGR2RGB), n_valid

    def _on_thresh_changed(self, val: int):
        """Re-run ROI detection and update preview whenever threshold changes.
        Also saves the threshold per-video so switching previews restores it."""
        # 영상별 threshold 저장
        if self._video_path:
            self._thresh_store[self._video_path] = val
            # 큐 테이블도 동기화
            for r in range(self.queue_table.rowCount()):
                item = self.queue_table.item(r, 1)
                if item and item.toolTip() == self._video_path:
                    self.queue_table.item(r, self._COL_THR).setText(str(val))
                    break

        if self._last_frame_rgb is None:
            return
        frame_bgr = cv2.cvtColor(self._last_frame_rgb, cv2.COLOR_RGB2BGR)
        rgb_preview, n_valid = self._detect_and_draw(frame_bgr, val)
        idx = self.frame_slider.value() if self.frame_slider.isEnabled() else 0
        self._show_in_preview(
            rgb_preview, f"Frame {idx}  |  Threshold: {val}  |  {n_valid} ROI(s) detected")
        self._update_roi_status_label(n_valid)

    # ─────────────────────────────────────────────────────────────────────────
    #  Frame-by-frame ROI tracking scrubber
    # ─────────────────────────────────────────────────────────────────────────

    def _update_roi_status_label(self, n_valid: int):
        idx   = self.frame_slider.value()
        total = max(self._total_frames - 1, 0)
        t_sec = idx / self._fps if self._fps else 0.0
        self.frame_info_lbl.setText(f"Frame {idx} / {total}  (t={t_sec:.2f}s)")
        if n_valid == 0:
            self.roi_count_lbl.setText(
                "⚠ No ROI detected on this frame — the organoid may have "
                "moved out of range. Try lowering the threshold or "
                "loosening solidity/aspect-ratio filters.")
            self.roi_count_lbl.setStyleSheet("color:#c0392b; font-weight:bold;")
        else:
            self.roi_count_lbl.setText(f"{n_valid} ROIs detected on this frame.")
            self.roi_count_lbl.setStyleSheet("color:#1A5E1A;")

    def _render_current_frame(self):
        """Seek the dedicated scrub-capture to the slider's frame index and
        redraw the ROI overlay there using the current threshold/shape
        settings. Debounced via self._scrub_timer so dragging the slider
        doesn't try to decode every intermediate frame."""
        if self._scrub_cap is None or not self._scrub_cap.isOpened():
            return
        idx = self.frame_slider.value()
        self._scrub_cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ret, frame = self._scrub_cap.read()
        if not ret:
            return
        self._last_frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        self._on_thresh_changed(self.thresh_slider.value())
        self._update_map_overlay(idx)

    def _update_map_overlay(self, frame_idx: int):
        """
        Update the 4-panel map overlay below the scrubber for frame_idx.
        Shows contour + per-frame displacement/strain/Δκ relative to rest.
        Only active after Compute Activation Map has been run.
        """
        if not hasattr(self, '_mech_maps_cache') or not self._roi_cards:
            return
        # Use ROI selected in dropdown (falls back to first available)
        roi_name = self._map_roi_combo.currentText() if self._map_roi_combo.count() else ""
        m = self._mech_maps_cache.get(roi_name)
        if m is None:
            if not self._mech_maps_cache:
                return
            roi_name = next(iter(self._mech_maps_cache))
            m = self._mech_maps_cache[roi_name]

        raw        = self._raw_signals.get(roi_name, {})
        frame_cnts = raw.get("frame_cnts", [])
        frame_bgs  = raw.get("frame_bgs",  [])
        px_to_mm   = m.px_to_mm

        if not frame_cnts or frame_idx >= len(frame_cnts):
            return

        from core.mechanical_maps import (
            _resample_contour, _align_contour_start,
            _radial_displacement, _arc_strain, _compute_curvature, N_CONTOUR
        )
        from matplotlib.colors import TwoSlopeNorm, Normalize

        cnt_t_raw = frame_cnts[frame_idx]
        if cnt_t_raw is None:
            return

        cnt_t_xy = cnt_t_raw[:, 0, :] if cnt_t_raw.ndim == 3 else cnt_t_raw
        cnt_r = m.contour_rest_px   # (N,2) already resampled

        # ── Centroid-based drift correction ──────────────────────────────
        # Align frame-t contour centroid to rest centroid,
        # removing rigid-body translation before measuring shape change.
        cx_rest = cnt_r[:, 0].mean()
        cy_rest = cnt_r[:, 1].mean()
        cnt_t_xy = cnt_t_xy.astype(float).copy()
        cnt_t_xy[:, 0] += (cx_rest - cnt_t_xy[:, 0].mean())
        cnt_t_xy[:, 1] += (cy_rest - cnt_t_xy[:, 1].mean())

        cnt_t = _resample_contour(cnt_t_xy, N_CONTOUR)
        shift = _align_contour_start(cnt_r, cnt_t)
        cnt_t = np.roll(cnt_t, -shift, axis=0)

        # Per-frame maps
        rad_t   = _radial_displacement(cnt_r, cnt_t)
        strain_t= _arc_strain(cnt_r, cnt_t, window_pts=7)
        kr_t    = _compute_curvature(cnt_t, px_to_mm, poly_order=3, window=22)
        dk_t    = kr_t - m.kappa_rest

        cx_t = cnt_t[:, 0] * px_to_mm
        cy_t = -cnt_t[:, 1] * px_to_mm

        # Draw
        DARK = '#0d0d0d'; TEXT = '#e8e8e8'; ACC = '#00d4ff'
        axes = self._map_overlay_ax
        titles = ['Contour', 'A Displacement', 'B Strain', 'C Δκ']
        for ax in axes:
            ax.cla()
            ax.set_facecolor(DARK)
            ax.tick_params(colors=TEXT, labelsize=5)
            for sp in ax.spines.values(): sp.set_color('#333')

        pad = 0.1
        xlim = (m.cx.min()-pad, m.cx.max()+pad)
        ylim = (m.cy.min()-pad, m.cy.max()+pad)

        def _snorm(v):
            v = max(float(v), 0.01)
            if v > 0:
                return TwoSlopeNorm(vmin=-v, vcenter=0, vmax=v)
            return Normalize(vmin=-1, vmax=1)

        # Panel 0: contour overlay
        if frame_bgs and frame_idx < len(frame_bgs):
            bg = frame_bgs[frame_idx]
            bh, bw = bg.shape[:2]
            axes[0].imshow(bg, cmap='gray', origin='upper', aspect='equal',
                           extent=[0, bw*px_to_mm, bh*px_to_mm, 0])
        axes[0].plot(m.cx, m.cy, '-', color='#ff4444', lw=1, alpha=0.7, label='Rest')
        axes[0].plot(cx_t, cy_t, '-', color='#4488ff', lw=1, alpha=0.9, label=f'f{frame_idx}')
        axes[0].legend(fontsize=5, facecolor='#1a1a1a', labelcolor=TEXT)
        axes[0].set_xlim(xlim); axes[0].set_ylim(ylim)
        axes[0].set_aspect('equal'); axes[0].set_axis_off()
        axes[0].set_title(f'Frame {frame_idx}', color=ACC, fontsize=7)

        # A: Displacement
        sc_a = axes[1].scatter(m.cx, m.cy, c=rad_t, cmap='RdBu_r',
                               norm=_snorm(np.abs(rad_t).max()), s=4)
        axes[1].set_xlim(xlim); axes[1].set_ylim(ylim)
        axes[1].set_aspect('equal')
        axes[1].set_title('Disp (px)', color=ACC, fontsize=7)

        # B: Strain
        sc_b = axes[2].scatter(m.cx, m.cy, c=strain_t, cmap='RdBu_r',
                               norm=_snorm(np.abs(strain_t).max()), s=4)
        axes[2].set_xlim(xlim); axes[2].set_ylim(ylim)
        axes[2].set_aspect('equal')
        axes[2].set_title('Strain (%)', color=ACC, fontsize=7)

        # C: Δκ
        sc_c = axes[3].scatter(m.cx, m.cy, c=dk_t, cmap='RdBu_r',
                               norm=_snorm(np.abs(dk_t).max()), s=4)
        axes[3].set_xlim(xlim); axes[3].set_ylim(ylim)
        axes[3].set_aspect('equal')
        axes[3].set_title('Δκ (mm⁻¹)', color=ACC, fontsize=7)

        self._map_overlay_fig.suptitle(
            f'Frame {frame_idx} vs rest={m.rest_idx}',
            color=TEXT, fontsize=7, y=0.98)
        self._map_overlay_canvas.draw_idle()

    def _on_frame_slider_changed(self, idx: int):
        # Update the frame counter immediately so dragging feels responsive,
        # then debounce the actual (more expensive) seek + redraw.
        total = max(self._total_frames - 1, 0)
        t_sec = idx / self._fps if self._fps else 0.0
        self.frame_info_lbl.setText(f"Frame {idx} / {total}  (t={t_sec:.2f}s)")
        self._scrub_timer.start(30)

    def _toggle_playback(self):
        if self._play_timer.isActive():
            self._stop_playback()
            return
        if self._total_frames <= 1:
            return
        interval = max(int(1000 / self._fps), 15)
        self._play_timer.start(interval)
        self.btn_play.setText("⏸")

    def _stop_playback(self):
        self._play_timer.stop()
        self.btn_play.setText("▶")

    def _advance_playback(self):
        idx = self.frame_slider.value()
        if idx >= self.frame_slider.maximum():
            self._stop_playback()
            return
        self.frame_slider.setValue(idx + 1)

    # ─────────────────────────────────────────────────────────────────────────
    #  Step 1 — Batch queue management
    # ─────────────────────────────────────────────────────────────────────────

    def _add_videos(self):
        """멀티 파일 선택 → 백그라운드 프로브 (UI 블로킹/튕김 방지)."""
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Select Videos", "", "Video (*.avi *.mp4 *.mov *.mkv *.tif *.tiff)")
        if not paths:
            return
        new_paths = [p for p in paths if p not in self._video_queue]
        if not new_paths:
            return

        for path in new_paths:
            self._video_queue.append(path)
            self._append_queue_row_placeholder(path)

        if self._video_path is None and self._video_queue:
            self._preview_video(self._video_queue[0])

        # 백그라운드에서 fps/duration/threshold 프로브
        self._probe_worker = QueueProbeWorker(new_paths)
        self._probe_worker.one_done.connect(self._on_probe_one_done)
        self._probe_worker.all_done.connect(self._on_probe_all_done)
        self._probe_worker.error.connect(self._on_probe_error)
        self._probe_worker.start()


    def _append_queue_row_placeholder(self, path: str):
        """큐 테이블에 행 즉시 추가 (프로브 완료 전 '로딩 중' 표시)."""
        row = self.queue_table.rowCount()
        self.queue_table.insertRow(row)

        num_item  = QTableWidgetItem(str(row + 1))
        num_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        name_item = QTableWidgetItem(Path(path).name)
        name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        name_item.setToolTip(path)
        fps_item  = QTableWidgetItem("…")
        thr_item  = QTableWidgetItem("…")
        ts_item   = QTableWidgetItem("0.0")
        te_item   = QTableWidgetItem("…")
        stat_item = QTableWidgetItem("Probing…")
        stat_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        stat_item.setForeground(Qt.GlobalColor.darkGray)

        for col, item in enumerate([num_item, name_item, fps_item,
                                     thr_item, ts_item, te_item, stat_item]):
            self.queue_table.setItem(row, col, item)

    def _append_queue_row(self, path: str):
        """기존 호환용 — 동기 프로브 (단일 파일에만 사용)."""
        row = self.queue_table.rowCount()
        self.queue_table.insertRow(row)
        cap   = cv2.VideoCapture(path)
        fps_s = cap.get(cv2.CAP_PROP_FPS)
        n_fr  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        ret, fr = cap.read()
        cap.release()
        if not fps_s or np.isnan(fps_s) or fps_s <= 0:
            fps_s = 30.0
        dur_s = n_fr / fps_s if fps_s > 0 else 0.0
        if ret:
            gray = cv2.cvtColor(fr, cv2.COLOR_BGR2GRAY)
            blur = cv2.GaussianBlur(gray, (11, 11), 0)
            ov, _ = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            auto_thr = max(10, min(220, int(ov * 0.85)))
        else:
            auto_thr = self.thresh_slider.value()
        num_item  = QTableWidgetItem(str(row + 1))
        num_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        name_item = QTableWidgetItem(Path(path).name)
        name_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        name_item.setToolTip(path)
        fps_item  = QTableWidgetItem(f"{fps_s:.1f}")
        thr_item  = QTableWidgetItem(str(auto_thr))
        ts_item   = QTableWidgetItem("0.0")
        te_item   = QTableWidgetItem(f"{dur_s:.1f}")
        stat_item = QTableWidgetItem("Queued")
        stat_item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        stat_item.setForeground(Qt.GlobalColor.darkGray)
        for col, item in enumerate([num_item, name_item, fps_item,
                                     thr_item, ts_item, te_item, stat_item]):
            self.queue_table.setItem(row, col, item)

        # 현재 UI의 px/µm 및 Step 3 파라미터를 이 영상의 초기값으로 저장
        if path not in self._extract_params_store:
            self._extract_params_store[path] = {
                "px_per_um":    self.px_um_spin.value(),
                "fps_override": fps_s if self.fps_override_chk.isChecked() else None,
                "sg_window":    self.sg_spin.value(),
                "baseline_pct": self.baseline_spin.value(),
                "trim_start_s": 0.0,
                "trim_end_s":   round(dur_s, 1),
            }

    def _on_probe_one_done(self, path: str, fps_s: float, dur_s: float, auto_thr: int):
        """QueueProbeWorker의 one_done 시그널 — 해당 행 업데이트.
        이미 사용자가 저장한 threshold가 있으면 덮어쓰지 않음."""
        for r in range(self.queue_table.rowCount()):
            item = self.queue_table.item(r, 1)
            if item and item.toolTip() == path:
                self.queue_table.item(r, self._COL_FPS).setText(f"{fps_s:.1f}")
                # 저장된 threshold 없을 때만 auto 값 사용
                if path not in self._thresh_store:
                    self.queue_table.item(r, self._COL_THR).setText(str(auto_thr))
                self.queue_table.item(r, self._COL_TE).setText(f"{dur_s:.1f}")
                stat = self.queue_table.item(r, self._COL_STAT)
                stat.setText("Queued")
                stat.setForeground(Qt.GlobalColor.darkGray)
                break

    def _on_probe_all_done(self):
        pass  # 필요 시 완료 알림 추가

    def _on_probe_error(self, path: str, msg: str):
        """프로브 실패 시 해당 행에 오류 표시."""
        for r in range(self.queue_table.rowCount()):
            item = self.queue_table.item(r, 1)
            if item and item.toolTip() == path:
                stat = self.queue_table.item(r, self._COL_STAT)
                stat.setText("Error")
                stat.setForeground(Qt.GlobalColor.red)
                break


    def _purge_video_data(self, path: str):
        """path에 연관된 모든 per-video 저장 데이터를 완전히 초기화한다."""
        for store in (self._roi_store, self._thresh_store, self._mode_store,
                      self._scan_store, self._extract_params_store,
                      self._extract_state_store):
            store.pop(path, None)

    def _remove_selected_videos(self):
        rows = sorted(set(i.row() for i in self.queue_table.selectedItems()),
                       reverse=True)
        removed_paths = []
        for row in rows:
            path = self.queue_table.item(row, 1).toolTip()
            removed_paths.append(path)
            if path in self._video_queue:
                self._video_queue.remove(path)
            self.queue_table.removeRow(row)

        # 제거된 영상의 모든 저장 데이터 초기화
        for path in removed_paths:
            self._purge_video_data(path)

        # Renumber remaining rows
        for r in range(self.queue_table.rowCount()):
            self.queue_table.item(r, 0).setText(str(r + 1))

        # 현재 미리보기 영상이 제거된 경우 초기화
        if self._video_path in removed_paths:
            self._video_path = None

        if not self._video_queue:
            self._video_path = None
            self.video_label.setText("No video loaded")
            self.video_label.setStyleSheet("color: gray;")

    def _clear_queue(self):
        from PyQt5.QtWidgets import QMessageBox
        reply = QMessageBox.question(
            self, "Clear All",
            "모든 영상과 분석 데이터(ROI, threshold, 결과 등)를 초기화합니다.\n계속하시겠습니까?",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        if reply != QMessageBox.Yes:
            return

        # 모든 per-video 저장 데이터 완전 초기화
        self._roi_store.clear()
        self._thresh_store.clear()
        self._mode_store.clear()
        self._scan_store.clear()
        self._extract_params_store.clear()
        self._extract_state_store.clear()

        self.queue_table.setRowCount(0)
        self._video_queue.clear()
        self._video_path = None
        self.video_label.setText("No video loaded")
        self.video_label.setStyleSheet("color: gray;")

    def _apply_shared_to_all(self):
        """현재 Step 3 파라미터(px/µm 포함)를 큐의 모든 영상에 일괄 적용."""
        fps_val    = self.fps_spin.value()
        thr_val    = self.thresh_slider.value()
        ts_val     = self.trim_start_spin.value()
        te_val     = self.trim_end_spin.value()
        px_val     = self.px_um_spin.value()
        sg_val     = self.sg_spin.value()
        bl_val     = self.baseline_spin.value()
        fps_ov     = fps_val if self.fps_override_chk.isChecked() else None

        for r in range(self.queue_table.rowCount()):
            path = self.queue_table.item(r, 1).toolTip()
            self.queue_table.item(r, self._COL_FPS).setText(f"{fps_val:.1f}")
            self.queue_table.item(r, self._COL_THR).setText(str(thr_val))
            self.queue_table.item(r, self._COL_TS).setText(f"{ts_val:.1f}")
            self.queue_table.item(r, self._COL_TE).setText(f"{te_val:.1f}")
            # px/µm + Step 3 파라미터도 _extract_params_store에 저장
            self._extract_params_store[path] = {
                "px_per_um":    px_val,
                "fps_override": fps_ov,
                "sg_window":    sg_val,
                "baseline_pct": bl_val,
                "trim_start_s": ts_val,
                "trim_end_s":   te_val,
            }

    # ─────────────────────────────────────────────────────────────────────────
    #  Step 3 파라미터 영상별 자동 저장/복원
    # ─────────────────────────────────────────────────────────────────────────

    def _save_extract_params(self, *_):
        """Step 3 파라미터가 변경될 때마다 현재 영상에 자동 저장."""
        if not self._video_path:
            return
        self._extract_params_store[self._video_path] = {
            "px_per_um":    self.px_um_spin.value(),
            "fps_override": self.fps_spin.value() if self.fps_override_chk.isChecked() else None,
            "sg_window":    self.sg_spin.value(),
            "baseline_pct": self.baseline_spin.value(),
            "trim_start_s": self.trim_start_spin.value(),
            "trim_end_s":   self.trim_end_spin.value(),
        }

    def _restore_extract_params(self, path: str):
        """영상 전환 시 해당 영상의 Step 3 파라미터 복원.
        저장된 값이 없으면 기본값으로 초기화."""
        p = self._extract_params_store.get(path)

        _prev = self._video_path
        self._video_path = None   # 저장 트리거 방지

        if p is None:
            # 저장된 값 없음 → 기본값 초기화
            # (단, px/µm은 사용자가 이미 입력했을 수 있으므로 576 기본값 사용)
            self.px_um_spin.setValue(576.0)
            self.sg_spin.setValue(11)
            self.baseline_spin.setValue(90)
            self.trim_start_spin.setValue(0.0)
            self.fps_override_chk.setChecked(False)
        else:
            self.px_um_spin.setValue(p["px_per_um"])
            self.sg_spin.setValue(p["sg_window"])
            self.baseline_spin.setValue(p["baseline_pct"])
            self.trim_start_spin.setValue(p["trim_start_s"])
            self.trim_end_spin.setValue(p["trim_end_s"])
            if p["fps_override"] is not None:
                self.fps_override_chk.setChecked(True)
                self.fps_spin.setValue(p["fps_override"])
            else:
                self.fps_override_chk.setChecked(False)

        self._video_path = _prev

    def _on_queue_selection_changed(self):
        """Preview the video in the row that was just clicked.
        threshold, ROI, stability bar를 복원."""
        rows = list(set(i.row() for i in self.queue_table.selectedItems()))
        if not rows:
            return
        row = rows[0]
        name_item = self.queue_table.item(row, 1)
        if name_item is None:
            return
        path = name_item.toolTip()
        if not path or path == self._video_path:
            return

        self._preview_video(path)

        # ── threshold 복원 ────────────────────────────────────────────────────
        saved_thr = self._thresh_store.get(path)
        if saved_thr is not None:
            self.thresh_slider.blockSignals(True)
            self.thresh_slider.setValue(saved_thr)
            self.thresh_slider.blockSignals(False)
            self.thresh_lbl.setText(str(saved_thr))

        # ── stability bar 복원 ───────────────────────────────────────────────
        saved_scan = self._scan_store.get(path)
        if saved_scan is not None:
            stab_pct = int(saved_scan.stability * 100)
            self.stability_bar.setValue(stab_pct)
            if stab_pct >= 85:
                self.stability_bar.setStyleSheet(
                    "QProgressBar::chunk { background: #2ecc71; }")
                self.ai_status_lbl.setText(f"✅  ROI 안정적 ({stab_pct}%)")
                self.ai_status_lbl.setStyleSheet("color: #1a5e1a;")
            elif stab_pct >= 60:
                self.stability_bar.setStyleSheet(
                    "QProgressBar::chunk { background: #f39c12; }")
                self.ai_status_lbl.setText(f"⚠  부분 불안정 ({stab_pct}%)")
                self.ai_status_lbl.setStyleSheet("color: #a04000;")
            else:
                self.stability_bar.setStyleSheet(
                    "QProgressBar::chunk { background: #e74c3c; }")
                self.ai_status_lbl.setText(f"❌  불안정 ({stab_pct}%)")
                self.ai_status_lbl.setStyleSheet("color: #c0392b;")
            if saved_scan.bad_ranges:
                lines = [f"  • {s:.1f}s ~ {e:.1f}s  ({r})"
                         for s, e, r in saved_scan.bad_ranges]
                self.bad_range_lbl.setText("이상 구간:\n" + "\n".join(lines))
        else:
            self.stability_bar.setValue(0)
            self.bad_range_lbl.setText("")

        # ── ROI 복원 ─────────────────────────────────────────────────────────
        saved_rois = self._roi_store.get(path, [])
        self._rois = saved_rois
        if saved_rois:
            QTimer.singleShot(300, lambda p=path: self._redraw_saved_rois(p))
        elif saved_thr is not None:
            QTimer.singleShot(300, lambda t=saved_thr: self._on_thresh_changed(t))

        # ── 슬라이더 활성/잠금 상태 복원 (mode_store 기준) ──────────────────
        mode = self._mode_store.get(path, 'auto')
        is_manual = (mode == 'manual')
        self.thresh_slider.setEnabled(is_manual)
        self.thresh_slider.setToolTip(
            "Manual Override 모드 — threshold를 직접 조정하세요" if is_manual else
            "Auto Detect가 Otsu로 자동 결정한 값입니다.\n"
            "직접 조정하려면 '✏️ Manual Override' 버튼을 누르세요.")

        # ── Step 3 파라미터 복원 ────────────────────────────────────────────
        self._restore_extract_params(path)

    def _redraw_saved_rois(self, path: str):
        """Re-draw the saved ROI overlay on the current preview frame."""
        if self._last_frame_rgb is None:
            return
        saved = self._roi_store.get(path, [])
        if not saved:
            return
        frame_bgr = cv2.cvtColor(self._last_frame_rgb, cv2.COLOR_RGB2BGR)
        for i, roi in enumerate(saved):
            cnt = roi.get("contour")
            if cnt is not None:
                cv2.drawContours(frame_bgr, [cnt], -1, (0, 255, 0), 2)
                x, y, w, h = roi["box"]
                cv2.putText(frame_bgr, f"ROI {i+1}", (x, y - 6),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
        vis_rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        self._show_in_preview(
            vis_rgb, f"Saved ROIs ({len(saved)}) for {Path(path).name}")

    def _preview_video(self, path: str):
        """Load the first frame of a video for preview and update shared
        controls (fps detected, trim range, threshold slider)."""
        self._video_path = path
        name = Path(path).name
        self.video_label.setText(f"✓ Previewing: {name}")
        self.video_label.setStyleSheet("color: #1A5E1A;")

        cap = cv2.VideoCapture(path)
        ret, frame = cap.read()
        fps_s = cap.get(cv2.CAP_PROP_FPS)
        n_fr  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        cap.release()
        if not fps_s or np.isnan(fps_s) or fps_s <= 0:
            fps_s = 30.0
        dur_s = n_fr / fps_s if fps_s > 0 else 0.0

        if ret:
            rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            self._last_frame_rgb = rgb
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            blur = cv2.GaussianBlur(gray, (11, 11), 0)
            ov, _ = cv2.threshold(blur, 0, 255,
                                   cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
            auto_thresh = max(10, min(220, int(ov * 0.85)))
            # 저장된 threshold가 없을 때만 auto 값 적용
            if path not in self._thresh_store:
                self.thresh_slider.blockSignals(True)
                self.thresh_slider.setValue(auto_thresh)
                self.thresh_slider.blockSignals(False)
            if "2D Monolayer" in self.model_combo.currentText():
                QTimer.singleShot(150, self._set_fullframe_roi)
            else:
                QTimer.singleShot(100, lambda: self._show_in_preview(
                    rgb, f"First frame — {name}  |  Auto threshold: {auto_thresh}"))

        # Update scrubber
        self._stop_playback()
        if self._scrub_cap is not None:
            self._scrub_cap.release()
        self._scrub_cap = cv2.VideoCapture(path)
        self._total_frames = max(n_fr, 1)
        self._fps = fps_s

        self.fps_spin.setValue(fps_s)
        self.fps_detected_lbl.setText(f"fps  (detected: {fps_s:.1f})")
        self.trim_start_spin.setValue(0.0)
        self.trim_end_spin.setValue(round(dur_s, 1))
        self.trim_end_spin.setMaximum(dur_s + 1.0)

        self.frame_slider.blockSignals(True)
        self.frame_slider.setRange(0, max(self._total_frames - 1, 0))
        self.frame_slider.setValue(0)
        self.frame_slider.blockSignals(False)
        self.frame_slider.setEnabled(self._total_frames > 1)
        self.btn_play.setEnabled(self._total_frames > 1)
        self.frame_info_lbl.setText(
            f"Frame 0 / {max(self._total_frames-1,0)}  (t=0.00s)")
        QTimer.singleShot(250, self._render_current_frame)
        # 이 영상에 저장된 ROI가 없으면 자동 스캔 시작
        if path not in self._roi_store:
            QTimer.singleShot(600, self._auto_detect_rois)

    def _load_video(self):
        """Legacy single-file path — delegates to batch add for compatibility."""
        self._add_videos()

    # ─────────────────────────────────────────────────────────────────────────
    # ─────────────────────────────────────────────────────────────────────────
    #  Step 2 — ROI Detection
    # ─────────────────────────────────────────────────────────────────────────

    def _update_detect_frame_lbl(self, idx: int = 0):
        """scrubber 이동 시 Manual Override 라벨 업데이트."""
        t = idx / self._fps if self._fps else 0.0
        if idx == 0:
            self.detect_frame_lbl.setText("Manual: Frame 0 (first frame)")
        else:
            self.detect_frame_lbl.setText(
                f"Manual: Frame {idx}  (t={t:.2f}s)  ← scrubber 위치")

    def _on_detection_mode_toggled(self, ai_checked: bool):
        """호환성 유지용 (Cellpose 제거됨)."""
        pass

    def _auto_detect_rois(self):
        """Auto Detect: Otsu threshold로 첫 프레임 탐색 + 전체 프레임 스캔.
        Manual Override 상태였다면 완전히 리셋하고 처음부터 재스캔."""
        if not self._video_path:
            QMessageBox.warning(self, "No video", "Load a video first.")
            return

        # ── Manual 상태 완전 초기화 ──────────────────────────────────────────
        self._mode_store[self._video_path] = 'auto'
        self._scan_store.pop(self._video_path, None)        # 이전 scan 결과 제거
        self._manual_override_frame.pop(self._video_path, None)  # manual 프레임 제거
        # threshold를 기본값으로 리셋 (Otsu가 처음부터 재계산)
        self.thresh_slider.blockSignals(True)
        self.thresh_slider.setValue(60)
        self.thresh_slider.blockSignals(False)
        self.thresh_lbl.setText("60")

        self.btn_detect.setEnabled(False)
        self.btn_detect.setText("스캔 중…")
        self.btn_manual_detect.setEnabled(False)
        # threshold는 Auto 모드에서 Otsu가 자동 결정 → 슬라이더 잠금
        self.thresh_slider.setEnabled(False)
        self.thresh_slider.setToolTip("Auto Detect 중 — Otsu가 자동 결정합니다")
        self.stability_bar.setValue(0)
        self.bad_range_lbl.setText("")
        self.ai_status_lbl.setText("전체 프레임 스캔 중… (잠시 기다려주세요)")
        self.ai_status_lbl.setStyleSheet("color: #2a6a9a;")

        self._stop_worker(self._scan_worker)
        self._scan_worker = AutoROIScanner(
            self._video_path,
            threshold    = self.thresh_slider.value(),
            max_rois     = self.maxroi_spin.value(),
            min_solidity = self.solidity_spin.value(),
            min_ar       = self.ar_min_spin.value(),
            max_ar       = self.ar_max_spin.value(),
            scan_step    = 10,
        )
        self._scan_worker.progress.connect(self.stability_bar.setValue)
        self._scan_worker.finished.connect(self._on_scan_done)
        self._scan_worker.error.connect(self._on_scan_error)
        self._scan_worker.start()

    def _on_scan_done(self, result):
        """AutoROIScanner 완료 콜백."""
        self.btn_detect.setEnabled(True)
        self.btn_detect.setText("🔍  Auto Detect ROI")
        self.btn_manual_detect.setEnabled(True)
        # 슬라이더는 Auto 완료 후에도 잠금 유지 (Manual Override 눌러야 활성화)
        # Otsu 계산값은 읽기 전용으로 표시만 함
        self.thresh_slider.setEnabled(False)
        self.thresh_slider.setToolTip(
            "Auto Detect가 Otsu로 자동 결정한 값입니다.\n"
            "직접 조정하려면 '✏️ Manual Override' 버튼을 누르세요.")

        # 안정성 바 업데이트
        stab_pct = int(result.stability * 100)
        self.stability_bar.setValue(stab_pct)
        if stab_pct >= 85:
            self.stability_bar.setStyleSheet(
                "QProgressBar::chunk { background: #2ecc71; }")
            self.ai_status_lbl.setText(
                f"✅  ROI 안정적 ({stab_pct}%) — Extract 진행 가능")
            self.ai_status_lbl.setStyleSheet("color: #1a5e1a;")
        elif stab_pct >= 60:
            self.stability_bar.setStyleSheet(
                "QProgressBar::chunk { background: #f39c12; }")
            self.ai_status_lbl.setText(
                f"⚠  부분 불안정 ({stab_pct}%) — 이상 구간 확인 후 Manual Override 권장")
            self.ai_status_lbl.setStyleSheet("color: #a04000;")
        else:
            self.stability_bar.setStyleSheet(
                "QProgressBar::chunk { background: #e74c3c; }")
            self.ai_status_lbl.setText(
                f"❌  불안정 ({stab_pct}%) — scrubber로 안정적 프레임 찾아 Manual Override 필요")
            self.ai_status_lbl.setStyleSheet("color: #c0392b;")

        # 이상 구간 표시
        if result.bad_ranges:
            lines = [f"  • {s:.1f}s ~ {e:.1f}s  ({r})"
                     for s, e, r in result.bad_ranges]
            self.bad_range_lbl.setText("이상 구간:\n" + "\n".join(lines))
        else:
            self.bad_range_lbl.setText("")

        # ROI 저장 및 threshold 자동 업데이트
        if result.rois:
            self._roi_store[self._video_path]    = result.rois
            self._thresh_store[self._video_path] = result.threshold
            self._scan_store[self._video_path]   = result
            self._rois = result.rois
            # 슬라이더를 자동 계산된 threshold로 업데이트
            self.thresh_slider.blockSignals(True)
            self.thresh_slider.setValue(result.threshold)
            self.thresh_slider.blockSignals(False)
            self.thresh_lbl.setText(str(result.threshold))
            # 큐 테이블 상태 업데이트
            for r in range(self.queue_table.rowCount()):
                item = self.queue_table.item(r, 1)
                if item and item.toolTip() == self._video_path:
                    stat = self.queue_table.item(r, self._COL_STAT)
                    icon = "✅" if stab_pct >= 85 else ("⚠" if stab_pct >= 60 else "❌")
                    stat.setText(f"{icon} ROI×{len(result.rois)} ({stab_pct}%)")
                    stat.setForeground(
                        Qt.GlobalColor.darkGreen if stab_pct >= 85 else Qt.GlobalColor.darkRed)
                    break
            self._show_in_preview(result.vis_rgb,
                f"Auto ROI: {len(result.rois)}개  |  안정성 {stab_pct}%  "
                f"|  Threshold {result.threshold}")
            self.btn_save_roi.setEnabled(True)
        else:
            self.ai_status_lbl.setText(
                "❌  첫 프레임에서 ROI를 찾지 못했습니다. "
                "Threshold를 조정하고 Manual Override를 시도하세요.")
            self.ai_status_lbl.setStyleSheet("color: #c0392b;")

    def _on_scan_error(self, msg: str):
        self.btn_detect.setEnabled(True)
        self.btn_detect.setText("🔍  Auto Detect ROI")
        self.btn_manual_detect.setEnabled(True)
        QMessageBox.critical(self, "Scan error", msg)

    def _manual_detect_rois(self):
        """Manual Override: scrubber 현재 프레임에서 threshold 기반 ROI 탐색."""
        if not self._video_path:
            QMessageBox.warning(self, "No video", "Load a video first.")
            return

        # Manual 모드 진입 → 모드 저장 + 슬라이더 활성화
        self._mode_store[self._video_path] = 'manual'
        self.thresh_slider.setEnabled(True)
        self.thresh_slider.setToolTip("Manual Override 모드 — threshold를 직접 조정하세요")

        frame_idx = self.frame_slider.value() if self.frame_slider.isEnabled() else 0

        self.btn_manual_detect.setEnabled(False)
        self.btn_manual_detect.setText("Detecting…")
        self.btn_save_roi.setEnabled(False)

        self._stop_worker(self._detect_worker)
        self._detect_worker = ROIDetectWorker(
            self._video_path,
            threshold     = self.thresh_slider.value(),
            max_rois      = self.maxroi_spin.value(),
            min_solidity  = self.solidity_spin.value(),
            min_ar        = self.ar_min_spin.value(),
            max_ar        = self.ar_max_spin.value(),
            min_area_frac = 0.001,
            max_area_frac = 0.80,
            frame_idx     = frame_idx,
        )
        self._detect_worker.finished.connect(
            lambda rois, vis, m: self._on_manual_rois_detected(rois, vis, frame_idx))
        self._detect_worker.error.connect(
            lambda e: (QMessageBox.critical(self, "Error", e),
                        self.btn_manual_detect.setEnabled(True),
                        self.btn_manual_detect.setText("✏️  Manual Override (현재 프레임)")))
        self._detect_worker.start()

    def _on_manual_rois_detected(self, rois, vis_rgb, frame_idx: int):
        """Manual Override ROI 탐색 완료 콜백."""
        self.btn_manual_detect.setEnabled(True)
        self.btn_manual_detect.setText("✏️  Manual Override (현재 프레임)")

        if not rois:
            QMessageBox.warning(self, "No ROI",
                "이 프레임에서 ROI를 찾지 못했습니다.\n"
                "Threshold를 조정하거나 다른 프레임을 선택해보세요.")
            return

        # 추출 시작점 묻기
        t = frame_idx / self._fps if self._fps else 0.0
        msg = (f"Frame {frame_idx} (t={t:.2f}s)에서 {len(rois)}개 ROI를 찾았습니다.\n\n"
               f"Signal Extraction을 어디서부터 시작할까요?")
        from PyQt5.QtWidgets import QPushButton as _QB
        dlg = QDialog(self)
        dlg.setWindowTitle("추출 시작점 선택")
        dlg.setFont(ARIAL)
        dl = QVBoxLayout(dlg)
        dl.addWidget(_lbl(msg, size=9))
        btn_row = QHBoxLayout()
        btn_full  = _btn("🎬  처음부터 전체 영상", color="#d4f0d4")
        btn_here  = _btn(f"▶  Frame {frame_idx}부터 추출", color="#fff0cc")
        btn_cancel = _btn("취소")
        for b in [btn_full, btn_here, btn_cancel]:
            btn_row.addWidget(b)
        dl.addLayout(btn_row)

        chosen = [None]
        btn_full.clicked.connect(lambda: (chosen.__setitem__(0, 0), dlg.accept()))
        btn_here.clicked.connect(lambda: (chosen.__setitem__(0, frame_idx), dlg.accept()))
        btn_cancel.clicked.connect(dlg.reject)

        if dlg.exec_() != QDialog.Accepted or chosen[0] is None:
            return

        start_frame = chosen[0]
        start_s = start_frame / self._fps if self._fps else 0.0

        # ── ROI box를 Frame 0 기준으로 보정 ──────────────────────────────────
        # Manual Override가 frame_idx에서 실행됐을 때,
        # ROI box 중심 = frame_idx의 오가노이드 위치
        # Frame 0부터 추출 시 centroid tracking이 올바르게 작동하도록
        # ROI box를 frame_idx → frame_0 centroid 차이만큼 역변환
        corrected_rois = rois
        if frame_idx > 0 and start_frame == 0:
            try:
                import cv2 as _cv2
                cap_tmp = _cv2.VideoCapture(self._video_path)

                def _get_centroid(fidx):
                    cap_tmp.set(_cv2.CAP_PROP_POS_FRAMES, fidx)
                    ret, frm = cap_tmp.read()
                    if not ret:
                        return None
                    g = _cv2.cvtColor(frm, _cv2.COLOR_BGR2GRAY)
                    _, bw = _cv2.threshold(g, self.thresh_slider.value(),
                                           255, _cv2.THRESH_BINARY_INV)
                    n_l, labs, stats, cents = _cv2.connectedComponentsWithStats(bw)
                    if n_l < 2:
                        return None
                    largest = 1 + int(stats[1:, _cv2.CC_STAT_AREA].argmax())
                    return cents[largest]   # (cx, cy)

                c_manual = _get_centroid(frame_idx)
                c_frame0 = _get_centroid(0)
                cap_tmp.release()

                if c_manual is not None and c_frame0 is not None:
                    dx = c_frame0[0] - c_manual[0]
                    dy = c_frame0[1] - c_manual[1]
                    corrected_rois = []
                    for roi in rois:
                        rx, ry, rw, rh = roi["box"]
                        corrected_rois.append({
                            **roi,
                            "box": (int(rx + dx), int(ry + dy), rw, rh)
                        })
            except Exception:
                corrected_rois = rois   # 보정 실패 시 원본 사용

        # ROI 저장
        self._rois = corrected_rois
        self._roi_store[self._video_path]    = corrected_rois
        self._thresh_store[self._video_path] = self.thresh_slider.value()
        self._manual_override_frame[self._video_path] = start_frame

        for r in range(self.queue_table.rowCount()):
            item = self.queue_table.item(r, 1)
            if item and item.toolTip() == self._video_path:
                stat = self.queue_table.item(r, self._COL_STAT)
                stat.setText(f"✏️ ROI×{len(rois)} fr{start_frame}")
                stat.setForeground(QColor("#a04000"))
                # 큐 테이블 Trim start도 자동 업데이트
                self.queue_table.item(r, self._COL_TS).setText(f"{start_s:.1f}")
                break

        # trim_start_spin도 자동 반영
        self.trim_start_spin.setValue(start_s)

        self._show_in_preview(vis_rgb,
            f"Manual ROI: {len(rois)}개  |  Frame {frame_idx}  "
            f"|  추출 시작: {'처음' if start_frame == 0 else f'{start_s:.2f}s'}")
        self.ai_status_lbl.setText(
            f"✏️  Manual Override 완료 — {len(rois)}개 ROI "
            f"({'처음부터' if start_frame == 0 else f'{start_s:.1f}s부터'} 추출)")
        self.ai_status_lbl.setStyleSheet("color: #5a3000;")
        self.btn_save_roi.setEnabled(True)

    def _detect_rois(self):
        """호환성 유지 — Auto Detect로 위임."""
        self._auto_detect_rois()

    def _on_rois_detected(self, rois, vis_rgb, method='cv'):
        """호환성 유지."""
        self._rois = rois
        if self._video_path:
            self._roi_store[self._video_path] = rois

    def _save_roi_feedback(self):
        """현재 ROI 세션 내 저장 확인."""
        if not self._rois or not self._video_path:
            QMessageBox.warning(self, "No ROI", "먼저 ROI를 감지하세요.")
            return
        n = len(self._rois)
        self.ai_status_lbl.setText(f"ROI {n}개 저장됨 (이 세션 유지)")
        QMessageBox.information(self, "저장 완료",
            f"{n}개 ROI가 저장되었습니다.\n영상 전환 후 돌아와도 ROI가 유지됩니다.")

    #  Step 3 — Extract signals
    # ─────────────────────────────────────────────────────────────────────────

    def _extract_signals(self):
        """상태 기반 스마트 배치 추출:
        - 파라미터 동일 + 이미 완료 → 자동 스킵
        - 파라미터 변경 또는 미완료 → 재추출
        """
        if not self._video_queue:
            QMessageBox.warning(self, "No videos", "Add videos to the queue first.")
            return

        # 큐 테이블에서 per-row 파라미터 수집
        queue_params = []
        for r in range(self.queue_table.rowCount()):
            path = self.queue_table.item(r, 1).toolTip()
            try:
                fps_v = float(self.queue_table.item(r, self._COL_FPS).text())
            except Exception:
                fps_v = None
            try:
                thr_v = int(self.queue_table.item(r, self._COL_THR).text())
            except Exception:
                thr_v = self.thresh_slider.value()
            try:
                ts_v  = float(self.queue_table.item(r, self._COL_TS).text())
            except Exception:
                ts_v  = 0.0
            try:
                te_v  = float(self.queue_table.item(r, self._COL_TE).text())
            except Exception:
                te_v  = 0.0
            queue_params.append((r, path, fps_v, thr_v, ts_v, te_v))

        # ── 상태 표시 다이얼로그 ─────────────────────────────────────────────
        dlg = BatchSelectDialog(
            queue_params, self._roi_store,
            self._extract_state_store, self._extract_params_store, self)
        if dlg.exec_() != QDialog.Accepted:
            return
        selected = dlg.selected_rows()
        if not selected:
            QMessageBox.information(self, "Nothing selected",
                                     "추출할 영상이 선택되지 않았습니다.")
            return

        # ROI 없는 영상 검사
        missing = [Path(p).name for _, p, *_ in selected
                   if not self._roi_store.get(p)]
        if missing:
            QMessageBox.warning(self, "Missing ROIs",
                "다음 영상에 ROI가 없습니다:\n" + "\n".join(missing))
            return

        # 선택된 영상만 상태 리셋 (나머지 기존 결과는 유지)
        for r, *_ in selected:
            self.queue_table.item(r, self._COL_STAT).setText("Queued")
            self.queue_table.item(r, self._COL_STAT).setForeground(
                Qt.GlobalColor.darkGray)

        # 선택된 영상의 ROI card만 제거하고 나머지 유지
        selected_paths = {p for _, p, *_ in selected}
        remaining_cards = []
        for card in self._roi_cards:
            card_path = getattr(card, '_video_path', None)
            if card_path in selected_paths:
                card.setParent(None)
            else:
                remaining_cards.append(card)
        self._roi_cards = remaining_cards

        self._batch_queue_params = selected
        self._batch_idx          = 0
        self._run_next_batch()

    def _run_next_batch(self):
        """큐의 다음 영상 추출 실행."""
        if self._batch_idx >= len(self._batch_queue_params):
            return

        r, path, fps_v, thr_v, ts_v, te_v = \
            self._batch_queue_params[self._batch_idx]

        rois = self._roi_store.get(path, [])
        if not rois:
            self.queue_table.item(r, self._COL_STAT).setText("Skip – no ROI")
            self.queue_table.item(r, self._COL_STAT).setForeground(Qt.GlobalColor.red)
            self._batch_idx += 1
            self._run_next_batch()
            return

        # 이 영상의 저장된 Step 3 파라미터 사용 (없으면 현재 UI 값)
        ep = self._extract_params_store.get(path, {})
        px_per_um    = ep.get("px_per_um",   self.px_um_spin.value())
        fps_override = ep.get("fps_override", fps_v)
        sg_window    = ep.get("sg_window",    self.sg_spin.value())
        baseline_pct = ep.get("baseline_pct", self.baseline_spin.value())
        trim_start_s = ep.get("trim_start_s", ts_v)
        trim_end_s   = ep.get("trim_end_s",   te_v)

        # 현재 추출에 쓰인 파라미터 해시 (완료 후 저장용)
        cur_hash = _params_hash({
            "px_per_um": px_per_um, "fps_override": fps_override,
            "sg_window": sg_window, "baseline_pct": baseline_pct,
            "trim_start_s": trim_start_s, "trim_end_s": trim_end_s,
            "thr": thr_v,
        })

        self.queue_table.item(r, self._COL_STAT).setText("Running…")
        self.queue_table.item(r, self._COL_STAT).setForeground(Qt.GlobalColor.darkBlue)
        self.queue_table.scrollToItem(self.queue_table.item(r, 0))

        n = self._batch_idx + 1
        total = len(self._batch_queue_params)
        self._prog = QProgressDialog(
            f"[{n}/{total}]  Extracting: {Path(path).name}",
            None, 0, 100, self)
        self._prog.setWindowModality(Qt.WindowModal)
        self._prog.show()

        self._stop_worker(self._extract_worker)
        self._extract_worker = SignalExtractWorker(
            path, rois,
            px_per_um    = px_per_um,
            threshold    = thr_v,
            fps_override = fps_override,
            trim_start_s = trim_start_s,
            trim_end_s   = trim_end_s,
        )
        self._extract_worker.progress.connect(self._prog.setValue)
        self._extract_worker.finished.connect(
            lambda res, _r=r, _path=path, _h=cur_hash, _sg=sg_window, _bl=baseline_pct:
                self._on_batch_item_done(res, _r, _path, _h, _sg, _bl))
        self._extract_worker.error.connect(
            lambda e, _r=r: self._on_batch_item_error(e, _r))
        self._extract_worker.start()

    def _on_batch_item_done(self, results: dict, table_row: int, path: str,
                             params_hash: str, sg_window: int, baseline_pct: int):
        self._prog.close()

        # 추출 상태 저장
        self._extract_state_store[path] = {
            "status":      "done",
            "params_hash": params_hash,
        }

        # _raw_signals에 저장 → export 시 heatmap/contour/CSV에 사용
        for roi_name, data in results.items():
            vid_name = Path(path).stem
            label = f"{vid_name} / {roi_name}"
            self._raw_signals[label] = data

        stat = self.queue_table.item(table_row, self._COL_STAT)
        roi_count = len(results)
        stat.setText(f"Ready · {roi_count} ROIs")
        stat.setForeground(Qt.GlobalColor.darkGreen)

        vid_name = Path(path).stem
        for roi_name, data in results.items():
            label = f"{vid_name} / {roi_name}"
            card = ROICard(label, data,
                            sg_window    = sg_window,
                            baseline_pct = baseline_pct)
            card._video_path = path   # 나중에 개별 재추출 시 식별용
            self._roi_cards.append(card)
            self._results_hint.hide()
            self._cards_layout.addWidget(card)
            self.result_tabs.setTabText(1, f"Signals + features ({len(self._roi_cards)})")

        self._batch_idx += 1
        self._run_next_batch()

    def _on_batch_item_error(self, msg: str, table_row: int):
        self._prog.close()
        stat = self.queue_table.item(table_row, self._COL_STAT)
        stat.setText("Error")
        stat.setForeground(Qt.GlobalColor.red)
        QMessageBox.warning(self, "Extraction error",
                             f"Row {table_row+1}: {msg}\n\nContinuing with next video…")
        self._batch_idx += 1
        self._run_next_batch()

    # ─────────────────────────────────────────────────────────────────────────
    #  Step 4 — Activation & Mechanical Maps
    # ─────────────────────────────────────────────────────────────────────────

    def _compute_strain(self):
        """Step 4 — Contour-based mechanical maps (A-D) for ALL ROIs.
        Results cached in _mech_maps_cache; result figure shows currently
        selected ROI (from _map_roi_combo dropdown).
        """
        if not self._video_path or not self._roi_cards:
            QMessageBox.warning(self, "No data", "Extract signals first.")
            return
        try:
            from core.mechanical_maps import MechanicalMapAnalyzer
        except ImportError:
            QMessageBox.critical(self, "Import error",
                                 "core/mechanical_maps.py not found.")
            return

        px_um    = float(self.px_um_spin.value())
        px_to_mm = 1.0 / (px_um * 1000.0) if px_um > 0 else 1.0 / 7.8

        fps_ov = self.fps_override_chk.isChecked()
        cap    = cv2.VideoCapture(self._video_path)
        fps    = float(self.fps_spin.value()) if fps_ov else (cap.get(cv2.CAP_PROP_FPS) or 30.0)
        n_tot  = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

        # Read full video once (grayscale)
        full_frames_gray = []
        while True:
            ret, frm = cap.read()
            if not ret:
                break
            full_frames_gray.append(cv2.cvtColor(frm, cv2.COLOR_BGR2GRAY))
        cap.release()

        if len(full_frames_gray) < 10:
            QMessageBox.warning(self, "Too few frames", "Need >= 10 frames.")
            return

        if not hasattr(self, '_mech_maps_cache'):
            self._mech_maps_cache = {}

        errors = []
        for card in self._roi_cards:
            roi_name = card.get_roi_name()
            try:
                roi_idx = int(roi_name.split()[-1]) - 1
            except (ValueError, IndexError):
                roi_idx = 0
            if roi_idx >= len(self._rois):
                continue

            x, y, w, h = self._rois[roi_idx]["box"]
            frames = [f[y:y+h, x:x+w] for f in full_frames_gray]

            raw           = self._raw_signals.get(roi_name, {})
            frame_cnts    = raw.get("frame_cnts", [])
            frame_bgs     = raw.get("frame_bgs",  [])
            rest_idx      = raw.get("rest_idx", None)
            peak_idx      = raw.get("peak_idx", None)
            area_peaks    = raw.get("area_peaks",   [])
            area_troughs  = raw.get("area_troughs", [])

            if rest_idx is None:
                area_arr = np.array(raw.get("area", []))
                if len(area_arr):
                    rest_idx = int(np.argmax(area_arr))
                    peak_idx = int(np.argmin(area_arr))

            cnt_rest_cv = frame_cnts[rest_idx] if frame_cnts and rest_idx is not None \
                          and rest_idx < len(frame_cnts) else None
            cnt_peak_cv = frame_cnts[peak_idx] if frame_cnts and peak_idx is not None \
                          and peak_idx < len(frame_cnts) else None

            try:
                analyzer = MechanicalMapAnalyzer(fps=fps, px_to_mm=px_to_mm,
                                                 act_threshold=float(self.act_thresh_spin.value()))
                m = analyzer.run(frames, np.ones((h, w), dtype=bool),
                                 rest_idx=rest_idx, peak_idx=peak_idx,
                                 cnt_rest_cv=cnt_rest_cv,
                                 cnt_peak_cv=cnt_peak_cv,
                                 frame_cnts_all=frame_cnts,
                                 frame_offsets=None,
                                 area_peaks=area_peaks,
                                 area_troughs=area_troughs)
                self._mech_maps_cache[roi_name] = m
            except Exception as e:
                errors.append(f"{roi_name}: {e}")
                continue

            # Update card thumbnail
            try:
                cnt_img = raw.get("contour_img")
                if cnt_img is not None:
                    card._cnt_lbl.setPixmap(card._np_to_pixmap(cnt_img, 160, 160))
            except Exception:
                pass

        if errors:
            QMessageBox.warning(self, "Some ROIs failed",
                                "\n".join(errors))

        if not self._mech_maps_cache:
            return

        # ── Update ROI selector dropdown ──────────────────────────────────
        self._map_roi_combo.blockSignals(True)
        prev = self._map_roi_combo.currentText()
        self._map_roi_combo.clear()
        for name in self._mech_maps_cache:
            self._map_roi_combo.addItem(name)
        # Restore previous selection if still present
        idx = self._map_roi_combo.findText(prev)
        self._map_roi_combo.setCurrentIndex(max(idx, 0))
        self._map_roi_combo.blockSignals(False)
        self._map_roi_row_widget.setVisible(len(self._mech_maps_cache) > 1)

        # Show overlay panel and draw result for selected ROI
        self._map_overlay_canvas.setVisible(True)
        self._update_map_overlay(self.frame_slider.value())
        self._draw_mech_map_result()

    def _draw_mech_map_result(self):
        """Draw 5-panel mechanical map figure for currently selected ROI."""
        if not hasattr(self, '_mech_maps_cache') or not self._mech_maps_cache:
            return

        roi_name = self._map_roi_combo.currentText() if self._map_roi_combo.count() else ""
        m = self._mech_maps_cache.get(roi_name)
        if m is None:
            m = next(iter(self._mech_maps_cache.values()))
            roi_name = next(iter(self._mech_maps_cache))

        px_to_mm = m.px_to_mm
        raw      = self._raw_signals.get(roi_name, {})
        frame_bgs = raw.get("frame_bgs", [])
        rest_idx  = m.rest_idx

        bg_rest = frame_bgs[rest_idx] if frame_bgs and rest_idx < len(frame_bgs) \
                  else None

        self._result_fig.clf()
        from matplotlib.colors import TwoSlopeNorm

        DARK = '#0d0d0d'; TEXT = '#e8e8e8'; ACC = '#00d4ff'
        self._result_fig.patch.set_facecolor(DARK)
        # 6 panels: Contour | A | B | C κ_rest | C' Δκ | D
        gs = self._result_fig.add_gridspec(2, 3, hspace=0.42, wspace=0.42,
                                            left=0.06, right=0.94,
                                            top=0.90, bottom=0.09)

        def _style(ax, title):
            ax.set_facecolor(DARK)
            ax.tick_params(colors=TEXT, labelsize=8)
            for sp in ax.spines.values(): sp.set_color('#333')
            ax.set_title(title, color=ACC, fontsize=9.0, pad=3)
            ax.xaxis.label.set_color(TEXT); ax.yaxis.label.set_color(TEXT)

        def _cbar(sc, ax, label):
            cb = self._result_fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.04)
            cb.set_label(label, color=TEXT, fontsize=8)
            cb.ax.yaxis.set_tick_params(colors=TEXT, labelsize=7)

        def _map2d(ax, data, cmap, norm, label, title):
            sc = ax.scatter(m.cx, m.cy, c=data, cmap=cmap, norm=norm,
                            s=8, linewidths=0)
            _cbar(sc, ax, label)
            ax.set_aspect('equal')
            ax.set_xlabel('x (mm)', fontsize=8)
            ax.set_ylabel('y (mm)', fontsize=8)
            _style(ax, title)
            return sc

        pad = 0.1
        xlim = (m.cx.min() - pad, m.cx.max() + pad)
        ylim = (m.cy.min() - pad, m.cy.max() + pad)

        def _set_extent(ax):
            ax.set_xlim(xlim); ax.set_ylim(ylim)

        # Panel 0: contour overlay
        ax0 = self._result_fig.add_subplot(gs[0])
        if bg_rest is not None:
            bg_h, bg_w = bg_rest.shape[:2]
            bg_ext = [0, bg_w * px_to_mm, bg_h * px_to_mm, 0]
            ax0.imshow(bg_rest, cmap='gray', origin='upper', aspect='equal',
                       extent=bg_ext)
        ax0.plot(m.cx, m.cy, '-', color='#ff4444', lw=1.2, label='Rest')
        ax0.plot(m.contour_peak_px[:, 0] * px_to_mm,
                 -m.contour_peak_px[:, 1] * px_to_mm,
                 '-', color='#4488ff', lw=1.2, label='Peak')
        ax0.legend(fontsize=8, facecolor='#1a1a1a', labelcolor=TEXT,
                   loc='upper right')
        _set_extent(ax0); ax0.set_axis_off()
        _style(ax0, 'Contour  red=rest  blue=peak')

        # A: Radial displacement
        ax_a = self._result_fig.add_subplot(gs[1])
        vd = max(float(np.abs(m.radial_disp).max()), 0.1)
        _map2d(ax_a, m.radial_disp, 'RdBu_r', _safe_two_slope_norm(vd),
               'Inward disp (px)\n+= contraction', 'A  Radial displacement')
        _set_extent(ax_a)

        # B: Strain
        ax_b = self._result_fig.add_subplot(gs[2])
        vs = max(float(np.abs(m.strain).max()), 0.1)
        _map2d(ax_b, m.strain, 'RdBu_r', _safe_two_slope_norm(vs),
               'Strain (%)\n−= compression', 'B  Arc-length strain')
        _set_extent(ax_b)

        # C: κ_rest — 원래 형태의 곡률 (가설 검증 핵심)
        ax_c = self._result_fig.add_subplot(gs[3])
        vkr = max(float(np.abs(m.kappa_rest).max()), 0.01)
        sc_kr = ax_c.scatter(m.cx, m.cy, c=m.kappa_rest,
                             cmap='hot', vmin=0, vmax=vkr,
                             s=8, linewidths=0)
        _cbar(sc_kr, ax_c, 'κ_rest (mm⁻¹)')
        # Mark kappa_rest peak (hypothesis test site)
        peak_kr_idx = int(np.argmax(np.abs(m.kappa_rest)))
        ax_c.scatter(m.cx[peak_kr_idx], m.cy[peak_kr_idx],
                     marker='D', color='cyan', s=80, zorder=5,
                     edgecolors='white', linewidths=0.8,
                     label='κ peak')
        ax_c.legend(fontsize=8, facecolor='#1a1a1a', labelcolor=TEXT)
        ax_c.set_aspect('equal')
        ax_c.set_xlabel('x (mm)', fontsize=8)
        ax_c.set_ylabel('y (mm)', fontsize=8)
        _set_extent(ax_c)
        _style(ax_c, 'C  κ_rest  [◆]=peak\n(geometry → pacemaking?)')

        # C': Δκ — 수축 중 곡률 변화
        ax_ck = self._result_fig.add_subplot(gs[4])
        vk = max(float(np.abs(m.delta_kappa).max()), 0.01)
        _map2d(ax_ck, m.delta_kappa, 'RdBu_r', _safe_two_slope_norm(vk),
               'Δκ (mm⁻¹)', "C'  Δκ = κ_peak − κ_rest")
        _set_extent(ax_ck)

        # D: Mechanical activation
        ax_d = self._result_fig.add_subplot(gs[5])
        if m.act_valid.any():
            act_pl = m.mech_act_ms.copy(); act_pl[~m.act_valid] = np.nan
            sc_d = ax_d.scatter(m.cx[m.act_valid], m.cy[m.act_valid],
                                c=act_pl[m.act_valid],
                                cmap='jet', s=8, vmin=0, linewidths=0)
            _cbar(sc_d, ax_d, 'Activation (ms)')
            valid_idx = np.where(m.act_valid)[0]
            ei = valid_idx[int(np.nanargmin(act_pl[m.act_valid]))]
            li = valid_idx[int(np.nanargmax(act_pl[m.act_valid]))]
            ax_d.scatter(m.cx[ei], m.cy[ei], marker='*', color='white',
                         s=180, zorder=5, label='Start',
                         edgecolors='black', linewidths=0.5)
            ax_d.scatter(m.cx[li], m.cy[li], marker='X', color='yellow',
                         s=120, zorder=5, label='End',
                         edgecolors='black', linewidths=0.5)
            ax_d.legend(fontsize=8, facecolor='#1a1a1a', labelcolor=TEXT)
            ax_d.set_aspect('equal')
            ax_d.set_xlabel('x (mm)', fontsize=8)
            ax_d.set_ylabel('y (mm)', fontsize=8)
            _set_extent(ax_d)

            # Hypothesis check: arc-length distance between κ_rest peak and activation start
            s_kappa = float(m.arc_s[peak_kr_idx])
            s_act   = float(m.arc_s[ei])
            total_L = float(m.arc_s[-1])
            diff    = abs(s_kappa - s_act)
            dist_mm = min(diff, total_L - diff)
            norm_dist = dist_mm / total_L  # 0=일치, 0.5=정반대
            ax_d.set_title(
                f'D  Mech. activation  [*]=start  [x]=end\n'
                f'|κ_peak − act_start| = {dist_mm:.2f} mm  ({norm_dist:.2f}×L)',
                color=ACC, fontsize=8.5, pad=3)
            ax_d.set_facecolor(DARK)
            for sp in ax_d.spines.values(): sp.set_color('#333')
            ax_d.tick_params(colors=TEXT, labelsize=8)
            ax_d.xaxis.label.set_color(TEXT); ax_d.yaxis.label.set_color(TEXT)
        else:
            ax_d.text(0.5, 0.5, 'No activation\ndetected',
                      ha='center', va='center', color=TEXT,
                      transform=ax_d.transAxes, fontsize=7)
            _style(ax_d, 'D  Mech. activation  [*]=start  [x]=end')

        n_cached = len(self._mech_maps_cache)
        self._result_fig.suptitle(
            f'Contour-based maps — {roi_name}  '
            f'rest={m.rest_idx} peak={m.peak_idx}  '
            f'({n_cached} ROI{"s" if n_cached > 1 else ""} computed)',
            color=TEXT, fontsize=8, y=0.97)

        self._result_canvas.draw_idle()



    # ─────────────────────────────────────────────────────────────────────────
    #  Export
    # ─────────────────────────────────────────────────────────────────────────

    # ─────────────────────────────────────────────────────────────────────────
    #  Unified Export Entry Point
    # ─────────────────────────────────────────────────────────────────────────

    def _export_all(self):
        """통합 Export:
        1) 영상 선택 다이얼로그 (큐에 여러 영상이 있을 때)
        2) Excel + CSV + PNG (summary figure 포함)
        3) ROI overlay 영상
        모두 같은 폴더에 저장.
        """
        if not self._roi_cards:
            QMessageBox.warning(self, "No data", "Extract signals first.")
            return

        # ── 1. 영상 선택 다이얼로그 ────────────────────────────────────────
        exportable_videos = [(p, self._roi_store.get(p, []))
                             for p in self._video_queue if self._roi_store.get(p)]

        selected_videos = []
        if len(self._video_queue) > 1:
            from PyQt5.QtWidgets import QDialog, QListWidget, QListWidgetItem, QDialogButtonBox, QVBoxLayout, QLabel
            dlg = QDialog(self)
            dlg.setWindowTitle("Export할 영상 선택")
            dlg.setMinimumWidth(420)
            vl = QVBoxLayout(dlg)
            vl.addWidget(QLabel("Excel/PNG/Video로 export할 영상을 선택하세요.\n(Ctrl+클릭으로 다중 선택)"))
            lst = QListWidget()
            lst.setSelectionMode(QListWidget.MultiSelection)
            for p, rois in exportable_videos:
                item = QListWidgetItem(f"{'✓' if rois else '✗'} {Path(p).name}")
                item.setData(Qt.UserRole, p)
                lst.addItem(item)
                if rois:
                    item.setSelected(True)
            vl.addWidget(lst)
            btns = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
            btns.accepted.connect(dlg.accept)
            btns.rejected.connect(dlg.reject)
            vl.addWidget(btns)
            if dlg.exec_() != QDialog.Accepted:
                return
            selected_paths = {item.data(Qt.UserRole)
                              for item in lst.selectedItems()}
            selected_videos = [(p, rois) for p, rois in exportable_videos
                               if p in selected_paths]
        else:
            selected_videos = exportable_videos

        # ── 2. 저장 폴더 선택 ──────────────────────────────────────────────
        out_dir = QFileDialog.getExistingDirectory(self, "저장 폴더 선택", "")
        if not out_dir:
            return
        out_dir = Path(out_dir)

        # ── 3. Excel + CSV + PNG (기존 _export_excel 로직) ─────────────────
        self._export_excel(out_dir=out_dir)

        # ── 4. Summary figure PNG (GUI 화면처럼 한 장에) ───────────────────
        for card in self._roi_cards:
            safe = card.get_roi_name()\
                       .replace(" / ", "_").replace("/", "_")\
                       .replace(" ", "_").replace("(", "").replace(")", "")
            try:
                self._make_summary_png(card, out_dir, safe)
            except Exception as _e:
                print(f"[PNG Export Error] {card.get_roi_name()}: {_e}")
                print(traceback.format_exc())

        # ── 5. ROI overlay 영상 export ────────────────────────────────────
        if selected_videos:
            self._video_export_queue = [
                (p, rois, str(out_dir / (Path(p).stem + "_ROI_overlay.mp4")))
                for p, rois in selected_videos
            ]
            self._video_export_idx = 0
            self._video_export_dir = str(out_dir)
            self._run_next_video_export(final_msg=True)
        else:
            QMessageBox.information(
                self, "저장 완료",
                f"폴더: {out_dir}\n\nExcel + CSV + PNG 저장 완료.\n"
                "(ROI가 저장된 영상이 없어 video export는 건너뜁니다.)")

    def _make_summary_png(self, card, out_dir: "Path", safe: str):
        """GUI 화면과 동일한 레이아웃의 summary figure PNG 저장.

        Layout:
          Row 0 (full width): Motion+Area trace (BPM/artifact 마커 포함)
          Row 1 left:  Averaged Motion & ΔArea transients (나란히)
          Row 2 left:  Max↔Min Contour
          Row 2 right: Motion Heatmap
          Row 3 (full width, 4-panel): Mechanical Maps
            A Displacement | B Strain | C Δκ | D Mechanical Activation
        """
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        import matplotlib.gridspec as gridspec
        from matplotlib.colors import TwoSlopeNorm

        raw_d = self._raw_signals.get(card.get_roi_name(), {})
        fps   = float(raw_d.get("fps", 30.0))
        px_um = self.px_um_spin.value()

        # Check if mechanical maps are cached
        mech = None
        if hasattr(self, '_mech_maps_cache'):
            mech = self._mech_maps_cache.get(card.get_roi_name())

        n_rows = 4 if mech is not None else 3
        height_ratios = [1.2, 1.4, 1.4, 1.6] if mech else [1.2, 1.4, 1.4]

        fig = plt.figure(figsize=(14, 5.5 * n_rows), facecolor="white")
        gs  = gridspec.GridSpec(n_rows, 2, figure=fig,
                                height_ratios=height_ratios,
                                hspace=0.45, wspace=0.35)

        # ── Row 0: Trace (full width) ─────────────────────────────────────
        ax_trace = fig.add_subplot(gs[0, :])
        fig_trace = card.get_trace_figure()
        if fig_trace is not None:
            import io
            buf = io.BytesIO()
            fig_trace.savefig(buf, format="png", dpi=120, bbox_inches="tight",
                              facecolor="white")
            buf.seek(0)
            try:
                import PIL.Image
                img_trace = np.array(PIL.Image.open(buf))
            except ImportError:
                buf.seek(0)
                img_trace = plt.imread(buf)
            ax_trace.imshow(img_trace)
            ax_trace.set_axis_off()
            buf.close()
        else:
            ax_trace.text(0.5, 0.5, "Trace not available",
                          ha="center", va="center", transform=ax_trace.transAxes)
            ax_trace.set_axis_off()

        # ── Row 1: Averaged transients ────────────────────────────────────
        ax_avg_m = fig.add_subplot(gs[1, 0])
        ax_avg_a = fig.add_subplot(gs[1, 1])

        avg_data = None
        try:
            amp_arr  = np.array(raw_d.get("amp",  []))
            area_arr = np.array(raw_d.get("area", []))
            if len(amp_arr) > 1:
                from scipy.signal import savgol_filter as _sgf, find_peaks as _fp
                sg = card._sg_win if card._sg_win % 2 == 1 else card._sg_win + 1
                sg = max(5, min(sg, len(amp_arr) - 1))
                c_s = _sgf(amp_arr, sg, 3)
                a_s = _sgf(area_arr, sg, 3)
                pks, _ = _fp(c_s, prominence=card._prom_spin.value(),
                             distance=card._dist_spin.value())
                if len(pks) >= 2:
                    avg_data = _build_avg_transient_df(c_s, a_s, pks, fps)
        except Exception:
            pass

        if avg_data is not None:
            _draw_motion_avg_ax(ax_avg_m, avg_data["all_motion"],
                                avg_data["t_frames"], avg_data["smooth_motion"], fps)
            if avg_data.get("all_delta") is not None:
                _draw_delta_area_avg_ax(ax_avg_a, avg_data["all_delta"],
                                        avg_data["t_frames"],
                                        avg_data["smooth_delta"], fps)
            else:
                ax_avg_a.text(0.5, 0.5, "ΔArea N/A",
                              ha="center", va="center",
                              transform=ax_avg_a.transAxes, color="gray")
                ax_avg_a.set_axis_off()
        else:
            for ax in (ax_avg_m, ax_avg_a):
                ax.text(0.5, 0.5, "Avg transient N/A",
                        ha="center", va="center",
                        transform=ax.transAxes, color="gray")
                ax.set_axis_off()

        # ── Row 2 left: Max↔Min Contour ───────────────────────────────────
        ax_cnt = fig.add_subplot(gs[2, 0])
        cnt_img = card.get_contour_img()
        if cnt_img is None:
            cnt_img = raw_d.get("contour_img")
        if cnt_img is not None:
            ax_cnt.imshow(cnt_img, aspect="equal", origin="upper")
            if px_um > 0:
                H_c, W_c = cnt_img.shape[:2]
                view_um = W_c / px_um
                target  = view_um * 0.2
                exp = np.floor(np.log10(max(target, 1e-9)))
                base_v = target / (10 ** exp)
                nice = 1 if base_v < 1.5 else (2 if base_v < 3.5 else (5 if base_v < 7.5 else 10))
                bar_um = float(nice * (10 ** exp))
                bar_px = bar_um * px_um
                margin = W_c * 0.04
                x2, x1, y = W_c - margin, W_c - margin - bar_px, H_c - margin
                ax_cnt.plot([x1, x2], [y, y], color="white", lw=3,
                            solid_capstyle="butt", zorder=5)
                ax_cnt.text((x1+x2)/2, y - H_c*0.025,
                            f"{bar_um:g} µm", ha="center", va="bottom",
                            color="white", fontsize=8, fontweight="bold", zorder=5)
            from matplotlib.lines import Line2D
            raw_area = raw_d.get("area", [])
            max_a = float(np.max(raw_area)) if len(raw_area) else None
            min_a = float(np.min(raw_area)) if len(raw_area) else None
            max_lbl = f"Max area (Relaxed){f' ({max_a:.0f} µm²)' if max_a else ''}"
            min_lbl = f"Min area (Contracted){f' ({min_a:.0f} µm²)' if min_a else ''}"
            ax_cnt.legend(handles=[
                Line2D([0],[0], color=(1,0,0), lw=2.5, label=max_lbl),
                Line2D([0],[0], color=(0,0,1), lw=2.5, label=min_lbl),
            ], loc="upper left", fontsize=7, framealpha=0.75)
        else:
            ax_cnt.text(0.5, 0.5, "Contour N/A",
                        ha="center", va="center", transform=ax_cnt.transAxes)
        ax_cnt.set_title(f"Max ↔ Min Contour — {card.get_roi_name()}",
                         fontsize=9, fontweight="bold")
        ax_cnt.set_axis_off()

        # ── Row 2 right: Motion Heatmap ───────────────────────────────────
        ax_hm = fig.add_subplot(gs[2, 1])
        hm_img = card.get_heatmap_img()
        if hm_img is None:
            hm_img = raw_d.get("heatmap")
        if hm_img is not None:
            H_h, W_h = hm_img.shape[:2]
            if px_um > 0:
                extent = [0, W_h/px_um, H_h/px_um, 0]
                ax_hm.imshow(hm_img, extent=extent, aspect="equal", origin="upper")
                ax_hm.set_xlabel("Distance (µm)", fontsize=8)
                ax_hm.set_ylabel("Distance (µm)", fontsize=8)
            else:
                ax_hm.imshow(hm_img, aspect="equal", origin="upper")
                ax_hm.set_xlabel("X (px)", fontsize=8)
                ax_hm.set_ylabel("Y (px)", fontsize=8)
            import matplotlib.colors as mcolors
            import matplotlib.cm as cm
            sm = plt.cm.ScalarMappable(
                cmap=cm.get_cmap("jet"),
                norm=mcolors.Normalize(vmin=0, vmax=1))
            sm.set_array([])
            cb = fig.colorbar(sm, ax=ax_hm, fraction=0.046, pad=0.04)
            cb.set_label("Motion Intensity (a.u.)", fontsize=8)
            cb.set_ticks([0, 0.5, 1.0])
            cb.set_ticklabels(["Low", "Medium", "High"])
        else:
            ax_hm.text(0.5, 0.5, "Heatmap N/A",
                       ha="center", va="center", transform=ax_hm.transAxes)
            ax_hm.set_axis_off()
        ax_hm.set_title(f"Motion Heatmap — {card.get_roi_name()}",
                        fontsize=9, fontweight="bold")

        # ── Row 3: 5 Mechanical Maps (only if cached) ─────────────────────
        if mech is not None:
            inner = gridspec.GridSpecFromSubplotSpec(
                1, 5, subplot_spec=gs[3, :], wspace=0.4)
            ax_A  = fig.add_subplot(inner[0])
            ax_B  = fig.add_subplot(inner[1])
            ax_C  = fig.add_subplot(inner[2])   # κ_rest
            ax_CK = fig.add_subplot(inner[3])   # Δκ
            ax_D  = fig.add_subplot(inner[4])

            DARK = '#0d0d0d'
            TEXT = '#e8e8e8'
            ACC  = '#00d4ff'

            def _mstyle(ax, title):
                ax.set_facecolor(DARK)
                ax.tick_params(colors=TEXT, labelsize=6)
                for sp in ax.spines.values():
                    sp.set_color('#444')
                ax.set_title(title, color=ACC, fontsize=8, pad=4)
                ax.xaxis.label.set_color(TEXT)
                ax.yaxis.label.set_color(TEXT)

            def _mcbar(im_or_sc, ax, label):
                cb = fig.colorbar(im_or_sc, ax=ax, fraction=0.046, pad=0.04)
                cb.set_label(label, color=TEXT, fontsize=6)
                cb.ax.yaxis.set_tick_params(colors=TEXT, labelsize=5)

            # ── Contour-based maps (1-D arc-length parameterised) ─────────
            pad_c = 0.1
            xlim_c = (mech.cx.min() - pad_c, mech.cx.max() + pad_c)
            ylim_c = (mech.cy.min() - pad_c, mech.cy.max() + pad_c)

            def _set_cnt_extent(ax):
                ax.set_xlim(xlim_c); ax.set_ylim(ylim_c)
                ax.set_aspect('equal')
                ax.set_xlabel('x (mm)', fontsize=6)
                ax.set_ylabel('y (mm)', fontsize=6)

            # A: Radial displacement
            vd = max(float(np.abs(mech.radial_disp).max()), 0.1)
            sc_a = ax_A.scatter(mech.cx, mech.cy, c=mech.radial_disp,
                                cmap='RdBu_r', norm=_safe_two_slope_norm(vd),
                                s=10, linewidths=0)
            _set_cnt_extent(ax_A)
            _mcbar(sc_a, ax_A, 'Inward disp (px)\n+= contraction')
            _mstyle(ax_A, 'A  Radial displacement')

            # B: Arc-length strain
            vs = max(float(np.abs(mech.strain).max()), 0.1)
            sc_b = ax_B.scatter(mech.cx, mech.cy, c=mech.strain,
                                cmap='RdBu_r', norm=_safe_two_slope_norm(vs),
                                s=10, linewidths=0)
            _set_cnt_extent(ax_B)
            _mcbar(sc_b, ax_B, 'Strain (%)\n−= compression')
            _mstyle(ax_B, 'B  Arc-length strain')

            # C: κ_rest — 원래 형태 곡률 (가설 검증 핵심)
            vkr = max(float(np.abs(mech.kappa_rest).max()), 0.01)
            sc_c = ax_C.scatter(mech.cx, mech.cy, c=mech.kappa_rest,
                                cmap='hot', vmin=0, vmax=vkr,
                                s=10, linewidths=0)
            _set_cnt_extent(ax_C)
            _mcbar(sc_c, ax_C, 'κ_rest (mm⁻¹)')
            peak_kr_idx = int(np.argmax(np.abs(mech.kappa_rest)))
            ax_C.scatter(mech.cx[peak_kr_idx], mech.cy[peak_kr_idx],
                         marker='D', color='cyan', s=80, zorder=5,
                         edgecolors='white', linewidths=0.8, label='κ peak')
            ax_C.legend(fontsize=6, facecolor='#1a1a1a', labelcolor=TEXT)
            ax_C.set_aspect('equal')
            _mstyle(ax_C, 'C  κ_rest  [◆]=peak\n(geometry → pacemaking?)')

            # C': Δκ
            vk = max(float(np.abs(mech.delta_kappa).max()), 0.01)
            sc_ck = ax_CK.scatter(mech.cx, mech.cy, c=mech.delta_kappa,
                                  cmap='RdBu_r', norm=_safe_two_slope_norm(vk),
                                  s=10, linewidths=0)
            _set_cnt_extent(ax_CK)
            _mcbar(sc_ck, ax_CK, 'Δκ (mm⁻¹)')
            _mstyle(ax_CK, "C'  Δκ = κ_peak − κ_rest")

            # D: Mechanical activation
            if mech.act_valid.any():
                act_pl = mech.mech_act_ms.copy()
                act_pl[~mech.act_valid] = np.nan
                sc_d = ax_D.scatter(mech.cx[mech.act_valid],
                                    mech.cy[mech.act_valid],
                                    c=act_pl[mech.act_valid],
                                    cmap='jet', s=10, vmin=0, linewidths=0)
                _mcbar(sc_d, ax_D, 'Activation (ms)')
                valid_idx = np.where(mech.act_valid)[0]
                ei = valid_idx[int(np.nanargmin(act_pl[mech.act_valid]))]
                li = valid_idx[int(np.nanargmax(act_pl[mech.act_valid]))]
                ax_D.scatter(mech.cx[ei], mech.cy[ei], marker='*',
                             color='white', s=180, zorder=5, label='Start',
                             edgecolors='black', linewidths=0.5)
                ax_D.scatter(mech.cx[li], mech.cy[li], marker='X',
                             color='yellow', s=120, zorder=5, label='End',
                             edgecolors='black', linewidths=0.5)
                ax_D.legend(fontsize=6, facecolor='#1a1a1a', labelcolor=TEXT)
                # Hypothesis distance annotation
                s_kappa = float(mech.arc_s[peak_kr_idx])
                s_act   = float(mech.arc_s[ei])
                total_L = float(mech.arc_s[-1])
                diff    = abs(s_kappa - s_act)
                dist_mm = min(diff, total_L - diff)
                norm_dist = dist_mm / total_L
                ax_D.set_title(
                    f'D  Mech. activation\n'
                    f'|κ_peak−act_start|={dist_mm:.2f}mm ({norm_dist:.2f}×L)',
                    color=ACC, fontsize=6, pad=3)
                ax_D.set_facecolor(DARK)
                for sp in ax_D.spines.values(): sp.set_color('#444')
                ax_D.tick_params(colors=TEXT, labelsize=6)
            else:
                ax_D.text(0.5, 0.5, 'No activation\ndetected',
                          ha='center', va='center', color=TEXT,
                          transform=ax_D.transAxes, fontsize=8)
                _mstyle(ax_D, 'D  Mechanical Activation  [*]=start  [x]=end')
            _set_cnt_extent(ax_D)
            ax_D.set_aspect('equal')

            # Row 3 background
            for ax in [ax_A, ax_B, ax_C, ax_CK, ax_D]:
                ax.set_facecolor(DARK)

        # ── 저장 ──────────────────────────────────────────────────────────
        fig.suptitle(f"{card.get_roi_name()} — Contractility Analysis Summary",
                     fontsize=13, fontweight="bold", y=0.995)
        fig.savefig(str(out_dir / f"{safe}_summary.png"),
                    dpi=200, bbox_inches="tight",
                    facecolor="white", edgecolor="none")
        plt.close(fig)

    def _export_roi_video(self):
        """큐에 있는 모든 영상에 대해 ROI 오버레이 영상을 순차 export."""
        if not self._video_queue:
            QMessageBox.warning(self, "No videos", "Add videos to the queue first.")
            return

        # ROI가 저장된 영상만 추출
        exportable = [(p, self._roi_store.get(p, []))
                      for p in self._video_queue if self._roi_store.get(p)]
        if not exportable:
            QMessageBox.warning(self, "No ROIs",
                                "Detect ROIs first before exporting videos.")
            return

        # 저장 폴더 선택 (파일명은 자동 생성)
        out_dir = QFileDialog.getExistingDirectory(
            self, "ROI 영상 저장 폴더 선택", "")
        if not out_dir:
            return

        from pathlib import Path
        self._video_export_queue = [
            (p, rois, str(Path(out_dir) / (Path(p).stem + "_ROI_overlay.mp4")))
            for p, rois in exportable
        ]
        self._video_export_idx = 0
        self._video_export_dir = out_dir
        self._run_next_video_export()

    def _run_next_video_export(self, final_msg=False):
        """큐의 다음 영상 export 실행."""
        if self._video_export_idx >= len(self._video_export_queue):
            n = len(self._video_export_queue)
            if final_msg:
                QMessageBox.information(
                    self, "Export 완료",
                    f"폴더: {self._video_export_dir}\n\n"
                    "■ contractility_results.xlsx  (Summary / 시트별 데이터)\n"
                    "■ <ROI>_summary.png           (분석 결과 종합 그림)\n"
                    "■ <ROI>_timeseries.csv / beat_stats.csv / average_trace*.csv\n"
                    "■ <ROI>_trace.png / heatmap.png / contour.png\n"
                    f"■ {n}개 ROI overlay 영상 (_ROI_overlay.mp4)\n\n"
                    "모든 파일이 저장됐습니다.")
            else:
                QMessageBox.information(
                    self, "Export 완료",
                    f"총 {n}개 영상 저장 완료:\n{self._video_export_dir}")
            return

        path, rois, out_path = self._video_export_queue[self._video_export_idx]
        n_total = len(self._video_export_queue)
        n_cur   = self._video_export_idx + 1

        self._video_prog = QProgressDialog(
            f"[{n_cur}/{n_total}]  {Path(path).name} 내보내는 중…",
            None, 0, 100, self)
        self._video_prog.setWindowModality(Qt.WindowModal)
        self._video_prog.show()

        # 이 영상의 저장된 px_per_um 사용
        ep = self._extract_params_store.get(path, {})
        px_per_um = ep.get("px_per_um", self.px_um_spin.value())
        thr = self._thresh_store.get(path, self.thresh_slider.value())

        self._stop_worker(self._video_export_worker)
        self._video_export_worker = VideoExportWorker(
            path, rois, out_path,
            threshold          = thr,
            px_per_um          = px_per_um,
            draw_scale_bar_flag = True,
            draw_roi_overlay   = True,
        )
        self._video_export_worker.progress.connect(self._video_prog.setValue)
        self._video_export_worker.finished.connect(self._on_video_exported)
        self._video_export_worker.error.connect(
            lambda e, _p=path: self._on_video_export_error(e, _p))
        self._video_export_worker.start()

    def _on_video_exported(self, out_path: str):
        self._video_prog.close()
        self._video_export_idx += 1
        self._run_next_video_export()

    def _on_video_export_error(self, msg: str, path: str):
        self._video_prog.close()
        from pathlib import Path
        QMessageBox.warning(self, "Export 오류",
            f"{Path(path).name}: {msg}\n\n다음 영상으로 계속합니다.")
        self._video_export_idx += 1
        self._run_next_video_export()

    def _export_excel(self, out_dir=None):
        if not self._roi_cards:
            QMessageBox.warning(self, "No data", "Extract signals first.")
            return

        if out_dir is None:
            out_dir = QFileDialog.getExistingDirectory(
                self, "저장 폴더 선택", "")
            if not out_dir:
                return
            out_dir = Path(out_dir)
            show_msg = True
        else:
            show_msg = False  # _export_all에서 호출 시 메시지 생략

        from pathlib import Path
        import pandas as pd
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment

        out_dir = Path(out_dir)

        def _hdr(ws, names):
            fill = PatternFill("solid", fgColor="1F3864")
            font = Font(bold=True, color="FFFFFF", name="Arial")
            for ci, nm in enumerate(names, 1):
                c = ws.cell(1, ci, nm)
                c.fill = fill; c.font = font
                c.alignment = Alignment(horizontal="center")

        def _subhdr(ws, names, row, col_start, color="BDD7EE"):
            fill = PatternFill("solid", fgColor=color)
            font = Font(bold=True, name="Arial")
            for ci, nm in enumerate(names, col_start):
                c = ws.cell(row, ci, nm)
                c.fill = fill; c.font = font
                c.alignment = Alignment(horizontal="center")

        try:
            from openpyxl.styles import Border, Side
            from openpyxl.utils import get_column_letter

            # ── 스타일 헬퍼 ──────────────────────────────────────────────
            thin = Side(style="thin", color="CCCCCC")
            def _border():
                return Border(left=thin, right=thin, top=thin, bottom=thin)

            def _write_df(ws, df, start_row=1, start_col=1,
                          hdr_color="1F3864", hdr_txt="FFFFFF",
                          mean_rows=None):
                """DataFrame을 ws에 쓰기. mean_rows: MEAN/SD/n 행 인덱스 집합"""
                hdr_fill = PatternFill("solid", fgColor=hdr_color)
                hdr_font = Font(bold=True, color=hdr_txt, name="Arial", size=9)
                data_font = Font(name="Arial", size=9)
                mean_fill = PatternFill("solid", fgColor="D9E1F2")
                sd_fill   = PatternFill("solid", fgColor="EEF2F9")
                n_fill    = PatternFill("solid", fgColor="F5F7FC")
                mean_font = Font(bold=True, name="Arial", size=9)
                aln_c = Alignment(horizontal="center", vertical="center")

                # 헤더
                for ci, col in enumerate(df.columns, start_col):
                    c = ws.cell(start_row, ci, col)
                    c.font = hdr_font; c.fill = hdr_fill
                    c.alignment = Alignment(horizontal="center", vertical="center",
                                            wrap_text=True)
                    c.border = _border()

                # 데이터
                for ri, row in enumerate(df.itertuples(index=False), start_row + 1):
                    label = str(row[0]) if len(row) > 0 else ""
                    is_mean = label == "MEAN"
                    is_sd   = label == "SD"
                    is_n    = label == "n"
                    row_fill = (mean_fill if is_mean else
                                sd_fill   if is_sd   else
                                n_fill    if is_n    else None)
                    row_font = mean_font if (is_mean or is_sd or is_n) else data_font
                    for ci, v in enumerate(row, start_col):
                        c = ws.cell(ri, ci, v)
                        c.font = row_font
                        if row_fill:
                            c.fill = row_fill
                        c.alignment = aln_c
                        c.border = _border()

            wb = openpyxl.Workbook()

            # ══════════════════════════════════════════════════════════════
            # ROI별 시트 묶음 (각 ROI마다 4개 시트)
            # ══════════════════════════════════════════════════════════════
            for card in self._roi_cards:
                safe = card.get_roi_name()\
                           .replace(" / ", "_")\
                           .replace("/", "_")\
                           .replace(" ", "_")\
                           .replace("(", "").replace(")", "")
                raw = self._raw_signals.get(card.get_roi_name(), {})
                fps = float(raw.get("fps", 30.0))
                roi_short = card.get_roi_name().replace(" / ", "/")

                # ── 시트 A: Timeseries ────────────────────────────────────
                ws_ts = wb.create_sheet(f"{safe[:20]}_Timeseries")
                # 타이틀
                ws_ts.cell(1, 1, f"{roi_short} — Time Series (raw & smoothed)")
                ws_ts.cell(1, 1).font = Font(bold=True, name="Arial", size=10,
                                              color="1F3864")
                ws_ts.merge_cells(start_row=1, start_column=1,
                                  end_row=1, end_column=5)

                amp_l  = raw.get("amp",  [])
                area_l = raw.get("area", [])
                ml = min(len(amp_l), len(area_l))
                if ml > 0:
                    t_s2, cont_s2, area_s2 = card.get_smoothed_traces()
                    df_ts = {
                        "Time (sec)":            np.arange(ml) / fps,
                        "Motion_raw (a.u.)":      amp_l[:ml],
                        "Area_raw (µm²)":         area_l[:ml],
                    }
                    if cont_s2 is not None and area_s2 is not None:
                        ms = min(ml, len(cont_s2), len(area_s2))
                        df_ts["Motion_smoothed (a.u.)"] = list(cont_s2[:ms]) + [np.nan]*(ml-ms)
                        df_ts["Area_smoothed (µm²)"]    = list(area_s2[:ms]) + [np.nan]*(ml-ms)
                    _write_df(ws_ts, pd.DataFrame(df_ts),
                              start_row=2, hdr_color="2E75B6")

                # ── 시트 B: Beat-to-Beat ──────────────────────────────────
                ws_bb = wb.create_sheet(f"{safe[:20]}_BeatToBeat")
                ws_bb.cell(1, 1, f"{roi_short} — Beat-to-Beat Statistics")
                ws_bb.cell(1, 1).font = Font(bold=True, name="Arial", size=10,
                                              color="1F3864")
                ws_bb.merge_cells(start_row=1, start_column=1,
                                  end_row=1, end_column=12)
                df_b = card.get_beat_stats()
                if df_b is not None and not df_b.empty:
                    _write_df(ws_bb, df_b, start_row=2, hdr_color="375623",
                              hdr_txt="FFFFFF")

                # ── 시트 C: Avg Transients (절대값) ──────────────────────
                ws_avg = wb.create_sheet(f"{safe[:20]}_AvgTrace")
                ws_avg.cell(1, 1, f"{roi_short} — Averaged Transients (Absolute)")
                ws_avg.cell(1, 1).font = Font(bold=True, name="Arial", size=10,
                                               color="1F3864")
                ws_avg.merge_cells(start_row=1, start_column=1,
                                   end_row=1, end_column=6)
                df_a = card.get_avg_stats()
                if df_a is not None and not df_a.empty:
                    _write_df(ws_avg, df_a, start_row=2, hdr_color="7030A0",
                              hdr_txt="FFFFFF")

                # ── 시트 D: ΔArea Avg Transients ─────────────────────────
                ws_da = wb.create_sheet(f"{safe[:20]}_DeltaArea")
                ws_da.cell(1, 1, f"{roi_short} — Averaged ΔArea Transients (Baseline-subtracted)")
                ws_da.cell(1, 1).font = Font(bold=True, name="Arial", size=10,
                                              color="1F3864")
                ws_da.merge_cells(start_row=1, start_column=1,
                                  end_row=1, end_column=6)
                df_delta = card.get_avg_delta_stats()
                if df_delta is not None and not df_delta.empty:
                    _write_df(ws_da, df_delta, start_row=2, hdr_color="843C0C",
                              hdr_txt="FFFFFF")

            # ══════════════════════════════════════════════════════════════
            # 전체 요약 시트 (기존 contractility_results 구조 유지)
            # ══════════════════════════════════════════════════════════════

            # ── Sheet: Summary ────────────────────────────────────────────
            ws_sum = wb.create_sheet("Summary")
            all_keys = ["ROI"] + list(self._roi_cards[0].get_features().keys())
            _hdr(ws_sum, all_keys)
            for r, card in enumerate(self._roi_cards, 2):
                ws_sum.cell(r, 1, card.get_roi_name())
                for ci, v in enumerate(card.get_features().values(), 2):
                    ws_sum.cell(r, ci, v)

            # ── Sheet: Beat-to-Beat (all ROIs side by side) ───────────────
            ws_bb_all = wb.create_sheet("Beat-to-Beat (All)")
            col_off = 1
            for card in self._roi_cards:
                df_b = card.get_beat_stats()
                if df_b is None or df_b.empty:
                    continue
                cols = list(df_b.columns)
                c = ws_bb_all.cell(1, col_off, card.get_roi_name())
                c.font = Font(bold=True, color="FFFFFF", name="Arial")
                c.fill = PatternFill("solid", fgColor="1F3864")
                _subhdr(ws_bb_all, cols, 2, col_off, "BDD7EE")
                for ri, row in enumerate(df_b.itertuples(index=False), 3):
                    for ci, v in enumerate(row, col_off):
                        ws_bb_all.cell(ri, ci, v)
                col_off += len(cols) + 1

            # ── Sheet: Avg Transients (all ROIs side by side) ─────────────
            ws_avg_all = wb.create_sheet("Avg Transients (All)")
            col_off = 1
            for card in self._roi_cards:
                df_a = card.get_avg_stats()
                if df_a is None or df_a.empty:
                    continue
                cols = list(df_a.columns)
                c = ws_avg_all.cell(1, col_off, card.get_roi_name())
                c.font = Font(bold=True, color="FFFFFF", name="Arial")
                c.fill = PatternFill("solid", fgColor="1F3864")
                _subhdr(ws_avg_all, cols, 2, col_off, "E2EFDA")
                for ri, row in enumerate(df_a.itertuples(index=False), 3):
                    for ci, v in enumerate(row, col_off):
                        ws_avg_all.cell(ri, ci, v)
                col_off += len(cols) + 1

            # ── Sheet: Mechanical Maps summary (if computed) ──────────────
            mech_cache = getattr(self, '_mech_maps_cache', {})
            if mech_cache:
                ws_mech = wb.create_sheet("Mechanical Maps")
                ws_mech.cell(1, 1, "Mechanical Activation Map Summary")
                ws_mech.cell(1, 1).font = Font(bold=True, name="Arial",
                                                size=11, color="1F3864")
                ws_mech.merge_cells(start_row=1, start_column=1,
                                    end_row=1, end_column=8)

                hdr_names = ["ROI", "Rest frame", "Peak frame",
                             "Max displacement (px)",
                             "Peak strain (ε_vol)",
                             "Max |Δκ| (mm⁻¹)",
                             "Mech activation range (ms)",
                             "Earliest activation site (x mm, y mm)"]
                _subhdr(ws_mech, hdr_names, 2, 1, "1F3864")
                for ci in range(1, len(hdr_names)+1):
                    ws_mech.cell(2, ci).font = Font(
                        bold=True, color="FFFFFF", name="Arial", size=9)

                for ri, (roi_name, m) in enumerate(mech_cache.items(), 3):
                    if m.act_valid.any():
                        act_vals = m.mech_act_ms[m.act_valid]
                        act_range_ms = round(float(act_vals.max() - act_vals.min()), 2)
                        ei = np.where(m.act_valid)[0][int(np.argmin(act_vals))]
                        ex_str = f"{m.cx[ei]:.2f}, {m.cy[ei]:.2f}"
                    else:
                        act_range_ms = float('nan')
                        ex_str = "N/A"

                    row_vals = [
                        roi_name,
                        m.rest_idx,
                        m.peak_idx,
                        round(float(np.abs(m.radial_disp).max()), 3),
                        round(float(np.abs(m.strain).max()), 3),
                        round(float(np.abs(m.delta_kappa).max()), 3),
                        act_range_ms,
                        ex_str,
                    ]
                    for ci, v in enumerate(row_vals, 1):
                        c = ws_mech.cell(ri, ci, v)
                        c.font = Font(name="Arial", size=9)
                        c.border = _border()
                        c.alignment = Alignment(horizontal="center",
                                                vertical="center")

            # ── 첫 번째 빈 시트 제거 / Summary 맨 앞으로 ─────────────────
            if "Sheet" in wb.sheetnames:
                del wb["Sheet"]
            wb.move_sheet("Summary", offset=-len(wb.sheetnames))

            wb.save(str(out_dir / "contractility_results.xlsx"))

            if show_msg:
                QMessageBox.information(
                    self, "저장 완료",
                    f"폴더: {out_dir}\n\n"
                    "■ contractility_results.xlsx\n"
                    "   시트: Summary | Beat-to-Beat | Avg Transients\n"
                    "         ROI별 Timeseries / BeatToBeat / AvgTrace / DeltaArea\n"
                    + ("   + Mechanical Maps\n"
                       if mech_cache else "") +
                    "\n■ <ROI>_summary.png  (trace + heatmap + contour"
                    + (" + 4 mechanical maps" if mech_cache else "") + ")")

        except Exception as e:
            print(f"[Export Error] {traceback.format_exc()}")
            QMessageBox.critical(self, "Export 오류",
                                 f"{e}\n\n터미널에서 상세 오류를 확인하세요.")
    # ─────────────────────────────────────────────────────────────────────────
    #  Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _show_in_preview(self, rgb: np.ndarray, caption: str = ""):
        arr = np.ascontiguousarray(rgb)
        qi  = QImage(arr.data, arr.shape[1], arr.shape[0],
                      arr.strides[0], QImage.Format_RGB888)
        pm  = QPixmap.fromImage(qi)
        # Scale to fit the label while keeping aspect ratio
        lw = max(self.roi_preview_lbl.width(), 600)
        lh = max(self.roi_preview_lbl.height(), 220)
        pm = pm.scaled(lw, lh, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        self.roi_preview_lbl.setPixmap(pm)
        self.roi_preview_lbl.setText("")
        self.roi_preview_lbl.setToolTip(caption)
