"""
core/export.py
Excel + publication image export — ported from iCAMAnalyzer.m export methods
"""

import numpy as np
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment
from pathlib import Path
from typing import Optional
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.colors as mcolors

from .signal_processing import KineticsResult, safe_sg
from .activation_mapping import ActivationResult, prepare_hires_map


# ─────────────────────────────────────────────
#  Excel export
# ─────────────────────────────────────────────

def export_excel(path: str,
                 result: KineticsResult,
                 act_result: Optional[ActivationResult] = None) -> None:
    wb = openpyxl.Workbook()

    # ── Sheet 1: Summary ────────────────────────
    ws1 = wb.active
    ws1.title = "Summary (Beat Avg)"
    _header(ws1, ["Parameter", "Value"])

    rows = [
        ("BPM",                          result.bpm),
        ("Amp (dF/F0) — Mean",           result.amp_mean),
        ("Amp (dF/F0) — SD",             result.amp_sd),
        ("TTP (ms) — Mean",              result.ttp_mean),
        ("TTP (ms) — SD",                result.ttp_sd),
        ("CTD60 (ms) — Mean",            result.ctd60_mean),
        ("CTD60 (ms) — SD",              result.ctd60_sd),
        ("CTD90 (ms) — Mean",            result.ctd90_mean),
        ("CTD90 (ms) — SD",              result.ctd90_sd),
        ("Tau (ms) — Ensemble only",     result.tau_ms),
        ("Vmax (dF/F0/s)",               result.vmax),
        ("Vrelax (dF/F0/s)",             result.vrelax),
        ("Vmax/Amp (s^-1)",              result.vmax_norm),
        ("Vrelax/Amp (s^-1)",            result.vrelax_norm),
        ("TTP/CTD90 Ratio",              result.ttp_ctd90_ratio),
        ("Valid beats (n)",              result.n_beats),
    ]
    if act_result is not None:
        rows.append(("CV (mm/s)",        act_result.cv_mm_s))
        rows.append(("Max Delay (ms)",   act_result.max_delay_ms))

    for r, (name, val) in enumerate(rows, start=2):
        ws1.cell(r, 1, name)
        ws1.cell(r, 2, round(float(val), 4) if (val is not None and not np.isnan(float(val))) else "N/A")

    ws1.column_dimensions["A"].width = 32
    ws1.column_dimensions["B"].width = 14

    # ── Sheet 2: Beat-to-beat ───────────────────
    ws2 = wb.create_sheet("Beat-to-Beat")
    headers = ["Beat", "IBI (ms)", "Amp (dF/F0)", "TTP (ms)",
               "CTD60 (ms)", "CTD90 (ms)", "Tau (ms)", "EAD", "EAD timing (ms)"]
    _header(ws2, headers)
    for r, b in enumerate(result.beat_to_beat, start=2):
        row = [b.beat, _fmt(b.ibi_ms), _fmt(b.amp), _fmt(b.ttp_ms),
               _fmt(b.ctd60_ms), _fmt(b.ctd90_ms), _fmt(b.tau_ms),
               int(b.ead_detected), _fmt(b.ead_timing_ms)]
        for c, v in enumerate(row, start=1):
            ws2.cell(r, c, v)
    for i, w in enumerate([8, 12, 14, 12, 12, 12, 12, 8, 16], start=1):
        ws2.column_dimensions[openpyxl.utils.get_column_letter(i)].width = w

    # ── Sheet 3: Avg transient ──────────────────
    if len(result.avg_time) > 0:
        ws3 = wb.create_sheet("Avg Transient")
        _header(ws3, ["Time (s)", "Mean dF/F0"])
        for r, (t, y) in enumerate(zip(result.avg_time, result.avg_signal), start=2):
            ws3.cell(r, 1, round(float(t), 6))
            ws3.cell(r, 2, round(float(y), 6))

    # ── Sheet 4: Individual transients ──────────
    if result.all_transients.size > 0:
        ws4 = wb.create_sheet("Individual Transients")
        n_beats = result.all_transients.shape[0]
        headers4 = ["Time (s)"] + [f"Beat_{i+1}" for i in range(n_beats)]
        _header(ws4, headers4)
        for r, t in enumerate(result.avg_time, start=2):
            ws4.cell(r, 1, round(float(t), 6))
            for c, beat_row in enumerate(result.all_transients, start=2):
                if r - 2 < len(beat_row):
                    ws4.cell(r, c, round(float(beat_row[r - 2]), 6))

    wb.save(path)


def _fmt(v) -> object:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "N/A"
    return round(float(v), 4)


def _header(ws, names: list):
    fill = PatternFill("solid", fgColor="1F3864")
    font = Font(bold=True, color="FFFFFF")
    for c, name in enumerate(names, start=1):
        cell = ws.cell(1, c, name)
        cell.fill = fill
        cell.font = font
        cell.alignment = Alignment(horizontal="center")


# ─────────────────────────────────────────────
#  Publication image export
# ─────────────────────────────────────────────

CUSTOM_CMAP = mcolors.LinearSegmentedColormap.from_list(
    "icam",
    [np.array(c) / 255 for c in [
        (90,  25, 140),
        (25,  65, 180),
        (128, 128, 140),
        (40,  165, 90),
        (240, 230, 40),
        (230,  25,  25),
    ]]
)


def export_whole_trace(path: str,
                       time_vec: np.ndarray,
                       dff_smooth: np.ndarray,
                       fps: float) -> None:
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(time_vec, dff_smooth, color="#1B6EC2", linewidth=1.5)
    ax.axhline(0, linestyle="--", color="#888888", linewidth=0.8)
    ax.set_xlim(0, 10)
    valid = (time_vec >= 0) & (time_vec <= 10)
    if valid.any():
        ax.set_ylim(0, dff_smooth[valid].max() * 1.2)
    ax.set_xlabel("Time (s)", fontsize=12, fontweight="bold")
    ax.set_ylabel("ΔF/F₀", fontsize=12, fontweight="bold")
    ax.set_title("Normalized Calcium Signal", fontsize=13, fontweight="bold")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def export_avg_transient(path: str, result: KineticsResult) -> None:
    t    = result.avg_time
    y    = safe_sg(result.avg_signal, 3, 31)
    fig, ax = plt.subplots(figsize=(5, 5))
    ax.plot(t, y, "k", linewidth=2.5)
    ax.axis("off")

    # scale bar
    x_lim = ax.get_xlim()
    y_lim = ax.get_ylim()
    x_range = x_lim[1] - x_lim[0]
    y_range = y_lim[1] - y_lim[0]
    sb_x = x_lim[0] + x_range * 0.05
    sb_y = y_lim[0] - y_range * 0.2

    ax.plot([sb_x, sb_x + 0.2], [sb_y, sb_y], "k", linewidth=2.5)
    ax.text(sb_x + 0.1, sb_y - y_range * 0.08, "200 ms",
            fontweight="bold", fontsize=11, ha="center", va="top")

    bar_height = 0.05
    ax.plot([sb_x, sb_x], [sb_y, sb_y + bar_height], "k", linewidth=2.5)
    ax.text(sb_x - x_range * 0.05, sb_y + bar_height / 2, "0.05 ΔF/F₀",
            rotation=90, fontweight="bold", fontsize=11, ha="right", va="center")

    ax.set_title("Averaged Transient Trace", fontsize=13, fontweight="bold")
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


def export_activation_map(path: str,
                           act_result: ActivationResult,
                           show_vectors: bool = False) -> None:
    hires_ms, X_mm, Y_mm, mask_hr = prepare_hires_map(
        act_result.act_map, act_result.mask, act_result.px_to_mm
    )

    fig, ax = plt.subplots(figsize=(7, 5.5))
    im = ax.imshow(
        np.where(mask_hr, hires_ms, np.nan),
        extent=[X_mm[0], X_mm[-1], Y_mm[-1], Y_mm[0]],
        cmap=CUSTOM_CMAP, origin="upper", aspect="equal"
    )
    cb = fig.colorbar(im, ax=ax)
    cb.set_label("Activation Delay (ms)", fontweight="bold", fontsize=12)

    if show_vectors:
        H, W = act_result.act_map.shape
        from .activation_mapping import _fill_missing
        filled = _fill_missing(act_result.act_map)
        from scipy.ndimage import gaussian_filter
        smoothed = gaussian_filter(filled, sigma=2.0)
        py, px_g = np.gradient(smoothed)
        mag = np.sqrt(px_g**2 + py**2) + 1e-9
        u = px_g / mag
        v = py / mag
        u[~act_result.mask] = np.nan
        v[~act_result.mask] = np.nan
        step = 8
        ys = np.arange(0, H, step)
        xs = np.arange(0, W, step)
        Xs, Ys = np.meshgrid(xs, ys)
        ax.quiver(
            Xs * act_result.px_to_mm, Ys * act_result.px_to_mm,
            u[::step, ::step], -v[::step, ::step],
            color="white", scale=30, width=0.003
        )

    ax.set_xlabel("Distance (mm)", fontweight="bold", fontsize=12)
    ax.set_ylabel("Distance (mm)", fontweight="bold", fontsize=12)
    ax.set_title(
        f"Activation Map  |  Max delay: {act_result.max_delay_ms:.1f} ms"
        f"  |  CV: {act_result.cv_mm_s:.2f} mm/s",
        fontsize=13, fontweight="bold"
    )
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)
