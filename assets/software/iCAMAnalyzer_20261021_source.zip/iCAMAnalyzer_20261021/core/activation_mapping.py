"""
core/activation_mapping.py
Activation map + Bayly CV  —  iCAMAnalyzer Python v3

Changes vs v2:
  ① Two-pass adaptive Bayly window
     Pass-1: fixed window=3 → rough CV
     Pass-2: optimal window from inter-pixel SNR → final CV
  ② IQR-based outlier removal before median CV
  ③ ActivationResult carries window_radius_used + cv_rough for diagnostics
"""

import numpy as np
from scipy.ndimage import (gaussian_filter, binary_fill_holes,
                           binary_dilation, label as ndlabel)
from typing import Optional
from dataclasses import dataclass, field

from .signal_processing import safe_sg


# ─────────────────────────────────────────────
#  Data container
# ─────────────────────────────────────────────

@dataclass
class ActivationResult:
    act_map:       np.ndarray   # relative delay map (s), NaN outside mask
    cv_mm_s:       float        # final median CV (mm/s)
    max_delay_ms:  float        # max delay (ms)
    dt_dx:         np.ndarray   # gradient x component
    dt_dy:         np.ndarray   # gradient y component
    mask:          np.ndarray   # boolean organoid mask
    px_to_mm:      float        # mm/px used
    # ── new diagnostic fields ──
    cv_rough:      float = np.nan   # Pass-1 CV estimate
    window_radius: int   = 3        # window radius actually used in Pass-2
    cv_iqr_lo:     float = np.nan   # IQR lower fence (mm/s)
    cv_iqr_hi:     float = np.nan   # IQR upper fence (mm/s)


# ─────────────────────────────────────────────
#  Mask building
# ─────────────────────────────────────────────

def _disk_struct(r: int) -> np.ndarray:
    y, x = np.ogrid[-r:r + 1, -r:r + 1]
    return (x**2 + y**2) <= r**2


def build_organoid_mask(roi_data: np.ndarray,
                        roi_shape_mask: np.ndarray) -> np.ndarray:
    activity = np.std(roi_data.astype(float), axis=2)
    norm = (activity - activity.min()) / (activity.max() - activity.min() + 1e-9)
    activity_smooth = gaussian_filter(norm, sigma=1.0)

    from skimage.filters import threshold_otsu
    level = threshold_otsu(activity_smooth) * 0.35
    bw = binary_fill_holes(activity_smooth > level)

    labeled, n = ndlabel(bw)
    if n > 0:
        sizes = [(labeled == i).sum() for i in range(1, n + 1)]
        bw = labeled == (np.argmax(sizes) + 1)

    bw = bw & roi_shape_mask.astype(bool)
    bw = binary_dilation(bw, structure=_disk_struct(3))
    return bw


# ─────────────────────────────────────────────
#  Adaptive window selector  (Two-pass core)
# ─────────────────────────────────────────────

def _optimal_window_radius(cv_rough_mm_s: float,
                           fps: float,
                           px_to_mm: float) -> int:
    """
    Compute the optimal Bayly window radius from a rough CV estimate.

    Logic
    -----
    inter-pixel delay  = px_to_mm / cv_rough        (seconds)
    one frame duration = 1 / fps                     (seconds)
    SNR ratio          = inter_pixel_delay / frame_time

    When SNR ratio < 1, adjacent pixels differ by less than one frame →
    gradient noise dominates.  We widen the window to average over more
    pixels, gaining spatial SNR at the cost of spatial resolution.

    Window radius chosen so that the window diameter covers at least
    2 / SNR_ratio pixels (i.e. spans at least 2 gradient "wavelengths").
    Clamped to [2, 6] (5×5 – 13×13) to stay practical.
    """
    if cv_rough_mm_s <= 0 or np.isnan(cv_rough_mm_s):
        return 3   # fallback

    inter_px_delay = px_to_mm / cv_rough_mm_s   # seconds per pixel
    frame_time     = 1.0 / fps                   # seconds per frame
    snr_ratio      = inter_px_delay / frame_time

    # Ideal radius: cover enough pixels so gradient is well-conditioned
    # SNR ratio > 1 → inter-pixel delay > 1 frame → low CV → gradient is
    # well-resolved even with a small window.
    # SNR ratio < 1 → high CV → delay < 1 frame → need larger window to
    # average out temporal quantization noise.
    if snr_ratio >= 1.5:
        wr = 3          # 7×7  — low CV, gradient clear, default window
    elif snr_ratio >= 0.8:
        wr = 3          # 7×7  — mid CV, still OK
    elif snr_ratio >= 0.4:
        wr = 4          # 9×9  — high CV, widen window
    elif snr_ratio >= 0.2:
        wr = 5          # 11×11
    else:
        wr = 6          # 13×13 — very high CV (>200 mm/s)
    return wr


# ─────────────────────────────────────────────
#  Bayly polynomial fitting (single pass)
# ─────────────────────────────────────────────

def _bayly_pass(act_map: np.ndarray,
                mask: np.ndarray,
                px_to_mm: float,
                window_radius: int):
    """
    One full Bayly 2nd-order polynomial pass.
    Returns (dt_dx, dt_dy, grad_mag) arrays of shape (H, W).
    """
    H, W = act_map.shape
    wr   = window_radius

    dt_dx = np.full((H, W), np.nan)
    dt_dy = np.full((H, W), np.nan)

    # Build design matrix for this window size
    wx, wy = np.meshgrid(np.arange(-wr, wr + 1), np.arange(-wr, wr + 1))
    wx_mm  = wx.ravel() * px_to_mm
    wy_mm  = wy.ravel() * px_to_mm
    A_full = np.column_stack([wx_mm**2, wy_mm**2, wx_mm * wy_mm,
                               wx_mm,   wy_mm,    np.ones(len(wx_mm))])

    min_pts = max(10, (2 * wr + 1)**2 // 2)   # need at least half the window

    for i in range(wr, H - wr):
        for j in range(wr, W - wr):
            if not mask[i, j]:
                continue
            window = act_map[i - wr:i + wr + 1, j - wr:j + wr + 1].ravel()
            valid  = ~np.isnan(window)
            if valid.sum() < min_pts:
                continue
            try:
                coeffs, *_ = np.linalg.lstsq(A_full[valid], window[valid],
                                              rcond=None)
                dt_dx[i, j] = coeffs[3]
                dt_dy[i, j] = coeffs[4]
            except np.linalg.LinAlgError:
                continue

    grad_mag = np.sqrt(dt_dx**2 + dt_dy**2)
    return dt_dx, dt_dy, grad_mag


# ─────────────────────────────────────────────
#  IQR-robust median CV
# ─────────────────────────────────────────────

def _robust_median_cv(grad_mag: np.ndarray,
                      mask: np.ndarray,
                      cv_max: float = 500.0):
    """
    Convert gradient magnitude → CV, remove outliers with IQR fence,
    return (median_cv, lo_fence, hi_fence, filtered_vals).
    """
    valid_px = mask & (grad_mag > 1e-6) & ~np.isnan(grad_mag)
    if not valid_px.any():
        return np.nan, np.nan, np.nan, np.array([])

    cv_raw = 1.0 / grad_mag[valid_px]
    cv_raw = cv_raw[(cv_raw > 0) & (cv_raw <= cv_max)]

    if len(cv_raw) < 4:
        return float(np.median(cv_raw)), np.nan, np.nan, cv_raw

    q25, q75 = np.percentile(cv_raw, [25, 75])
    iqr       = q75 - q25
    lo        = q25 - 1.5 * iqr
    hi        = q75 + 1.5 * iqr

    cv_clean  = cv_raw[(cv_raw >= lo) & (cv_raw <= hi)]
    if len(cv_clean) == 0:
        cv_clean = cv_raw   # fallback: keep all if IQR removes everything

    return float(np.median(cv_clean)), float(lo), float(hi), cv_clean


# ─────────────────────────────────────────────
#  Main entry point
# ─────────────────────────────────────────────

def compute_activation_map(roi_data: np.ndarray,
                            mask: np.ndarray,
                            fps: float,
                            px_to_mm: float) -> ActivationResult:
    """
    Full activation map + two-pass adaptive Bayly CV.

    Parameters
    ----------
    roi_data  : (H, W, F) uint8 — cropped to ROI bounding box
    mask      : (H, W) bool     — organoid mask
    fps       : frames per second
    px_to_mm  : mm per pixel (user-calibrated)
    """
    H, W, num_frames = roi_data.shape

    # ── 1. Spatial binning (5×5) ─────────────────
    from scipy.ndimage import uniform_filter
    binned = np.zeros_like(roi_data, dtype=float)
    for f in range(num_frames):
        binned[:, :, f] = uniform_filter(roi_data[:, :, f].astype(float),
                                          size=5, mode='nearest')

    # ── 2. Average signal → beat detection ───────
    avg_signal  = binned.mean(axis=(0, 1))
    avg_smooth  = safe_sg(avg_signal, 3, 21)
    diff_signal = np.diff(avg_smooth)
    max_diff    = diff_signal.max()
    if max_diff <= 0:
        raise ValueError("No signal change detected in ROI.")

    L    = len(avg_smooth)
    Yfft = np.abs(np.fft.rfft(avg_smooth - avg_smooth.mean()))
    freq_axis = np.fft.rfftfreq(L, d=1.0 / fps)
    valid_f   = (freq_axis >= 0.3) & (freq_axis <= 6.0)

    beat_period_frames = round(fps * 0.5)
    if valid_f.any():
        dom_f = freq_axis[valid_f][np.argmax(Yfft[valid_f])]
        if dom_f > 0:
            beat_period_frames = round(fps / dom_f)

    from scipy.signal import find_peaks
    safe_dist = max(3, min(round(beat_period_frames * 0.6),
                            len(diff_signal) // 2 - 1))
    locs, _ = find_peaks(diff_signal,
                          height=max_diff * 0.3,
                          distance=safe_dist)
    if len(locs) == 0:
        raise ValueError("No activation peak found in average signal.")

    # ── 3. Search range ──────────────────────────
    pre_frames  = round(beat_period_frames * 0.15)
    post_frames = round(beat_period_frames * 0.80)
    sr_start    = max(0, locs[0] - pre_frames)
    sr_end      = min(num_frames - 1, locs[0] + post_frames)
    min_frames  = max(25, round(beat_period_frames * 0.5))
    if (sr_end - sr_start) < min_frames:
        sr_end = min(num_frames - 1, sr_start + min_frames)
    if len(locs) >= 2:
        sr_end = min(sr_end, locs[1] - pre_frames - 2)
    search_range = np.arange(sr_start, sr_end + 1)

    # ── 4. Pixel-wise activation time ────────────
    act_map = np.full((H, W), np.nan)

    for i in range(H):
        for j in range(W):
            if not mask[i, j]:
                continue
            trace = binned[i, j, search_range]
            win   = min(21, len(trace))
            if win % 2 == 0:
                win -= 1
            y_s = safe_sg(trace, 3, win) if win >= 5 else trace.copy()
            rng = y_s.max() - y_s.min()
            if rng < 1e-9:
                continue
            dff  = (y_s - y_s.min()) / rng
            idx2 = int(np.argmax(dff >= 0.5))
            if dff[idx2] < 0.5:
                exact_idx = float(int(np.argmax(np.diff(dff))))
            elif idx2 > 0:
                frac = (0.5 - dff[idx2 - 1]) / (dff[idx2] - dff[idx2 - 1] + 1e-9)
                exact_idx = (idx2 - 1) + frac
            else:
                exact_idx = float(idx2)
            act_map[i, j] = (search_range[0] + exact_idx) / fps

    act_map -= np.nanmin(act_map)

    # ══════════════════════════════════════════
    #  TWO-PASS ADAPTIVE BAYLY
    # ══════════════════════════════════════════

    # ── Pass 1: fixed window=3, rough CV ─────────
    _, _, grad_mag_rough = _bayly_pass(act_map, mask, px_to_mm, window_radius=3)
    cv_rough, *_ = _robust_median_cv(grad_mag_rough, mask)

    # ── Adaptive window decision ──────────────────
    wr_opt = _optimal_window_radius(cv_rough, fps, px_to_mm)

    # ── Pass 2: optimal window, final CV ─────────
    if wr_opt == 3:
        # No need to recompute — reuse Pass-1 gradient
        dt_dx_f, dt_dy_f, grad_mag_f = _bayly_pass(act_map, mask,
                                                     px_to_mm, wr_opt)
    else:
        dt_dx_f, dt_dy_f, grad_mag_f = _bayly_pass(act_map, mask,
                                                     px_to_mm, wr_opt)

    # ── IQR-robust median CV ─────────────────────
    median_cv, lo_fence, hi_fence, _ = _robust_median_cv(grad_mag_f, mask)

    return ActivationResult(
        act_map       = act_map,
        cv_mm_s       = median_cv,
        max_delay_ms  = float(np.nanmax(act_map) * 1000),
        dt_dx         = dt_dx_f,
        dt_dy         = dt_dy_f,
        mask          = mask,
        px_to_mm      = px_to_mm,
        cv_rough      = cv_rough,
        window_radius = wr_opt,
        cv_iqr_lo     = lo_fence,
        cv_iqr_hi     = hi_fence,
    )


# ─────────────────────────────────────────────
#  High-res visualization
# ─────────────────────────────────────────────

def prepare_hires_map(act_map: np.ndarray,
                      mask: np.ndarray,
                      px_to_mm: float,
                      interp_factor: int = 4):
    from scipy.interpolate import RegularGridInterpolator

    H, W   = act_map.shape
    filled  = _fill_missing(act_map)
    smoothed = gaussian_filter(filled, sigma=2.0)

    x_orig = np.arange(W);  y_orig = np.arange(H)
    xq = np.linspace(0, W - 1, W * interp_factor)
    yq = np.linspace(0, H - 1, H * interp_factor)

    interp_map = RegularGridInterpolator(
        (y_orig, x_orig), smoothed, method='linear',
        bounds_error=False, fill_value=np.nan)
    Xq, Yq = np.meshgrid(xq, yq)
    pts     = np.column_stack([Yq.ravel(), Xq.ravel()])
    hires   = gaussian_filter(interp_map(pts).reshape(Yq.shape), sigma=2.5)

    interp_mask = RegularGridInterpolator(
        (y_orig, x_orig), mask.astype(float), method='nearest',
        bounds_error=False, fill_value=0.0)
    mask_hr = interp_mask(pts).reshape(Yq.shape) > 0.5

    return hires * 1000, xq * px_to_mm, yq * px_to_mm, mask_hr


def _fill_missing(arr: np.ndarray) -> np.ndarray:
    out  = arr.copy()
    nan  = np.isnan(out)
    if not nan.any():
        return out
    from scipy.ndimage import distance_transform_edt
    _, idx = distance_transform_edt(nan, return_indices=True)
    out[nan] = out[tuple(idx[:, nan])]
    return out


# ═══════════════════════════════════════════════════════════════════════════════
#  CHIP-MODE  ─  Patterned tissue / chip mask & arc-length analysis
# ═══════════════════════════════════════════════════════════════════════════════

@dataclass
class ChipArcResult:
    """Arc-length activation analysis result for patterned chips."""
    arc_s:          np.ndarray   # arc-length positions (mm) along skeleton
    act_t:          np.ndarray   # activation times at each skeleton point (s)
    cv_mm_s:        float        # linear-regression CV (mm/s)
    r_squared:      float        # R² of linear fit
    skeleton_yx:    np.ndarray   # (N,2) skeleton pixel coords (row, col)
    act_map:        np.ndarray   # full 2D activation map (same as ActivationResult)
    mask:           np.ndarray   # chip boolean mask used
    px_to_mm:       float


def build_chip_mask_auto(roi_data: np.ndarray,
                         roi_shape_mask: np.ndarray,
                         activity_weight: float = 0.5) -> np.ndarray:
    """
    Auto mask for patterned chip.

    Strategy (differs from organoid mask):
    ────────────────────────────────────────
    Organoid mask uses  Mean × STD  →  requires bright cytoplasm.
    Chip Ca²⁺ channels can be dark between flashes, so we use a
    combined score:  activity_weight * STD  +  (1-activity_weight) * MEAN.
    This keeps the channel lumen even if baseline fluorescence is low.

    Parameters
    ----------
    roi_data        : (H, W, F) uint8
    roi_shape_mask  : (H, W) bool  – polygon drawn by user over the chip
    activity_weight : 0=pure mean brightness, 1=pure activity STD
    """
    from skimage.filters import threshold_otsu
    from skimage.morphology import remove_small_objects

    data = roi_data.astype(float)
    mean_img = data.mean(axis=2)
    std_img  = data.std(axis=2)

    def _norm(x):
        lo, hi = x.min(), x.max()
        return (x - lo) / (hi - lo + 1e-9)

    score = activity_weight * _norm(std_img) + (1 - activity_weight) * _norm(mean_img)
    score_smooth = gaussian_filter(score, sigma=1.5)

    # Otsu on ROI pixels only
    roi_vals = score_smooth[roi_shape_mask.astype(bool)]
    if roi_vals.size == 0:
        return roi_shape_mask.astype(bool)
    level = threshold_otsu(roi_vals) * 0.45   # more permissive than organoid
    bw    = (score_smooth > level) & roi_shape_mask.astype(bool)

    bw = binary_fill_holes(bw)
    bw = remove_small_objects(bw, min_size=31)  # >30 px
    return bw


def build_chip_mask_from_template(frame: np.ndarray,
                                   template_img: np.ndarray,
                                   roi_shape_mask: np.ndarray) -> np.ndarray:
    """
    Template-matching mask for chip.

    Finds the yellow channel pattern (template_img, grayscale) in the
    video frame using ORB feature matching + homography.
    Falls back to activity-based mask if matching fails (<8 inliers).

    Parameters
    ----------
    frame           : (H, W) uint8 — single video frame (grayscale)
    template_img    : (Ht, Wt, 3) uint8 — yellow chip image (BGR or RGB)
    roi_shape_mask  : (H, W) bool — user-drawn polygon on video
    """
    import cv2

    H, W = frame.shape[:2]

    # Convert template to grayscale if needed
    if template_img.ndim == 3:
        tpl_gray = cv2.cvtColor(template_img, cv2.COLOR_BGR2GRAY)
    else:
        tpl_gray = template_img.copy()

    # Invert template if it's a yellow-on-white image
    # (yellow in grayscale ≈ bright → invert so features are dark-on-bright)
    if tpl_gray.mean() > 128:
        tpl_gray = 255 - tpl_gray

    # ORB feature matching
    orb  = cv2.ORB_create(nfeatures=1000)
    kp1, des1 = orb.detectAndCompute(tpl_gray, None)
    kp2, des2 = orb.detectAndCompute(frame, None)

    matched_mask = None
    if des1 is not None and des2 is not None and len(kp1) >= 4 and len(kp2) >= 4:
        bf      = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        matches = bf.knnMatch(des1, des2, k=2)
        good    = [m for m, n in matches if m.distance < 0.75 * n.distance]

        if len(good) >= 8:
            src_pts = np.float32([kp1[m.queryIdx].pt for m in good]).reshape(-1,1,2)
            dst_pts = np.float32([kp2[m.trainIdx].pt for m in good]).reshape(-1,1,2)
            H_mat, inlier_mask = cv2.findHomography(src_pts, dst_pts,
                                                     cv2.RANSAC, 5.0)
            n_inliers = int(inlier_mask.sum()) if inlier_mask is not None else 0
            if H_mat is not None and n_inliers >= 8:
                # Warp template binary mask into frame space
                tpl_bin = (tpl_gray < 128).astype(np.uint8) * 255
                warped  = cv2.warpPerspective(tpl_bin, H_mat, (W, H))
                matched_mask = (warped > 127) & roi_shape_mask.astype(bool)

    if matched_mask is None or matched_mask.sum() < 50:
        # Fallback: cannot match — return None so caller can use auto/manual
        return None

    matched_mask = binary_fill_holes(matched_mask)
    return matched_mask


def extract_skeleton_arc(mask: np.ndarray,
                          px_to_mm: float) -> tuple:
    """
    Extract ordered skeleton of a chip mask and compute arc-length.

    Returns
    -------
    (yx_ordered, arc_mm) : (N,2) int array of (row, col),  (N,) float mm
    Uses morphological skeleton → graph traversal from one endpoint to the other.
    """
    from skimage.morphology import skeletonize, remove_small_objects

    skel = skeletonize(mask)

    # Find endpoints: skeleton pixels with exactly 1 neighbour
    from scipy.ndimage import convolve
    kernel = np.ones((3, 3), dtype=int)
    neighbour_count = convolve(skel.astype(int), kernel, mode='constant') * skel.astype(int)
    endpoints = np.argwhere((neighbour_count == 2))   # 2 = self + 1 neighbour

    if len(endpoints) < 2:
        # No clear endpoints (ring or blob) → use bounding-box longest axis
        yx = np.argwhere(skel)
        if len(yx) == 0:
            return np.zeros((0, 2), int), np.zeros(0)
        # project onto first PCA axis
        from numpy.linalg import eigh
        cov = np.cov(yx.T)
        _, vecs = eigh(cov)
        main_axis = vecs[:, -1]
        proj = yx @ main_axis
        order = np.argsort(proj)
        yx_ord = yx[order]
    else:
        # BFS/DFS traversal from first endpoint
        start = tuple(endpoints[0])
        yx_set = set(map(tuple, np.argwhere(skel)))
        visited = []
        stack   = [start]
        seen    = set()
        while stack:
            node = stack.pop()
            if node in seen:
                continue
            seen.add(node)
            visited.append(node)
            r, c = node
            for dr in [-1, 0, 1]:
                for dc in [-1, 0, 1]:
                    nb = (r + dr, c + dc)
                    if nb != node and nb in yx_set and nb not in seen:
                        stack.append(nb)
        yx_ord = np.array(visited)

    # Arc-length (cumulative Euclidean distance in mm)
    if len(yx_ord) == 0:
        return yx_ord, np.zeros(0)
    diffs = np.diff(yx_ord.astype(float), axis=0)
    step_mm = np.sqrt((diffs**2).sum(axis=1)) * px_to_mm
    arc_mm  = np.concatenate([[0.0], np.cumsum(step_mm)])
    return yx_ord, arc_mm


def compute_arc_length_cv(act_map: np.ndarray,
                           mask: np.ndarray,
                           px_to_mm: float) -> ChipArcResult:
    """
    Compute 1D arc-length activation plot and linear-regression CV for a chip.

    Samples the 2D activation map along the skeleton of the chip mask,
    then fits t(s) = s / CV  (linear, forced through origin or free intercept).

    Returns ChipArcResult with arc_s, act_t, cv_mm_s, r_squared.
    """
    from scipy.stats import linregress

    yx_ord, arc_mm = extract_skeleton_arc(mask, px_to_mm)
    if len(yx_ord) == 0:
        return ChipArcResult(
            arc_s=np.zeros(0), act_t=np.zeros(0),
            cv_mm_s=np.nan, r_squared=np.nan,
            skeleton_yx=yx_ord, act_map=act_map,
            mask=mask, px_to_mm=px_to_mm)

    # Sample act_map at skeleton pixels (with NaN guard)
    act_vals = np.array([act_map[r, c] for r, c in yx_ord])
    valid    = ~np.isnan(act_vals)

    if valid.sum() < 4:
        return ChipArcResult(
            arc_s=arc_mm, act_t=act_vals,
            cv_mm_s=np.nan, r_squared=np.nan,
            skeleton_yx=yx_ord, act_map=act_map,
            mask=mask, px_to_mm=px_to_mm)

    s_v = arc_mm[valid]
    t_v = act_vals[valid]

    slope, intercept, r, *_ = linregress(s_v, t_v)
    cv_mm_s = (1.0 / slope) if abs(slope) > 1e-9 else np.nan

    return ChipArcResult(
        arc_s=arc_mm,
        act_t=act_vals,
        cv_mm_s=cv_mm_s,
        r_squared=r**2,
        skeleton_yx=yx_ord,
        act_map=act_map,
        mask=mask,
        px_to_mm=px_to_mm,
    )
