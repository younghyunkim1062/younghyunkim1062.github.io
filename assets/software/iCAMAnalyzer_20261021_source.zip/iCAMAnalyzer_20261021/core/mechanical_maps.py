"""
core/mechanical_maps.py  — Contour-Based Mechanical Maps
=========================================================

4 maps, all derived from per-frame organoid contour tracking.
Works on brightfield where optical flow fails (no internal texture).

Maps
----
A. Radial displacement map   : how far each contour point moved inward [px]
B. Arc-length strain map     : local stretch/compression of contour [%]
C. Δκ curvature change map   : κ_peak − κ_rest  [mm⁻¹]  (MATLAB logic)
D. Mechanical activation map : when each contour point started contracting [ms]

Physics note
------------
All maps are defined ON THE CONTOUR (1-D, arc-length parametrised).
This is appropriate for a spheroid where the measurable deformation
is the boundary motion — not an internal flow field.
"""

import numpy as np
import cv2
from scipy.ndimage import gaussian_filter1d
from scipy.signal import find_peaks
from dataclasses import dataclass
from typing import Optional, List


# ─────────────────────────────────────────────
# Data container
# ─────────────────────────────────────────────

@dataclass
class MechanicalMaps:
    # All arrays are length N (number of contour points, arc-length order)
    arc_s:          np.ndarray   # arc-length coordinate [mm]
    cx:             np.ndarray   # x physical coord of resting contour [mm]
    cy:             np.ndarray   # y physical coord of resting contour [mm]

    # A
    radial_disp:    np.ndarray   # radial inward displacement [px], >0 = contraction
    # B
    strain:         np.ndarray   # arc-length strain = (ds_peak-ds_rest)/ds_rest [%]
    # C
    delta_kappa:    np.ndarray   # Δκ = κ_peak − κ_rest [mm⁻¹]
    kappa_rest:     np.ndarray
    kappa_peak:     np.ndarray
    # D
    mech_act_ms:    np.ndarray   # activation time [ms], NaN = no signal
    act_valid:      np.ndarray   # bool mask: True where activation detected

    # Metadata
    mask:           np.ndarray   # (H,W) bool — organoid binary mask (resting)
    rest_idx:       int
    peak_idx:       int
    fps:            float
    px_to_mm:       float
    n_frames:       int
    contour_rest_px: np.ndarray  # (N,2) col,row in pixel coords
    contour_peak_px: np.ndarray


# ─────────────────────────────────────────────
# Mask & contour helpers
# ─────────────────────────────────────────────

def _binarise(frame_gray: np.ndarray, roi_mask: np.ndarray) -> np.ndarray:
    """
    Brightfield-aware binarisation with CLAHE preprocessing.
    Handles complex backgrounds (e.g. water droplets, uneven illumination).
    """
    img = frame_gray.copy().astype(np.uint8)

    # CLAHE: enhance local contrast so organoid boundary stands out
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    img = clahe.apply(img)

    # Mask outside ROI to neutral mid-gray (not extreme values)
    img[~roi_mask] = 128

    # Try both directions, pick the one whose largest blob is
    # closest to the center of the ROI (organoid should be central)
    h, w = img.shape
    cy_roi, cx_roi = h // 2, w // 2

    def _score(bw):
        n, labs, stats, centroids = cv2.connectedComponentsWithStats(bw)
        if n < 2:
            return -1, None, None
        # Largest blob
        idx = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
        area = stats[idx, cv2.CC_STAT_AREA]
        cx_b, cy_b = centroids[idx]
        dist = np.sqrt((cx_b - cx_roi)**2 + (cy_b - cy_roi)**2)
        # Score: large area + close to center
        score = area / (dist + 1)
        return score, labs, idx

    _, bw_inv = cv2.threshold(img, 0, 255,
                               cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    _, bw_fwd = cv2.threshold(img, 0, 255,
                               cv2.THRESH_BINARY     + cv2.THRESH_OTSU)

    sc_inv, labs_inv, idx_inv = _score(bw_inv)
    sc_fwd, labs_fwd, idx_fwd = _score(bw_fwd)

    if sc_inv >= sc_fwd and labs_inv is not None:
        bw = ((labs_inv == idx_inv) * 255).astype(np.uint8)
    elif labs_fwd is not None:
        bw = ((labs_fwd == idx_fwd) * 255).astype(np.uint8)
    else:
        bw = bw_inv  # fallback

    # Morphological cleanup
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
    bw = cv2.morphologyEx(bw, cv2.MORPH_CLOSE, kernel, iterations=2)
    bw = cv2.morphologyEx(bw, cv2.MORPH_OPEN,  kernel, iterations=1)

    # Fill holes
    flood = bw.copy()
    mf = np.zeros((h+2, w+2), np.uint8)
    cv2.floodFill(flood, mf, (0, 0), 255)
    return bw | cv2.bitwise_not(flood)


def _extract_ordered_contour(bw: np.ndarray) -> Optional[np.ndarray]:
    """
    Returns contour as (N,2) array of (col, row) = (x, y) pixel coords,
    ordered clockwise, CHAIN_APPROX_NONE for dense sampling.
    """
    cnts, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    if not cnts:
        return None
    c = max(cnts, key=cv2.contourArea)
    return c[:, 0, :]   # (N, 2): col, row


def _resample_contour(pts: np.ndarray, n_target: int) -> np.ndarray:
    """Resample contour to exactly n_target points via arc-length interpolation."""
    d = np.sqrt(np.sum(np.diff(pts, axis=0)**2, axis=1))
    s = np.concatenate([[0], np.cumsum(d)])
    s_new = np.linspace(0, s[-1], n_target)
    cx = np.interp(s_new, s, pts[:, 0])
    cy = np.interp(s_new, s, pts[:, 1])
    return np.column_stack([cx, cy])


# ─────────────────────────────────────────────
# C. Δκ — MATLAB CurvatureAnalysisApp.m logic
# ─────────────────────────────────────────────

def _compute_curvature(contour_xy: np.ndarray,
                       px_to_mm: float,
                       poly_order: int = 3,
                       window: int = 22) -> np.ndarray:
    """
    Signed curvature at each contour point.
    contour_xy : (N,2) col,row  (= x,y in image coords)
    Returns kappa [mm⁻¹].

    Identical to CurvatureAnalysisApp.m:
      pX = polyfit on row coords
      pY = polyfit on col coords
      κ  = -(x'y'' - y'x'') / (x'²+y'²)^1.5  / scale
    """
    n  = len(contour_xy)
    c2 = np.vstack([contour_xy, contour_xy])   # wrap-around
    half = window // 2
    t    = np.arange(window + 1, dtype=float)
    kappa = np.zeros(n)

    for i in range(n):
        seg = c2[i: i + window + 1]
        row_s = seg[:, 1].astype(float)   # row = Y in image
        col_s = seg[:, 0].astype(float)   # col = X in image

        # MATLAB convention: pX on rows, pY on cols
        px = np.polyfit(t, row_s, poly_order)
        py = np.polyfit(t, col_s, poly_order)

        px1 = np.polyder(px, 1); py1 = np.polyder(py, 1)
        px2 = np.polyder(px, 2); py2 = np.polyder(py, 2)

        x1 = np.polyval(px1, half); y1 = np.polyval(py1, half)
        x2 = np.polyval(px2, half); y2 = np.polyval(py2, half)

        denom = (x1**2 + y1**2) ** 1.5
        kappa[i] = 0.0 if denom < 1e-12 else \
                   -(x1*y2 - y1*x2) / denom / px_to_mm

    return kappa


# ─────────────────────────────────────────────
# A. Radial displacement
# ─────────────────────────────────────────────

def _radial_displacement(cnt_rest: np.ndarray,
                         cnt_peak: np.ndarray) -> np.ndarray:
    """
    For each point on the resting contour, compute inward displacement
    = projection of (rest→peak) vector onto the inward normal.
    Positive value = contraction (point moved toward centroid).
    """
    cx_r = cnt_rest[:, 0].mean(); cy_r = cnt_rest[:, 1].mean()

    # Inward normal at each resting point = unit vector toward centroid
    dx_in = cx_r - cnt_rest[:, 0]
    dy_in = cy_r - cnt_rest[:, 1]
    mag   = np.sqrt(dx_in**2 + dy_in**2) + 1e-9
    nx = dx_in / mag
    ny = dy_in / mag

    # Displacement vector rest→peak
    dv = cnt_peak - cnt_rest   # (N,2)

    # Radial (inward) component
    return dv[:, 0] * nx + dv[:, 1] * ny


# ─────────────────────────────────────────────
# B. Arc-length strain
# ─────────────────────────────────────────────

def _arc_strain(cnt_rest: np.ndarray,
                cnt_peak: np.ndarray,
                window_pts: int = 5) -> np.ndarray:
    """
    Local arc-length strain = (ds_peak - ds_rest) / ds_rest  [fraction]
    Averaged over a sliding window of window_pts neighbours.
    Negative = compression (contraction), positive = stretch.
    """
    n = len(cnt_rest)

    def _local_arc(cnt, i, w):
        idx = [(i + k) % n for k in range(-w//2, w//2+1)]
        pts = cnt[idx]
        d   = np.sqrt(np.sum(np.diff(pts, axis=0)**2, axis=1))
        return d.sum()

    strain = np.zeros(n)
    for i in range(n):
        ds_r = _local_arc(cnt_rest, i, window_pts)
        ds_p = _local_arc(cnt_peak, i, window_pts)
        strain[i] = (ds_p - ds_r) / (ds_r + 1e-9) * 100.0   # percent
    return strain


# ─────────────────────────────────────────────
# D. Mechanical activation  (Radial-Profile method)
# ─────────────────────────────────────────────

def _radial_profile_activation(
        frame_cnts_all: List,
        rest_idx: int,
        beat_start: int,
        beat_end: int,
        fps: float,
        n_angles: int = 512,
        threshold_frac: float = 0.05,
        smooth_sigma: float = 1.5,
) -> tuple:
    """
    Robust mechanical activation using Radial Distance Profile.

    For each angle θ from the organoid centroid:
      Δr(θ, t) = r_rest(θ) - r(θ, t)   [positive = inward = contraction]
    Activation = first frame where Δr exceeds threshold_frac × max(Δr).
    """
    from scipy.interpolate import interp1d
    from scipy.ndimage import gaussian_filter1d as _gf1d

    def _cnt_to_xy(cnt):
        if cnt is None:
            return None
        arr = np.array(cnt)
        if arr.ndim == 3:
            arr = arr[:, 0, :]
        return arr.astype(float).copy()  # always return a copy

    # Rest contour → centroid (fixed reference for all frames)
    cnt_r_raw = _cnt_to_xy(frame_cnts_all[rest_idx]
                            if rest_idx < len(frame_cnts_all) else None)
    if cnt_r_raw is None:
        return (np.full(n_angles, np.nan), np.zeros(n_angles, bool),
                None, None, None, None)

    cx0 = cnt_r_raw[:, 0].mean()
    cy0 = cnt_r_raw[:, 1].mean()

    theta_bins = np.linspace(-np.pi, np.pi, n_angles, endpoint=False)

    def _radius_profile(cnt_xy):
        """
        Measure contour radius at each angle bin.
        Centroid of cnt_xy is aligned to (cx0, cy0) before computing angles.
        """
        # Copy to avoid modifying original
        xy = cnt_xy.copy()
        # Align this contour's centroid to rest centroid
        xy[:, 0] += (cx0 - xy[:, 0].mean())
        xy[:, 1] += (cy0 - xy[:, 1].mean())

        dx = xy[:, 0] - cx0
        dy = xy[:, 1] - cy0
        angles = np.arctan2(dy, dx)
        radii  = np.sqrt(dx**2 + dy**2)

        # Sort by angle, then wrap for periodic interpolation
        order   = np.argsort(angles)
        angles  = angles[order]
        radii   = radii[order]
        angles_w = np.concatenate([angles - 2*np.pi, angles, angles + 2*np.pi])
        radii_w  = np.concatenate([radii,  radii,  radii])

        f = interp1d(angles_w, radii_w, kind='linear',
                     bounds_error=False, fill_value=np.nan)
        return f(theta_bins)

    # Rest profile (reference)
    r_rest = _radius_profile(cnt_r_raw)

    # Build r(θ, t) series over beat window
    n_frames_win = beat_end - beat_start + 1
    r_series = np.full((n_angles, n_frames_win), np.nan, dtype=np.float32)

    for k, frame_abs in enumerate(range(beat_start, beat_end + 1)):
        if frame_abs >= len(frame_cnts_all):
            continue
        cnt_raw = _cnt_to_xy(frame_cnts_all[frame_abs])
        if cnt_raw is None:
            continue
        r_series[:, k] = _radius_profile(cnt_raw)

    # Δr = inward displacement per angle per frame
    delta_r = r_rest[:, None] - r_series   # positive = contraction

    # Forward-fill NaN columns (missing frames)
    for k in range(1, n_frames_win):
        mask_nan = np.isnan(r_series[:, k])
        r_series[mask_nan, k] = r_series[mask_nan, k-1]

    # Smooth along time axis
    if smooth_sigma > 0:
        valid_cols = ~np.all(np.isnan(delta_r), axis=0)
        if valid_cols.any():
            delta_r[:, valid_cols] = _gf1d(
                delta_r[:, valid_cols], smooth_sigma, axis=1)

    # Find rest frame index within window (minimum Δr sum = closest to rest)
    col_rest = rest_idx - beat_start
    col_rest = max(0, min(col_rest, n_frames_win - 1))

    act_ms    = np.full(n_angles, np.nan)
    act_valid = np.zeros(n_angles, bool)

    for i in range(n_angles):
        trace = delta_r[i]
        if np.all(np.isnan(trace)):
            continue

        # Look only from rest frame onward (not before)
        trace_from_rest = trace[col_rest:]
        peak_val = float(np.nanmax(trace_from_rest))
        if peak_val < 0.5:   # < 0.5 px inward → likely noise
            continue

        thresh = threshold_frac * peak_val
        crossings = np.where(trace_from_rest >= thresh)[0]
        if len(crossings) == 0:
            continue

        k0 = int(crossings[0])
        frame_in_win = col_rest + k0
        if k0 == 0:
            t_act = (beat_start + frame_in_win) / fps
        else:
            v0 = float(trace[col_rest + k0 - 1])
            v1 = float(trace[col_rest + k0])
            if np.isnan(v0):
                v0 = 0.0
            frac = (thresh - v0) / (v1 - v0 + 1e-9)
            t_act = (beat_start + frame_in_win - 1 + frac) / fps

        act_ms[i]    = t_act * 1000.0
        act_valid[i] = True

    # Normalize: earliest activation = 0 ms
    if act_valid.any():
        act_ms[act_valid] -= act_ms[act_valid].min()

    return act_ms, act_valid, theta_bins, r_rest, cx0, cy0


def _mechanical_activation(frames, roi_mask, cnt_rest_px,
                            fps, beat_start, beat_end, n_pts,
                            centroid_rest, threshold_frac=0.05,
                            smooth_sigma=1.5,
                            frame_cnts_all=None,
                            frame_offsets=None,
                            rest_idx=None):
    """
    Wrapper: uses radial-profile method when frame_cnts_all is available
    (always the case in GUI flow), falls back to legacy arc-length otherwise.
    """
    if frame_cnts_all is not None and len(frame_cnts_all) > 0:
        # Use actual rest_idx; fall back to beat_start if not provided
        _rest = rest_idx if rest_idx is not None else beat_start
        act_ms, act_valid, theta_bins, r_rest, cx0, cy0 = \
            _radial_profile_activation(
                frame_cnts_all, _rest,
                beat_start, beat_end, fps,
                n_angles=n_pts,
                threshold_frac=threshold_frac,
                smooth_sigma=smooth_sigma)
        return act_ms, act_valid
    else:
        return _mechanical_activation_legacy(
            frames, roi_mask, cnt_rest_px,
            fps, beat_start, beat_end, n_pts,
            centroid_rest, threshold_frac, smooth_sigma)


def _mechanical_activation_legacy(frames, roi_mask, cnt_rest_px,
                                    fps, beat_start, beat_end, n_pts,
                                    centroid_rest, threshold_frac=0.05,
                                    smooth_sigma=1.5,
                                    frame_cnts_all=None,
                                    frame_offsets=None):
    """Original arc-length point-matching method (fallback only)."""
    n_sf = beat_end - beat_start + 1
    if n_sf < 3:
        return np.full(n_pts, np.nan), np.zeros(n_pts, bool)

    cx0, cy0 = centroid_rest
    cnt_r = _resample_contour(cnt_rest_px, n_pts)

    dx_in = cx0 - cnt_r[:, 0]; dy_in = cy0 - cnt_r[:, 1]
    mag   = np.sqrt(dx_in**2 + dy_in**2) + 1e-9
    nx = dx_in / mag; ny = dy_in / mag

    disp_series = np.zeros((n_pts, n_sf), dtype=np.float32)

    for k_idx, frame_abs in enumerate(range(beat_start, beat_end + 1)):
        cnt_k_raw = None
        if frame_cnts_all is not None and frame_abs < len(frame_cnts_all):
            cnt_k_raw = frame_cnts_all[frame_abs]
        if cnt_k_raw is None:
            if frame_abs < len(frames):
                bw = _binarise(frames[frame_abs], roi_mask)
                cnt_k_raw = _extract_ordered_contour(bw)
        if cnt_k_raw is None:
            continue

        cnt_k_xy = cnt_k_raw[:, 0, :] if cnt_k_raw.ndim == 3 else cnt_k_raw
        cnt_k_xy = cnt_k_xy.astype(float).copy()
        cnt_k_xy[:, 0] += (cx0 - cnt_k_xy[:, 0].mean())
        cnt_k_xy[:, 1] += (cy0 - cnt_k_xy[:, 1].mean())

        cnt_k = _resample_contour(cnt_k_xy, n_pts)
        shift = _align_contour_start(cnt_r, cnt_k)
        cnt_k = np.roll(cnt_k, -shift, axis=0)

        dv = cnt_k - cnt_r
        disp_series[:, k_idx] = dv[:, 0] * nx + dv[:, 1] * ny

    if smooth_sigma > 0:
        from scipy.ndimage import gaussian_filter1d as _gf1d
        disp_series = _gf1d(disp_series, smooth_sigma, axis=1)

    act_ms = np.full(n_pts, np.nan)
    valid  = np.zeros(n_pts, bool)

    for i in range(n_pts):
        trace    = disp_series[i]
        peak_val = float(trace.max())
        if peak_val < 0.3:
            continue
        thresh = threshold_frac * peak_val
        crossings = np.where(trace >= thresh)[0]
        if len(crossings) == 0:
            continue
        k0 = int(crossings[0])
        if k0 == 0:
            t_act = beat_start / fps
        else:
            v0 = float(trace[k0-1]); v1 = float(trace[k0])
            frac = (thresh - v0) / (v1 - v0 + 1e-9)
            t_act = (beat_start + k0 - 1 + frac) / fps
        act_ms[i] = t_act * 1000.0
        valid[i]  = True

    if valid.any():
        act_ms[valid] -= act_ms[valid].min()

    return act_ms, valid

def _detect_beat_window(frames: List[np.ndarray],
                        roi_mask: np.ndarray,
                        fps: float) -> tuple[int, int, int, int]:
    """Area signal → rest/peak frame + search window."""
    areas = []
    for f in frames:
        bw = _binarise(f, roi_mask)
        areas.append(float((bw > 0).sum()))
    areas = np.array(areas)

    dist = max(1, int(fps * 0.6))
    peaks,   _ = find_peaks( areas, distance=dist)
    troughs, _ = find_peaks(-areas, distance=dist)

    if len(peaks) == 0 or len(troughs) == 0:
        ri = int(np.argmax(areas))
        pi = int(np.argmin(areas))
        margin = max(5, int(fps * 0.15))
        return ri, pi, max(0, ri - margin), min(len(frames)-1, pi + margin)

    best_sw, best_r, best_p = -1, 0, 0
    for pk in peaks:
        after = troughs[troughs > pk]
        if not len(after):
            continue
        tr = after[0]
        sw = areas[pk] - areas[tr]
        if sw > best_sw:
            best_sw, best_r, best_p = sw, int(pk), int(tr)

    margin = max(5, int(fps * 0.15))
    return (best_r, best_p,
            max(0, best_r - margin),
            min(len(frames)-1, best_p + margin))


# ─────────────────────────────────────────────
# Main analyser
# ─────────────────────────────────────────────

N_CONTOUR = 512   # resampled contour points

class MechanicalMapAnalyzer:
    def __init__(self, fps: float, px_to_mm: float,
                 poly_order: int = 3, kappa_window: int = 22,
                 smooth_sigma: float = 2.0,
                 act_threshold: float = 0.05):
        self.fps           = fps
        self.px_to_mm      = px_to_mm
        self.poly_order    = poly_order
        self.kappa_window  = kappa_window
        self.smooth_sigma  = smooth_sigma
        self.act_threshold = act_threshold

    def _beat_window(self, rest_idx: int, peak_idx: int,
                     n_frames: int,
                     area_peaks, area_troughs) -> tuple:
        """
        Compute accurate beat window (b_s, b_e) for the rest→peak cycle.

        Logic:
          b_s = previous trough before rest_idx
                (= end of prior relaxation = true start of this beat)
          b_e = next trough after peak_idx
                (= end of this contraction = true end of this beat)

        Falls back to fixed margin if peaks/troughs not available.
        """
        margin = max(5, int(self.fps * 0.15))

        if not area_peaks or not area_troughs:
            # Fallback: fixed margin
            return (max(0, rest_idx - margin),
                    min(n_frames - 1, peak_idx + margin))

        peaks   = np.array(area_peaks,   dtype=int)
        troughs = np.array(area_troughs, dtype=int)

        # b_s: trough immediately before rest_idx (previous beat's trough)
        before = troughs[troughs < rest_idx]
        if len(before):
            b_s = int(before[-1])
        else:
            b_s = max(0, rest_idx - margin)

        # b_e: trough immediately after peak_idx (end of this contraction)
        after = troughs[troughs > peak_idx]
        if len(after):
            b_e = int(after[0])
        else:
            b_e = min(n_frames - 1, peak_idx + margin)

        return b_s, b_e

    def run(self,
            frames: List[np.ndarray],
            mask:   np.ndarray,
            rest_idx: Optional[int] = None,
            peak_idx: Optional[int] = None,
            cnt_rest_cv: Optional[np.ndarray] = None,
            cnt_peak_cv: Optional[np.ndarray] = None,
            frame_cnts_all: Optional[List] = None,
            frame_offsets: Optional[List] = None,
            area_peaks: Optional[List[int]] = None,
            area_troughs: Optional[List[int]] = None) -> MechanicalMaps:
        """
        area_peaks / area_troughs : peak/trough frame indices from Extract Signals
            → used to compute an accurate beat window (b_s, b_e) that matches
              exactly one rest→peak cycle, rather than a fixed margin.
        """
        roi_mask = mask.astype(bool)

        if rest_idx is None or peak_idx is None:
            r_a, p_a, b_s, b_e = _detect_beat_window(frames, roi_mask, self.fps)
            rest_idx = rest_idx if rest_idx is not None else r_a
            peak_idx = peak_idx if peak_idx is not None else p_a
        else:
            # ── Accurate beat window from Extract Signals peaks/troughs ───
            b_s, b_e = self._beat_window(
                rest_idx, peak_idx, len(frames),
                area_peaks, area_troughs)

        # b_s must come before peak for activation window
        if b_s > b_e:
            b_s, b_e = min(rest_idx, peak_idx), max(rest_idx, peak_idx)

        # ── Use pre-computed contours if available ─────────────────────────
        def _cv_to_xy(cnt_cv):
            """Convert OpenCV contour (N,1,2) or (N,2) to (N,2) col,row array."""
            if cnt_cv is None:
                return None
            arr = np.array(cnt_cv)
            if arr.ndim == 3:
                arr = arr[:, 0, :]   # (N,1,2) → (N,2)
            return arr  # already col,row = x,y

        cnt_r_raw = _cv_to_xy(cnt_rest_cv)
        cnt_p_raw = _cv_to_xy(cnt_peak_cv)

        # Fall back to binarisation if contours not supplied
        if cnt_r_raw is None:
            bw_rest = _binarise(frames[rest_idx], roi_mask)
            cnt_r_raw = _extract_ordered_contour(bw_rest)
        if cnt_p_raw is None:
            bw_peak = _binarise(frames[peak_idx], roi_mask)
            cnt_p_raw = _extract_ordered_contour(bw_peak)

        if cnt_r_raw is None or cnt_p_raw is None:
            raise RuntimeError("Contour extraction failed.")

        # Resample both to N_CONTOUR points
        cnt_r = _resample_contour(cnt_r_raw, N_CONTOUR)
        cnt_p = _resample_contour(cnt_p_raw, N_CONTOUR)

        # Align peak contour starting point to resting (minimise total distance)
        shift = _align_contour_start(cnt_r, cnt_p)
        cnt_p = np.roll(cnt_p, -shift, axis=0)

        # Physical coordinates [mm]
        cx_mm =  cnt_r[:, 0] * self.px_to_mm
        cy_mm = -cnt_r[:, 1] * self.px_to_mm   # flip y for display

        # Arc-length [mm]
        d = np.sqrt(np.sum(np.diff(cnt_r, axis=0)**2, axis=1)) * self.px_to_mm
        arc_s = np.concatenate([[0], np.cumsum(d)])

        # ── A. Radial displacement ────────────────────────────────────────
        rad_disp = _radial_displacement(cnt_r, cnt_p)
        if self.smooth_sigma > 0:
            rad_disp = gaussian_filter1d(rad_disp, self.smooth_sigma, mode='wrap')

        # ── B. Arc-length strain ──────────────────────────────────────────
        strain = _arc_strain(cnt_r, cnt_p, window_pts=7)
        if self.smooth_sigma > 0:
            strain = gaussian_filter1d(strain, self.smooth_sigma, mode='wrap')

        # ── C. Δκ (MATLAB logic) ──────────────────────────────────────────
        kr = _compute_curvature(cnt_r, self.px_to_mm,
                                self.poly_order, self.kappa_window)
        kp = _compute_curvature(cnt_p, self.px_to_mm,
                                self.poly_order, self.kappa_window)
        if self.smooth_sigma > 0:
            kr = gaussian_filter1d(kr, self.smooth_sigma, mode='wrap')
            kp = gaussian_filter1d(kp, self.smooth_sigma, mode='wrap')
        dk = kp - kr

        # ── D. Mechanical activation (radial-profile method) ─────────────
        centroid = (cnt_r[:, 0].mean(), cnt_r[:, 1].mean())
        act_ms, act_valid = _mechanical_activation(
            frames, roi_mask, cnt_r_raw,
            self.fps, b_s, b_e, N_CONTOUR, centroid,
            threshold_frac=self.act_threshold,
            frame_cnts_all=frame_cnts_all,
            frame_offsets=frame_offsets,
            rest_idx=rest_idx)

        # mask: use roi_mask since bw_rest may not exist when cnt provided
        out_mask = roi_mask

        return MechanicalMaps(
            arc_s           = arc_s,
            cx              = cx_mm,
            cy              = cy_mm,
            radial_disp     = rad_disp,
            strain          = strain,
            delta_kappa     = dk,
            kappa_rest      = kr,
            kappa_peak      = kp,
            mech_act_ms     = act_ms,
            act_valid       = act_valid,
            mask            = out_mask,
            rest_idx        = rest_idx,
            peak_idx        = peak_idx,
            fps             = self.fps,
            px_to_mm        = self.px_to_mm,
            n_frames        = len(frames),
            contour_rest_px = cnt_r,
            contour_peak_px = cnt_p,
        )


def _align_contour_start(cnt_r: np.ndarray, cnt_p: np.ndarray) -> int:
    """
    Find roll offset that minimises mean distance between two contours.
    Coarse-to-fine: check 32 coarse candidates, then refine ±8 around best.
    """
    n = len(cnt_r)

    # Coarse pass: 32 candidates
    coarse = np.linspace(0, n, 33, dtype=int)[:-1]
    best_shift, best_d = 0, np.inf
    for s in coarse:
        rolled = np.roll(cnt_p, -int(s), axis=0)
        d = np.mean(np.sqrt(np.sum((cnt_r - rolled)**2, axis=1)))
        if d < best_d:
            best_d, best_shift = d, int(s)

    # Fine pass: ±(n//32) around best
    window = max(1, n // 32)
    for s in range(best_shift - window, best_shift + window + 1):
        s = s % n
        rolled = np.roll(cnt_p, -s, axis=0)
        d = np.mean(np.sqrt(np.sum((cnt_r - rolled)**2, axis=1)))
        if d < best_d:
            best_d, best_shift = d, s

    return best_shift


# ─────────────────────────────────────────────
# Plotting — 4-panel with contour overlay
# ─────────────────────────────────────────────

def plot_mechanical_maps(m: MechanicalMaps,
                         bg_frame: Optional[np.ndarray] = None,
                         save_path: Optional[str] = None,
                         ca2_act_ms: Optional[np.ndarray] = None
                         ) -> "plt.Figure":
    """
    5-panel figure showing contour-based maps in 2D (organoid shape).
      Panel 0 : contour overlay (rest=red, peak=blue) on bg_frame
      A        : radial displacement [px]  — colored dots on contour shape
      B        : arc-length strain [%]
      C        : Δκ [mm⁻¹]
      D        : mechanical activation [ms]
    """
    import matplotlib.pyplot as plt
    import matplotlib.gridspec as gridspec
    from matplotlib.colors import TwoSlopeNorm, Normalize

    def _safe_norm(v, vcenter=0.0):
        vmin, vmax = -abs(v), abs(v)
        if vmin < vcenter < vmax:
            return TwoSlopeNorm(vmin=vmin, vcenter=vcenter, vmax=vmax)
        lo = min(vmin, vcenter) - 1e-6
        hi = max(vmax, vcenter) + 1e-6
        return Normalize(vmin=lo, vmax=hi)

    DARK = '#0d0d0d'; TEXT = '#e8e8e8'; ACC = '#00d4ff'

    fig = plt.figure(figsize=(20, 5), facecolor=DARK)
    gs  = gridspec.GridSpec(1, 5, figure=fig,
                            wspace=0.35, left=0.03, right=0.97,
                            top=0.88, bottom=0.08)

    def _style(ax, title):
        ax.set_facecolor(DARK)
        ax.tick_params(colors=TEXT, labelsize=7)
        for sp in ax.spines.values(): sp.set_color('#333')
        ax.set_title(title, color=ACC, fontsize=8, pad=4)
        ax.xaxis.label.set_color(TEXT); ax.yaxis.label.set_color(TEXT)

    def _cbar(sc, ax, label):
        cb = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.04)
        cb.set_label(label, color=TEXT, fontsize=6)
        cb.ax.yaxis.set_tick_params(colors=TEXT, labelsize=5)

    def _map2d(ax, data, cmap, norm, label, title, dot_size=12):
        """Draw data as colored dots along the actual 2D contour shape."""
        sc = ax.scatter(m.cx, m.cy, c=data, cmap=cmap, norm=norm,
                        s=dot_size, linewidths=0)
        _cbar(sc, ax, label)
        ax.set_aspect('equal')
        ax.set_xlabel('x (mm)', fontsize=7)
        ax.set_ylabel('y (mm)', fontsize=7)
        _style(ax, title)
        return sc

    # ── Panel 0: Contour overlay on background frame ──────────────────────
    ax0 = fig.add_subplot(gs[0])
    if bg_frame is not None:
        ax0.imshow(bg_frame, cmap='gray', origin='upper', aspect='equal')
    # Draw contours in pixel coords
    ax0.plot(m.contour_rest_px[:, 0], m.contour_rest_px[:, 1],
             '-', color='#ff4444', lw=1.5, label='Rest', alpha=0.9)
    ax0.plot(m.contour_peak_px[:, 0], m.contour_peak_px[:, 1],
             '-', color='#4488ff', lw=1.5, label='Peak', alpha=0.9)
    ax0.legend(fontsize=7, facecolor='#1a1a1a', labelcolor=TEXT,
               loc='upper right')
    ax0.set_axis_off()
    _style(ax0, 'Contour  red=rest  blue=peak')

    # ── A: Radial displacement ────────────────────────────────────────────
    ax_a = fig.add_subplot(gs[1])
    vd = max(float(np.abs(m.radial_disp).max()), 0.1)
    _map2d(ax_a, m.radial_disp, 'RdBu_r', _safe_norm(vd),
           'Inward disp (px)\n+= contraction', 'A  Radial displacement')

    # ── B: Arc-length strain ──────────────────────────────────────────────
    ax_b = fig.add_subplot(gs[2])
    vs = max(float(np.abs(m.strain).max()), 0.1)
    _map2d(ax_b, m.strain, 'RdBu_r', _safe_norm(vs),
           'Arc-length strain (%)\n−= compression', 'B  Arc-length strain')

    # ── C: Δκ ─────────────────────────────────────────────────────────────
    ax_c = fig.add_subplot(gs[3])
    vk = max(float(np.abs(m.delta_kappa).max()), 0.01)
    _map2d(ax_c, m.delta_kappa, 'RdBu_r', _safe_norm(vk),
           'Δκ (mm⁻¹)\n+= more curved at peak', 'C  Δκ (MATLAB)')

    # ── D: Mechanical activation ──────────────────────────────────────────
    ax_d = fig.add_subplot(gs[4])
    if m.act_valid.any():
        act_plot = m.mech_act_ms.copy()
        act_plot[~m.act_valid] = np.nan
        sc_d = ax_d.scatter(m.cx[m.act_valid], m.cy[m.act_valid],
                            c=act_plot[m.act_valid],
                            cmap='jet', s=12, vmin=0, linewidths=0)
        _cbar(sc_d, ax_d, 'Activation (ms)')
        # Mark start/end
        valid_idx = np.where(m.act_valid)[0]
        ei = valid_idx[int(np.nanargmin(act_plot[m.act_valid]))]
        li = valid_idx[int(np.nanargmax(act_plot[m.act_valid]))]
        ax_d.scatter(m.cx[ei], m.cy[ei], marker='*', color='white',
                     s=180, zorder=5, label='Start',
                     edgecolors='black', linewidths=0.5)
        ax_d.scatter(m.cx[li], m.cy[li], marker='X', color='yellow',
                     s=120, zorder=5, label='End',
                     edgecolors='black', linewidths=0.5)
        ax_d.legend(fontsize=6, facecolor='#1a1a1a', labelcolor=TEXT)
        ax_d.set_aspect('equal')
        ax_d.set_xlabel('x (mm)', fontsize=7)
        ax_d.set_ylabel('y (mm)', fontsize=7)
    else:
        ax_d.text(0.5, 0.5, 'No activation\ndetected',
                  ha='center', va='center', color=TEXT,
                  transform=ax_d.transAxes, fontsize=8)
    _style(ax_d, 'D  Mech. activation  [*]=start  [x]=end')

    fig.suptitle(
        f'Contour-based mechanical maps  |  '
        f'rest={m.rest_idx}  peak={m.peak_idx}  '
        f'{m.fps:.0f} fps  {m.px_to_mm:.5f} mm/px',
        color=TEXT, fontsize=9, y=0.97)

    if save_path:
        fig.savefig(save_path, dpi=300, bbox_inches='tight', facecolor=DARK)
    return fig

    def _safe_norm(v, vcenter=0.0):
        vmin, vmax = -abs(v), abs(v)
        if vmin < vcenter < vmax:
            return TwoSlopeNorm(vmin=vmin, vcenter=vcenter, vmax=vmax)
        lo = min(vmin, vcenter) - 1e-6
        hi = max(vmax, vcenter) + 1e-6
        return Normalize(vmin=lo, vmax=hi)

    DARK = '#0d0d0d'; TEXT = '#e8e8e8'; ACC = '#00d4ff'

    fig = plt.figure(figsize=(18, 4.5), facecolor=DARK)
    gs  = gridspec.GridSpec(1, 5, figure=fig,
                            wspace=0.38, left=0.04, right=0.97,
                            top=0.88, bottom=0.12)

    def _style(ax, title):
        ax.set_facecolor(DARK)
        ax.tick_params(colors=TEXT, labelsize=7)
        for sp in ax.spines.values(): sp.set_color('#333')
        ax.set_title(title, color=ACC, fontsize=8, pad=4)
        ax.xaxis.label.set_color(TEXT); ax.yaxis.label.set_color(TEXT)

    def _cbar(sc, ax, label):
        cb = fig.colorbar(sc, ax=ax, fraction=0.046, pad=0.04)
        cb.set_label(label, color=TEXT, fontsize=6)
        cb.ax.yaxis.set_tick_params(colors=TEXT, labelsize=5)

    # Contour scatter helper (polar-ish: arc_s as x)
    def _contour_scatter(ax, data, cmap, norm, label, title):
        sc = ax.scatter(m.arc_s, np.zeros_like(m.arc_s),
                        c=data, cmap=cmap, norm=norm, s=8, zorder=3)
        _cbar(sc, ax, label)
        ax.set_xlabel('Arc-length (mm)', fontsize=7)
        ax.set_yticks([])
        _style(ax, title)
        return sc

    # ── Panel 0: Contour overlay ──────────────────────────────────────────
    ax0 = fig.add_subplot(gs[0])
    if bg_frame is not None:
        ax0.imshow(bg_frame, cmap='gray', origin='upper', aspect='equal')
    ax0.plot(m.contour_rest_px[:, 0], m.contour_rest_px[:, 1],
             '-', color='#ff4444', lw=1.5, label='Rest', alpha=0.9)
    ax0.plot(m.contour_peak_px[:, 0], m.contour_peak_px[:, 1],
             '-', color='#4488ff', lw=1.5, label='Peak', alpha=0.9)
    ax0.legend(fontsize=7, facecolor='#1a1a1a', labelcolor=TEXT,
               loc='upper right')
    ax0.set_axis_off()
    _style(ax0, 'Contour  red=rest  blue=peak')

    # ── A: Radial displacement ────────────────────────────────────────────
    ax_a = fig.add_subplot(gs[1])
    vd = max(np.abs(m.radial_disp).max(), 0.1)
    norm_a = _safe_norm(vd)
    sc_a = ax_a.scatter(m.arc_s, np.zeros_like(m.arc_s),
                        c=m.radial_disp, cmap='RdBu_r', norm=norm_a, s=8)
    _cbar(sc_a, ax_a, 'Inward disp (px)\n+= contraction')
    ax_a.set_xlabel('Arc-length (mm)', fontsize=7)
    ax_a.set_yticks([])
    _style(ax_a, 'A  Radial displacement')

    # ── B: Strain ─────────────────────────────────────────────────────────
    ax_b = fig.add_subplot(gs[2])
    vs = max(np.abs(m.strain).max(), 0.1)
    norm_b = _safe_norm(vs)
    sc_b = ax_b.scatter(m.arc_s, np.zeros_like(m.arc_s),
                        c=m.strain, cmap='RdBu_r', norm=norm_b, s=8)
    _cbar(sc_b, ax_b, 'Arc-length strain (%)\n−= compression')
    ax_b.set_xlabel('Arc-length (mm)', fontsize=7)
    ax_b.set_yticks([])
    _style(ax_b, 'B  Arc-length strain')

    # ── C: Δκ ─────────────────────────────────────────────────────────────
    ax_c = fig.add_subplot(gs[3])
    vk = max(np.abs(m.delta_kappa).max(), 0.01)
    norm_c = _safe_norm(vk)
    sc_c = ax_c.scatter(m.arc_s, np.zeros_like(m.arc_s),
                        c=m.delta_kappa, cmap='RdBu_r', norm=norm_c, s=8)
    _cbar(sc_c, ax_c, 'Δκ (mm⁻¹)\n+= more curved at peak')
    ax_c.set_xlabel('Arc-length (mm)', fontsize=7)
    ax_c.set_yticks([])
    _style(ax_c, 'C  Δκ curvature change  (MATLAB)')

    # ── D: Mechanical activation ──────────────────────────────────────────
    ax_d = fig.add_subplot(gs[4])
    if m.act_valid.any():
        act_plot = m.mech_act_ms.copy()
        act_plot[~m.act_valid] = np.nan
        sc_d = ax_d.scatter(m.arc_s[m.act_valid],
                            np.zeros(m.act_valid.sum()),
                            c=act_plot[m.act_valid],
                            cmap='jet', s=8, vmin=0)
        _cbar(sc_d, ax_d, 'Activation time (ms)')

        # Mark earliest / latest
        earliest_i = int(np.nanargmin(act_plot))
        latest_i   = int(np.nanargmax(act_plot))
        for i, mk, col, lbl in [(earliest_i, '*', 'white', 'Start'),
                                  (latest_i,  'X', 'yellow', 'End')]:
            ax_d.scatter(m.arc_s[i], 0, marker=mk, color=col,
                         s=120, zorder=5, label=lbl,
                         edgecolors='black', linewidths=0.5)
        ax_d.legend(fontsize=6, facecolor='#1a1a1a', labelcolor=TEXT)
    else:
        ax_d.text(0.5, 0.5, 'No activation\ndetected',
                  ha='center', va='center', color=TEXT,
                  transform=ax_d.transAxes, fontsize=8)
    ax_d.set_xlabel('Arc-length (mm)', fontsize=7)
    ax_d.set_yticks([])
    _style(ax_d, 'D  Mechanical activation  [*]=start  [x]=end')

    fig.suptitle(
        f'Contour-based mechanical maps  |  '
        f'rest={m.rest_idx}  peak={m.peak_idx}  '
        f'{m.fps:.0f} fps  {m.px_to_mm:.4f} mm/px',
        color=TEXT, fontsize=9, y=0.97)

    if save_path:
        fig.savefig(save_path, dpi=300, bbox_inches='tight', facecolor=DARK)
    return fig
