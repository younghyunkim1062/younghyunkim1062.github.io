"""
core/cellpose_detector.py
─────────────────────────────────────────────────────────────────────────────
Cellpose 기반 자동 ROI 감지 모듈 for iCAMAnalyzer v5
─────────────────────────────────────────────────────────────────────────────

설계 원칙:
  - Cellpose 설치 여부와 무관하게 import 가능
  - 미설치 시 → CLAHE+Otsu adaptive CV fallback 자동 사용
  - GUI는 항상 동일한 인터페이스(roi dict 리스트)를 받음

Brightfield 특성:
  - 배경 밝음, organoid 어둡거나 회색
  - Cellpose: cyto3 모델, invert=True (밝은 배경 보정)

피드백 저장:
  - save_feedback() / load_feedback() → <video>.roi_feedback.json
  - 사용자가 수동으로 수정한 ROI를 저장 → 다음 실행 시 자동 로드
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Optional

import cv2
import numpy as np

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────────────────────────────────────
#  Cellpose 가용성 체크 (import 실패해도 모듈 로드는 성공)
# ─────────────────────────────────────────────────────────────────────────────

_CELLPOSE_AVAILABLE = False

def _try_import_cellpose() -> bool:
    global _CELLPOSE_AVAILABLE
    try:
        from cellpose import models as _cp_models  # noqa: F401
        _CELLPOSE_AVAILABLE = True
        logger.info("Cellpose available.")
    except ImportError:
        _CELLPOSE_AVAILABLE = False
        logger.info("Cellpose not installed — adaptive CV fallback will be used.")
    return _CELLPOSE_AVAILABLE

_try_import_cellpose()


def cellpose_available() -> bool:
    return _CELLPOSE_AVAILABLE


# ─────────────────────────────────────────────────────────────────────────────
#  Cellpose 모델 (lazy singleton — 처음 한 번만 로드)
# ─────────────────────────────────────────────────────────────────────────────

_cp_model_cache: dict = {}

def _get_cellpose_model(model_type: str = "cyto3"):
    if model_type in _cp_model_cache:
        return _cp_model_cache[model_type]
    try:
        from cellpose import models
        m = models.Cellpose(model_type=model_type, gpu=False)
        _cp_model_cache[model_type] = m
        logger.info(f"Cellpose model loaded: {model_type}")
        return m
    except Exception as e:
        logger.error(f"Cellpose model load failed: {e}")
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  Cellpose 감지
# ─────────────────────────────────────────────────────────────────────────────

def detect_rois_cellpose(frame_bgr: np.ndarray,
                          max_rois: int = 9,
                          diameter: Optional[float] = None,
                          model_type: str = "cyto3",
                          min_area_frac: float = 0.001,
                          max_area_frac: float = 0.80,
                          ) -> list[dict]:
    """
    Cellpose로 organoid ROI 감지.
    diameter=None 이면 Cellpose가 자동 추정 (권장).
    """
    model = _get_cellpose_model(model_type)
    if model is None:
        return []

    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    H, W = gray.shape
    total = H * W

    # Brightfield: 배경 밝음 → invert=True 로 어두운 organoid를 전경으로
    try:
        masks, flows, styles, diams = model.eval(
            gray,
            diameter=diameter,
            channels=[0, 0],   # grayscale
            invert=True,       # brightfield 보정
            flow_threshold=0.4,
            cellprob_threshold=0.0,
        )
    except Exception as e:
        logger.error(f"Cellpose eval failed: {e}")
        return []

    rois = []
    cell_ids = np.unique(masks)
    cell_ids = cell_ids[cell_ids != 0]  # 배경(0) 제외

    # 면적 내림차순 정렬
    cell_areas = [(cid, np.sum(masks == cid)) for cid in cell_ids]
    cell_areas.sort(key=lambda x: x[1], reverse=True)

    for cid, area in cell_areas:
        frac = area / total
        if not (min_area_frac <= frac <= max_area_frac):
            continue
        # mask → contour
        cell_mask = (masks == cid).astype(np.uint8) * 255
        cnts, _ = cv2.findContours(cell_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if not cnts:
            continue
        c = max(cnts, key=cv2.contourArea)
        x, y, w, h = cv2.boundingRect(c)
        rois.append({"box": (x, y, w, h), "contour": c})
        if len(rois) >= max_rois:
            break

    return rois


# ─────────────────────────────────────────────────────────────────────────────
#  Adaptive CV fallback (CLAHE + Otsu) — Cellpose 없을 때
# ─────────────────────────────────────────────────────────────────────────────

def detect_rois_cv(frame_bgr: np.ndarray,
                   threshold: int = 60,
                   max_rois: int = 9,
                   min_solidity: float = 0.5,
                   min_ar: float = 0.3,
                   max_ar: float = 3.0,
                   min_area_frac: float = 0.001,
                   max_area_frac: float = 0.80) -> list[dict]:
    """
    CLAHE + Otsu adaptive threshold 기반 ROI 감지.
    threshold 파라미터는 Otsu 자동값의 오프셋으로 사용 (미세 조정용).
    """
    gray = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2GRAY)
    clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
    enhanced = clahe.apply(gray)
    blur = cv2.GaussianBlur(enhanced, (11, 11), 0)

    otsu_val, _ = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    # 슬라이더 값을 오프셋으로 반영 (기본값 60 기준, ±조정)
    adjusted = max(10, min(240, otsu_val + (threshold - 60)))
    _, th = cv2.threshold(blur, adjusted, 255, cv2.THRESH_BINARY_INV)

    kernel = np.ones((5, 5), np.uint8)
    th = cv2.morphologyEx(th, cv2.MORPH_OPEN,  kernel, iterations=2)
    th = cv2.morphologyEx(th, cv2.MORPH_CLOSE, kernel, iterations=1)

    cnts, _ = cv2.findContours(th, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    H, W = gray.shape
    total = H * W
    valid = []

    if cnts:
        cnts = sorted(cnts, key=cv2.contourArea, reverse=True)
        for c in cnts:
            area = cv2.contourArea(c)
            frac = area / total
            if not (min_area_frac <= frac <= max_area_frac):
                continue
            hull_area = cv2.contourArea(cv2.convexHull(c))
            if hull_area <= 0:
                continue
            solidity = area / hull_area
            x, y, w, h = cv2.boundingRect(c)
            ar = w / max(h, 1)
            if solidity >= min_solidity and min_ar <= ar <= max_ar:
                valid.append({"box": (x, y, w, h), "contour": c})
            if len(valid) >= max_rois:
                break
    return valid


# ─────────────────────────────────────────────────────────────────────────────
#  메인 감지 함수
# ─────────────────────────────────────────────────────────────────────────────

def detect_rois_auto(frame_bgr: np.ndarray,
                     use_cellpose: bool = True,
                     threshold: int = 60,
                     max_rois: int = 9,
                     min_solidity: float = 0.5,
                     min_ar: float = 0.3,
                     max_ar: float = 3.0,
                     min_area_frac: float = 0.001,
                     max_area_frac: float = 0.80,
                     cellpose_diameter: Optional[float] = None,
                     ) -> tuple[list[dict], str]:
    """
    Returns: (rois, method)
      method: "cellpose" | "adaptive_cv" | "cv_manual"
    """
    if use_cellpose and _CELLPOSE_AVAILABLE:
        rois = detect_rois_cellpose(
            frame_bgr,
            max_rois=max_rois,
            diameter=cellpose_diameter,
            min_area_frac=min_area_frac,
            max_area_frac=max_area_frac,
        )
        if rois:
            return rois, "cellpose"
        logger.info("Cellpose returned no ROIs — falling back to adaptive CV.")

    # CV fallback (수동 모드 or Cellpose 실패)
    rois = detect_rois_cv(
        frame_bgr,
        threshold=threshold,
        max_rois=max_rois,
        min_solidity=min_solidity,
        min_ar=min_ar,
        max_ar=max_ar,
        min_area_frac=min_area_frac,
        max_area_frac=max_area_frac,
    )
    method = "cv_manual" if not use_cellpose else "adaptive_cv"
    return rois, method


# ─────────────────────────────────────────────────────────────────────────────
#  시각화
# ─────────────────────────────────────────────────────────────────────────────

_METHOD_COLORS = {
    "cellpose":    (0, 200, 80),
    "adaptive_cv": (200, 150, 0),
    "cv_manual":   (180, 100, 0),
    "saved":       (0, 120, 255),
}

def draw_roi_annotations(frame_bgr: np.ndarray,
                          rois: list[dict],
                          method: str = "") -> np.ndarray:
    vis = frame_bgr.copy()
    label_color = _METHOD_COLORS.get(method, (200, 200, 200))
    label_text = {
        "cellpose":    "AI: Cellpose",
        "adaptive_cv": "Auto CV (fallback)",
        "cv_manual":   "Manual CV",
        "saved":       "Saved ROI",
    }.get(method, method)

    cv2.putText(vis, label_text, (10, 26),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, label_color, 2)

    for i, roi in enumerate(rois):
        x, y, w, h = roi["box"]
        cnt = roi.get("contour")
        if cnt is not None:
            cv2.drawContours(vis, [cnt], -1, (0, 0, 255), 2)
        cv2.rectangle(vis, (x, y), (x + w, y + h), (0, 255, 0), 2)
        cv2.putText(vis, f"ROI {i+1}", (x, max(y - 8, 10)),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)
        M = cv2.moments(cnt) if cnt is not None else None
        if M and M["m00"] > 0:
            ccx, ccy = int(M["m10"] / M["m00"]), int(M["m01"] / M["m00"])
        else:
            ccx, ccy = x + w // 2, y + h // 2
        arm = 18
        cv2.line(vis, (ccx - arm, ccy), (ccx + arm, ccy), (0, 165, 255), 2)
        cv2.line(vis, (ccx, ccy - arm), (ccx, ccy + arm), (0, 165, 255), 2)
        cv2.circle(vis, (ccx, ccy), 5, (0, 165, 255), -1)

    return vis


# ─────────────────────────────────────────────────────────────────────────────
#  피드백 저장 / 불러오기
# ─────────────────────────────────────────────────────────────────────────────

def _roi_to_json(roi: dict) -> dict:
    d = {"box": list(roi["box"])}
    if roi.get("contour") is not None:
        d["contour"] = roi["contour"].tolist()
    return d

def _roi_from_json(d: dict) -> dict:
    roi = {"box": tuple(d["box"])}
    if d.get("contour") is not None:
        roi["contour"] = np.array(d["contour"], dtype=np.int32)
    return roi

def save_feedback(video_path: str, rois: list[dict], method: str = "") -> str:
    json_path = Path(video_path).with_suffix(".roi_feedback.json")
    data = {
        "video": str(video_path),
        "method": method,
        "rois": [_roi_to_json(r) for r in rois],
    }
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    logger.info(f"ROI feedback saved -> {json_path}")
    return str(json_path)

def load_feedback(video_path: str) -> Optional[list[dict]]:
    json_path = Path(video_path).with_suffix(".roi_feedback.json")
    if not json_path.exists():
        return None
    try:
        with open(json_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        rois = [_roi_from_json(r) for r in data.get("rois", [])]
        logger.info(f"ROI feedback loaded <- {json_path} ({len(rois)} ROIs)")
        return rois
    except Exception as e:
        logger.warning(f"ROI feedback load failed: {e}")
        return None
