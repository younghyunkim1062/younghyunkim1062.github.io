"""
core/signal_processing.py
Ca2+ transient kinetics analysis — ported from iCAMAnalyzer.m (Section 1)
"""

import numpy as np
from scipy.signal import savgol_filter, find_peaks
from scipy.optimize import curve_fit
from dataclasses import dataclass, field
from typing import Optional
import warnings


# ─────────────────────────────────────────────
#  Data containers
# ─────────────────────────────────────────────

@dataclass
class BeatParams:
    beat:   int
    ibi_ms: float
    amp:    float
    ttp_ms: float
    ctd60_ms: float
    ctd90_ms: float
    tau_ms: float
    ead_detected:       bool  = False
    ead_timing_ms:      float = np.nan
    dad_detected:       bool  = False   # inter-beat extra depolarization
    dad_timing_ms:      float = np.nan
    triggered_activity: bool  = False   # EAD/DAD → consecutive short IBI


@dataclass
class AlternansResult:
    """
    Beat-to-beat Ca2+ alternans quantification.
    AI = |mean_odd - mean_even| / (mean_odd + mean_even), range 0-0.5
    AI > 0.10 considered significant (Weiss et al. Circ Res 2006).
    """
    amp_ai:        float
    amp_odd_mean:  float
    amp_even_mean: float
    amp_ratio:     float
    amp_alternans: bool

    dur_ai:        float
    dur_odd_mean:  float
    dur_even_mean: float
    dur_ratio:     float
    dur_alternans: bool

    odd_amps:   np.ndarray = field(default_factory=lambda: np.array([]))
    even_amps:  np.ndarray = field(default_factory=lambda: np.array([]))
    odd_ctd90s: np.ndarray = field(default_factory=lambda: np.array([]))
    even_ctd90s:np.ndarray = field(default_factory=lambda: np.array([]))
    n_pairs:    int = 0
    ai_threshold: float = 0.10


@dataclass
class KineticsResult:
    bpm:        float
    amp_mean:   float;  amp_sd:    float
    ttp_mean:   float;  ttp_sd:    float
    ctd60_mean: float;  ctd60_sd:  float
    ctd90_mean: float;  ctd90_sd:  float
    tau_ms:     float
    vmax:       float;  vrelax:    float
    vmax_norm:  float;  vrelax_norm: float
    ttp_ctd90_ratio: float
    n_beats:    int
    cv_mm_s:    Optional[float] = None
    max_delay_ms: Optional[float] = None

    beat_to_beat:   list = field(default_factory=list)
    avg_time:       np.ndarray = field(default_factory=lambda: np.array([]))
    avg_signal:     np.ndarray = field(default_factory=lambda: np.array([]))
    all_transients: np.ndarray = field(default_factory=lambda: np.array([]))
    alternans:      Optional["AlternansResult"] = None

    # Beat irregularity (arrhythmia burden)
    ibi_cv_pct:     float = np.nan   # CV% of IBI = SD/mean × 100
    ibi_mean_ms:    float = np.nan
    ibi_sd_ms:      float = np.nan
    irregular_beat_pct: float = np.nan  # % beats with IBI < mean-2SD or > mean+2SD

    # DAD summary
    n_dad_beats:    int   = 0
    dad_beat_pct:   float = np.nan

    # Triggered activity summary
    n_triggered:    int   = 0


# ─────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────

def safe_sg(x: np.ndarray, deg: int = 3, win: int = 11) -> np.ndarray:
    """Savitzky-Golay with automatic window clamping (prevents crash at low fps)."""
    x = np.asarray(x, dtype=float).ravel()
    n = len(x)
    win = max(deg + 2, round(win))
    if win % 2 == 0:
        win += 1
    max_odd = n if n % 2 == 1 else n - 1
    win = min(win, max_odd)
    if win < deg + 2 or n < deg + 2:
        return x.copy()
    return savgol_filter(x, win, deg)


def _safe_interp(v_in: np.ndarray, t_in: np.ndarray, target: float) -> float:
    """Linear interpolation with unique-value guard."""
    u_v, ia = np.unique(v_in, return_index=True)
    if len(u_v) < 2:
        return np.nan
    return float(np.interp(target, u_v, t_in[ia]))


def _fit_exponential(t: np.ndarray, y: np.ndarray):
    """Fit A*exp(k*t) + C; returns (A, k, C) or raises."""
    def model(x, A, k, C):
        return A * np.exp(k * x) + C
    p0 = [y[0] - y[-1], -5.0, y[-1]]
    popt, _ = curve_fit(model, t - t[0], y, p0=p0,
                        bounds=([-np.inf, -np.inf, -np.inf],
                                [np.inf, 0, np.inf]),
                        maxfev=5000)
    return popt


# ─────────────────────────────────────────────
#  Main analysis
# ─────────────────────────────────────────────

def analyze_transient(signal: np.ndarray, fps: float) -> KineticsResult:
    """
    Full Ca2+ transient kinetics analysis.

    Parameters
    ----------
    signal : 1-D array of raw fluorescence intensity
    fps    : frames per second

    Returns
    -------
    KineticsResult dataclass
    """
    signal = np.asarray(signal, dtype=float).ravel()
    frames = np.arange(len(signal))
    time_vec = frames / fps

    # ── 1. dF/F0 normalisation ──────────────────
    sorted_y = np.sort(signal)
    n10 = max(1, round(len(sorted_y) * 0.10))
    baseline_raw = np.mean(sorted_y[:n10])
    if baseline_raw <= 0:
        pos = signal[signal > 0]
        baseline_raw = float(np.min(pos)) if len(pos) else float(np.min(signal))
    if np.isnan(baseline_raw):
        baseline_raw = float(np.min(signal))

    dff_raw    = (signal - baseline_raw) / baseline_raw
    dff_smooth = safe_sg(dff_raw, 3, 11)

    # ── 2. FFT-adaptive peak detection ──────────
    L    = len(dff_smooth)
    Y    = np.fft.rfft(dff_smooth - np.mean(dff_smooth))
    P    = np.abs(Y) / L
    P[1:-1] *= 2
    freq = np.fft.rfftfreq(L, d=1.0 / fps)

    valid = (freq >= 0.5) & (freq <= 4.0)
    if valid.any():
        dom_freq = freq[valid][np.argmax(P[valid])]
        dom_freq = dom_freq if dom_freq > 0 else 0
    else:
        dom_freq = 0

    if dom_freq > 0:
        beat_period = fps / dom_freq
        adaptive_dist = round(beat_period * 0.65)
    else:
        adaptive_dist = round(fps * 0.4)
    adaptive_dist = max(adaptive_dist, 1)

    # ── 3. Derivative peak detection ────────────
    dy_dt     = np.append(np.diff(dff_smooth), 0) * fps
    win_dy    = 2 * int(fps * 0.03) + 1
    dy_filt   = safe_sg(dy_dt, 3, win_dy)

    min_height = 0.20 * np.max(dy_filt)
    min_prom   = 0.15 * np.max(dy_filt)

    locs_dy, _ = find_peaks(dy_filt,
                             height=min_height,
                             prominence=min_prom,
                             distance=adaptive_dist)

    if len(locs_dy) == 0:
        raise ValueError("No peaks detected — check FPS or signal quality.")

    # ── 4. Segment & ensemble ───────────────────
    pre_offset = round(0.1 * fps)
    transients = []
    beat_params: list[BeatParams] = []

    beat_period_frames = int(fps / dom_freq) if dom_freq > 0 else int(fps * 1.0)

    for i in range(len(locs_dy) - 1):
        idx1 = max(0, locs_dy[i] - pre_offset)

        # Extend segment to cover full decay for EAD detection
        next_onset = locs_dy[i + 1] - pre_offset - 1
        ead_window = locs_dy[i] + int(beat_period_frames * 1.1)
        idx2       = min(next_onset, ead_window, len(signal) - 1)

        if idx2 <= idx1:
            continue

        seg   = signal[idx1:idx2]
        t_seg = np.arange(len(seg)) / fps - pre_offset / fps
        seg_s = safe_sg(seg, 3, min(21, 2 * (len(seg) // 4) * 2 + 1))
        pidx_i = int(np.argmax(seg_s))
        fmax_i = seg_s[pidx_i]

        # ── Baseline: exponential asymptote (most accurate)
        # Fit decay to A*exp(k*t)+C; C = true asymptotic baseline
        # Falls back to 10th-percentile if fit fails
        bl_i = np.nan
        try:
            decay_seg = seg_s[pidx_i:].copy()
            t_decay   = np.arange(len(decay_seg)) / fps
            popt_bl   = _fit_exponential(t_decay, decay_seg)
            bl_i      = float(popt_bl[2])    # C term = asymptote
            # Sanity check: asymptote must be below peak and above zero
            if not (0 < bl_i < fmax_i * 0.8):
                raise ValueError("asymptote out of range")
        except Exception:
            # Fallback: 10th percentile of whole signal
            bl_i = float(np.percentile(signal, 10))

        amp_i = (fmax_i - bl_i) / (bl_i + 1e-9)

        # TTP
        try:
            ttp_i = (_safe_interp(seg_s[:pidx_i + 1], t_seg[:pidx_i + 1],
                                  bl_i + 0.1 * (fmax_i - bl_i))
                     - t_seg[pidx_i]) * -1000
        except Exception:
            ttp_i = np.nan

        # CTD60 / CTD90 with asymptote-corrected baseline
        ctd60_i = ctd90_i = np.nan
        try:
            t2 = t_seg[pidx_i:]
            y2 = seg_s[pidx_i:]
            ctd60_i = (_safe_interp(y2, t2, bl_i + 0.4 * (fmax_i - bl_i))
                       - t2[0] + ttp_i / 1000) * 1000
            ctd90_i = (_safe_interp(y2, t2, bl_i + 0.1 * (fmax_i - bl_i))
                       - t2[0] + ttp_i / 1000) * 1000
        except Exception:
            pass

        # Tau
        tau_i = np.nan
        try:
            dy   = seg_s[pidx_i:]
            dt2  = np.arange(len(dy)) / fps
            popt = _fit_exponential(dt2, dy)
            tau_i = (-1.0 / popt[1]) * 1000
        except Exception:
            pass

        ibi_i = (time_vec[locs_dy[i + 1]] - time_vec[locs_dy[i]]) * 1000
        transients.append(seg)
        beat_params.append(BeatParams(
            beat=i + 1, ibi_ms=ibi_i, amp=amp_i,
            ttp_ms=ttp_i, ctd60_ms=ctd60_i, ctd90_ms=ctd90_i, tau_ms=tau_i
        ))

    if not transients:
        raise ValueError("No valid beat segments found.")

    # ── 5. Ensemble average ──────────────────────
    min_len = min(len(s) for s in transients)
    all_t   = np.vstack([s[:min_len] for s in transients])
    avg     = np.mean(all_t, axis=0)
    t_avg   = (np.arange(min_len) - pre_offset) / fps

    # Baseline from exponential asymptote of ensemble average
    try:
        decay_avg = avg[p_idx:].copy()
        t_decay_avg = np.arange(len(decay_avg)) / fps
        popt_ens = _fit_exponential(t_decay_avg, decay_avg)
        baseline = float(popt_ens[2])
        if not (0 < baseline < np.max(avg) * 0.8):
            raise ValueError("out of range")
    except Exception:
        baseline = float(np.percentile(avg, 10))
    p_idx    = int(np.argmax(avg))
    f_max    = avg[p_idx]

    norm_amp   = (f_max - baseline) / baseline
    avg_norm   = (avg - baseline) / baseline
    dt         = 1.0 / fps

    t10_on  = _safe_interp(avg[:p_idx + 1], t_avg[:p_idx + 1],
                            baseline + 0.1 * (f_max - baseline))
    t40_off = _safe_interp(avg[p_idx:], t_avg[p_idx:],
                            baseline + 0.4 * (f_max - baseline))
    t10_off = _safe_interp(avg[p_idx:], t_avg[p_idx:],
                            baseline + 0.1 * (f_max - baseline))

    ttp    = (t_avg[p_idx] - t10_on) * 1000
    ctd60  = (t40_off - t10_on) * 1000
    ctd90  = (t10_off - t10_on) * 1000

    max_vel       = np.max(np.diff(avg_norm[:p_idx + 1]) / dt)
    max_relax_vel = abs(np.min(np.diff(avg_norm[p_idx:]) / dt))
    vmax_norm_val  = max_vel / (norm_amp + 1e-9)
    vrelax_norm_val = max_relax_vel / (norm_amp + 1e-9)

    if len(locs_dy) >= 2:
        bpm = (len(locs_dy) - 1) / (time_vec[locs_dy[-1]] - time_vec[locs_dy[0]]) * 60
    else:
        bpm = 60.0 / np.mean(np.diff(time_vec[locs_dy]))

    # Tau (ensemble)
    tau_ens = np.nan
    try:
        decay_t = t_avg[p_idx:].copy()
        decay_y = avg[p_idx:].copy()
        popt = _fit_exponential(decay_t, decay_y)
        tau_ens = (-1.0 / popt[1]) * 1000
    except Exception:
        pass

    # ── 6. Beat-to-beat stats ────────────────────
    valid_mask = np.array([not (np.isnan(b.ttp_ms) or np.isnan(b.ctd90_ms))
                           for b in beat_params])

    def _nanmean(arr): return float(np.nanmean(arr)) if len(arr) else np.nan
    def _nanstd(arr):  return float(np.nanstd(arr))  if len(arr) else np.nan

    amps  = [b.amp    for b in beat_params if not np.isnan(b.amp)]
    ttps  = [b.ttp_ms for i, b in enumerate(beat_params) if valid_mask[i]]
    c60s  = [b.ctd60_ms for i, b in enumerate(beat_params) if valid_mask[i]]
    c90s  = [b.ctd90_ms for i, b in enumerate(beat_params) if valid_mask[i]]

    ratio = _nanmean(ttps) / (_nanmean(c90s) + 1e-9)

    # ── 7. EAD detection ────────────────────────
    # Detect secondary depolarization during decay phase.
    # Segment already extended to cover full decay (Step 4).
    for i, seg in enumerate(transients):
        if len(seg) < 10:
            continue
        seg_s2 = safe_sg(seg.astype(float), 3,
                         min(21, 2 * (len(seg) // 6) * 2 + 1))
        pidx2  = int(np.argmax(seg_s2))
        decay2 = seg_s2[pidx2:]
        if len(decay2) < 5:
            continue
        d_range = np.max(decay2) - np.min(decay2)

        # Lower thresholds vs. original (3% height, 5% prominence)
        # to catch physiologically realistic EADs (~10-20% of peak)
        ead_pks, _ = find_peaks(
            decay2,
            height=np.max(decay2) * 0.03,
            prominence=d_range * 0.05,
            distance=round(fps * 0.04),   # min 40 ms between EAD peaks
        )
        if len(ead_pks) > 0 and i < len(beat_params):
            beat_params[i].ead_detected  = True
            beat_params[i].ead_timing_ms = (ead_pks[0] + pidx2) / fps * 1000

    # ── 8. Smooth avg for export ─────────────────
    smooth_avg_norm = safe_sg(avg_norm, 3, 15)
    all_transients_norm = ((all_t - baseline) / baseline)

    return KineticsResult(
        bpm=bpm,
        amp_mean=_nanmean(amps),  amp_sd=_nanstd(amps),
        ttp_mean=_nanmean(ttps),  ttp_sd=_nanstd(ttps),
        ctd60_mean=_nanmean(c60s), ctd60_sd=_nanstd(c60s),
        ctd90_mean=_nanmean(c90s), ctd90_sd=_nanstd(c90s),
        tau_ms=tau_ens,
        vmax=max_vel, vrelax=max_relax_vel,
        vmax_norm=vmax_norm_val, vrelax_norm=vrelax_norm_val,
        ttp_ctd90_ratio=ratio,
        n_beats=int(valid_mask.sum()),
        beat_to_beat=beat_params,
        avg_time=t_avg,
        avg_signal=smooth_avg_norm,
        all_transients=all_transients_norm,
    )


# ─────────────────────────────────────────────
#  Alternans analysis (separate function)
# ─────────────────────────────────────────────

def analyze_alternans(
    result: KineticsResult,
    ai_threshold: float = 0.10,
    min_pairs: int = 3,
) -> AlternansResult:
    """
    Quantify beat-to-beat Ca2+ alternans from a KineticsResult.

    Requires at least min_pairs*2 valid beats.

    Parameters
    ----------
    result       : KineticsResult from analyze_transient()
    ai_threshold : AI > this → alternans flag  (default 0.10)
    min_pairs    : minimum odd/even pairs required

    Returns
    -------
    AlternansResult with amplitude and duration alternans indices.

    Method
    ------
    Beats are split into odd (1,3,5,...) and even (2,4,6,...) groups.
    For each group the mean amplitude and CTD90 are computed.

    Alternans Index (AI):
        AI = |mean_odd - mean_even| / (mean_odd + mean_even)

    This is identical to the sMAPE-based metric used by COSMAS
    (Tomek et al. Sci Rep 2021) applied at the trace level.

    Reference:
        Weiss JN et al. Circ Res 2006;98:1244-1253.
        Tomek J et al. Sci Rep 2021;11:9147.
    """
    beats = result.beat_to_beat
    if len(beats) < min_pairs * 2:
        raise ValueError(
            f"Need ≥{min_pairs * 2} beats for alternans analysis "
            f"(got {len(beats)})"
        )

    # ── Filter valid beats (non-NaN amp AND ctd90)
    valid = [
        b for b in beats
        if not (np.isnan(b.amp) or np.isnan(b.ctd90_ms))
    ]
    if len(valid) < min_pairs * 2:
        raise ValueError(
            f"Too few valid beats after NaN filter "
            f"({len(valid)} < {min_pairs * 2})"
        )

    # ── Split odd / even (1-indexed beat number)
    odd_beats  = [b for b in valid if b.beat % 2 == 1]
    even_beats = [b for b in valid if b.beat % 2 == 0]

    n_pairs = min(len(odd_beats), len(even_beats))
    odd_beats  = odd_beats[:n_pairs]
    even_beats = even_beats[:n_pairs]

    odd_amps   = np.array([b.amp      for b in odd_beats])
    even_amps  = np.array([b.amp      for b in even_beats])
    odd_ctd90s = np.array([b.ctd90_ms for b in odd_beats])
    even_ctd90s= np.array([b.ctd90_ms for b in even_beats])

    # ── Amplitude alternans
    amp_odd_mean  = float(np.mean(odd_amps))
    amp_even_mean = float(np.mean(even_amps))
    denom_amp     = amp_odd_mean + amp_even_mean
    amp_ai        = abs(amp_odd_mean - amp_even_mean) / denom_amp if denom_amp > 0 else 0.0
    amp_ratio     = amp_odd_mean / amp_even_mean if amp_even_mean > 0 else np.nan

    # ── Duration alternans (CTD90)
    dur_odd_mean  = float(np.mean(odd_ctd90s))
    dur_even_mean = float(np.mean(even_ctd90s))
    denom_dur     = dur_odd_mean + dur_even_mean
    dur_ai        = abs(dur_odd_mean - dur_even_mean) / denom_dur if denom_dur > 0 else 0.0
    dur_ratio     = dur_odd_mean / dur_even_mean if dur_even_mean > 0 else np.nan

    alt_result = AlternansResult(
        amp_ai        = amp_ai,
        amp_odd_mean  = amp_odd_mean,
        amp_even_mean = amp_even_mean,
        amp_ratio     = amp_ratio,
        amp_alternans = amp_ai > ai_threshold,

        dur_ai        = dur_ai,
        dur_odd_mean  = dur_odd_mean,
        dur_even_mean = dur_even_mean,
        dur_ratio     = dur_ratio,
        dur_alternans = dur_ai > ai_threshold,

        odd_amps      = odd_amps,
        even_amps     = even_amps,
        odd_ctd90s    = odd_ctd90s,
        even_ctd90s   = even_ctd90s,
        n_pairs       = n_pairs,
        ai_threshold  = ai_threshold,
    )

    # Attach to result in-place
    result.alternans = alt_result
    return alt_result


# ─────────────────────────────────────────────
#  Beat Irregularity (IBI CV%)
# ─────────────────────────────────────────────

def analyze_beat_irregularity(result: KineticsResult,
                               outlier_sd: float = 2.0) -> dict:
    """
    Quantify beat-to-beat interval variability (arrhythmia burden).

    Parameters
    ----------
    result      : KineticsResult from analyze_transient()
    outlier_sd  : beats with IBI > mean ± outlier_sd*SD are irregular

    Returns
    -------
    dict with ibi_cv_pct, ibi_mean_ms, ibi_sd_ms, irregular_beat_pct

    Clinical reference
    ------------------
    CV% > 15% considered arrhythmic in hiPSC-CM studies
    (Sala et al. Stem Cell Rep 2018; Ahola et al. 2018)
    """
    ibis = np.array([b.ibi_ms for b in result.beat_to_beat
                     if not np.isnan(b.ibi_ms)])
    if len(ibis) < 3:
        return {}

    mean_ibi = float(np.mean(ibis))
    sd_ibi   = float(np.std(ibis))
    cv_pct   = sd_ibi / mean_ibi * 100 if mean_ibi > 0 else np.nan

    # Irregular beats: IBI outside mean ± outlier_sd*SD
    lo = mean_ibi - outlier_sd * sd_ibi
    hi = mean_ibi + outlier_sd * sd_ibi
    n_irreg = int(np.sum((ibis < lo) | (ibis > hi)))
    irreg_pct = n_irreg / len(ibis) * 100

    # Write back to result
    result.ibi_cv_pct          = cv_pct
    result.ibi_mean_ms         = mean_ibi
    result.ibi_sd_ms           = sd_ibi
    result.irregular_beat_pct  = irreg_pct

    return {
        "ibi_cv_pct":         cv_pct,
        "ibi_mean_ms":        mean_ibi,
        "ibi_sd_ms":          sd_ibi,
        "irregular_beat_pct": irreg_pct,
        "n_irregular":        n_irreg,
        "n_total":            len(ibis),
    }


# ─────────────────────────────────────────────
#  DAD Detection
# ─────────────────────────────────────────────

def detect_dad(result: KineticsResult,
               signal: np.ndarray,
               fps: float,
               dad_window_ms: float = 200.0,
               dad_prominence: float = 0.05) -> dict:
    """
    Detect Delayed Afterdepolarizations (DADs) between beats.

    Strategy: search the inter-beat interval (diastolic window)
    for sub-threshold Ca2+ elevations that precede the next beat.

    DAD appears as a small Ca2+ bump AFTER complete decay
    and BEFORE the next normal beat — unlike EAD which occurs
    DURING the decay phase.

    Parameters
    ----------
    result           : KineticsResult (beat_to_beat must be populated)
    signal           : raw Ca2+ signal (same as passed to analyze_transient)
    fps              : frames per second
    dad_window_ms    : look-back window before next beat onset (ms)
    dad_prominence   : minimum prominence as fraction of mean amplitude

    Returns
    -------
    dict with n_dad_beats, dad_beat_pct, dad_timings_ms
    """
    beats     = result.beat_to_beat
    mean_amp  = result.amp_mean
    prom_abs  = dad_prominence * mean_amp * float(np.percentile(signal, 10))
    n_frames  = len(signal)
    dad_window_frames = int(dad_window_ms / 1000 * fps)

    # Estimate beat onset frames from IBI
    # Reconstruct approximate beat times
    ibi_frames = [int(b.ibi_ms / 1000 * fps)
                  for b in beats if not np.isnan(b.ibi_ms)]
    if len(ibi_frames) < 2:
        return {"n_dad_beats": 0}

    mean_ibi_frames = int(np.mean(ibi_frames))
    # Approximate first beat onset
    first_onset = int(0.1 * fps)
    beat_onsets = [first_onset + i * mean_ibi_frames
                   for i in range(len(beats) + 1)]
    beat_onsets = [b for b in beat_onsets if b < n_frames]

    dad_timings = []
    sig_smooth  = safe_sg(signal.astype(float), 3, 11)
    baseline_v  = float(np.percentile(signal, 10))

    for i in range(len(beat_onsets) - 1):
        # Diastolic window: end of current beat → start of next beat
        current_onset = beat_onsets[i]
        next_onset    = beat_onsets[i + 1]

        # Skip first 40% of IBI (still in decay)
        diastole_start = current_onset + int(0.40 * (next_onset - current_onset))
        diastole_end   = next_onset - int(0.10 * (next_onset - current_onset))

        if diastole_end <= diastole_start or diastole_start >= n_frames:
            continue

        window = sig_smooth[diastole_start:min(diastole_end, n_frames)]
        if len(window) < 5:
            continue

        # Normalize window
        w_norm  = (window - baseline_v) / (baseline_v + 1e-9)
        w_range = np.max(w_norm) - np.min(w_norm)

        dad_pks, _ = find_peaks(
            w_norm,
            height=dad_prominence * 0.5,       # 2.5% of baseline
            prominence=max(0.02, w_range * 0.3),
            distance=int(fps * 0.03),
        )

        if len(dad_pks) > 0 and i < len(beats):
            timing_ms = (diastole_start + dad_pks[0]) / fps * 1000
            dad_timings.append(timing_ms)
            beats[i].dad_detected  = True
            beats[i].dad_timing_ms = timing_ms

    n_dad = len(dad_timings)
    dad_pct = n_dad / max(len(beats), 1) * 100

    result.n_dad_beats  = n_dad
    result.dad_beat_pct = dad_pct

    return {
        "n_dad_beats":    n_dad,
        "dad_beat_pct":   dad_pct,
        "dad_timings_ms": dad_timings,
    }


# ─────────────────────────────────────────────
#  Triggered Activity Detection
# ─────────────────────────────────────────────

def detect_triggered_activity(result: KineticsResult,
                               ibi_shortening_threshold: float = 0.30) -> dict:
    """
    Detect triggered activity: EAD or DAD that triggers consecutive
    abnormally short beats (IBI shortening).

    Definition
    ----------
    Triggered activity is flagged when:
    1. Beat N has EAD or DAD detected
    2. Beat N+1 has IBI < mean_IBI × (1 - threshold)
       i.e., next beat comes early (rate acceleration)

    This captures the "EAD/DAD → run of fast beats" cascade
    characteristic of triggered ventricular tachycardia.

    Parameters
    ----------
    result                     : KineticsResult
    ibi_shortening_threshold   : fraction of mean IBI shortening
                                 that defines "triggered" (default 0.30)

    Returns
    -------
    dict with n_triggered, triggered_beat_indices, triggered_pct
    """
    beats    = result.beat_to_beat
    ibis     = np.array([b.ibi_ms for b in beats if not np.isnan(b.ibi_ms)])
    if len(ibis) < 3:
        return {"n_triggered": 0}

    mean_ibi   = float(np.mean(ibis))
    threshold_ms = mean_ibi * (1 - ibi_shortening_threshold)

    triggered_indices = []

    for i in range(len(beats) - 1):
        b_now  = beats[i]
        b_next = beats[i + 1]

        # Trigger condition: EAD or DAD in current beat
        has_trigger = b_now.ead_detected or b_now.dad_detected

        # Consequence: next beat comes early
        next_short  = (not np.isnan(b_next.ibi_ms) and
                       b_next.ibi_ms < threshold_ms)

        if has_trigger and next_short:
            b_now.triggered_activity = True
            triggered_indices.append(i)

    n_trig   = len(triggered_indices)
    trig_pct = n_trig / max(len(beats), 1) * 100

    result.n_triggered = n_trig

    return {
        "n_triggered":            n_trig,
        "triggered_beat_indices": triggered_indices,
        "triggered_pct":          trig_pct,
        "mean_ibi_ms":            mean_ibi,
        "threshold_ms":           threshold_ms,
    }


# ─────────────────────────────────────────────
#  Convenience: run all arrhythmia analyses
# ─────────────────────────────────────────────

def analyze_arrhythmia_panel(result: KineticsResult,
                              signal: np.ndarray,
                              fps: float) -> dict:
    """
    Run all arrhythmia analyses in one call.

    Returns
    -------
    dict with keys: irregularity, dad, triggered, alternans
    """
    out = {}
    out["irregularity"] = analyze_beat_irregularity(result)
    out["dad"]          = detect_dad(result, signal, fps)
    out["triggered"]    = detect_triggered_activity(result)
    try:
        from core.signal_processing import analyze_alternans
        out["alternans"] = analyze_alternans(result).__dict__
    except Exception:
        out["alternans"] = {}
    return out
