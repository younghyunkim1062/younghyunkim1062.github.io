# iCAMAnalyzer — Python source, UI version 20261021

Calcium-transient analysis, calcium-based activation mapping, and label-free tissue-motion analysis in separate workspaces.

## Run
Use Python 3.10 or later. Extract this archive into its own folder. Activate your Python environment, open a terminal in that folder, then run:

    python -m pip install -r requirements.txt
    python iCAMAnalyzer.py

The package uses a PyQt5 desktop interface. Dependencies include NumPy, SciPy, Matplotlib, OpenCV, pandas, scikit-image, scikit-learn, openpyxl, and Cellpose. See requirements.txt.

## Version and scope
This package contains the 20261021 interface refresh based on the supplied 20260719 source. It is not a claim that this is the latest of all private development copies. The core/*.py analysis files are unchanged from that source. Fluorescence and brightfield remain separate modes. The inactive morphology_tab.py module is retained as source but is not an active workspace.

Calcium-signal propagation is not a direct electrical conduction measurement. Image-derived motion and area changes are not independently calibrated force measurements. Synchronized acquisition is needed to relate calcium and contraction timing within the same beat.

## Verification completed for the UI update
- Both workspaces and the mode-selection interface launched under Linux/PyQt5 offscreen rendering.
- Synthetic fluorescence example: video/ROI processing, activation maps, transient analysis, and Excel/PNG exports.
- Synthetic brightfield example: region detection, three ROI signals, feature displays, and mechanical maps.

These are workflow smoke tests, not a scientific validation study. Experimental recordings, Windows scaling, all input formats, and Cellpose model inference require separate checks. Preview screenshots on the website use synthetic data.

## Packaging
Application source and dependency files match the 20261021 working copy. The original backup archive, cached bytecode, editor settings, and preview images are not included in this public source package. The original user archive is preserved separately.

## License and citation
Formal licensing and citation guidance are pending. No open-source license is granted by this README.

Project page: https://younghyunkim1062.github.io/icamanalyzer.html
