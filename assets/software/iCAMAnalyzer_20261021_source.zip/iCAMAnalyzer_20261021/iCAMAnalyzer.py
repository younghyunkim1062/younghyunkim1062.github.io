#!/usr/bin/env python3
"""
iCAMAnalyzer.py  —  entry point
Run:  python iCAMAnalyzer.py
"""

from gui.main_window import launch

if __name__ == "__main__":
    launch()
